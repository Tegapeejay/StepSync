import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/theme.dart';
import 'screens/auth/sign_in_screen.dart';
import 'screens/auth/update_password_screen.dart';
import 'screens/main_scaffold.dart';
import 'services/analytics_service.dart';
import 'services/auth_service.dart';

class StepSyncApp extends StatefulWidget {
  final SharedPreferences prefs;
  final AuthService auth;
  final AnalyticsService analytics;

  const StepSyncApp({
    super.key,
    required this.prefs,
    required this.auth,
    required this.analytics,
  });

  @override
  State<StepSyncApp> createState() => _StepSyncAppState();
}

class _StepSyncAppState extends State<StepSyncApp> {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StepSync',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      navigatorKey: _navigatorKey,
      home: AuthGate(
        prefs: widget.prefs,
        auth: widget.auth,
        analytics: widget.analytics,
        navigatorKey: _navigatorKey,
      ),
    );
  }
}

/// Chooses between the sign-in flow and the signed-in app based on the
/// Supabase session. Protected screens are only built while a session
/// exists, and the signed-in shell is keyed by user id so switching accounts
/// discards the previous user's in-memory state.
class AuthGate extends StatefulWidget {
  final SharedPreferences prefs;
  final AuthService auth;
  final AnalyticsService analytics;
  final GlobalKey<NavigatorState> navigatorKey;

  const AuthGate({
    super.key,
    required this.prefs,
    required this.auth,
    required this.analytics,
    required this.navigatorKey,
  });

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  StreamSubscription<AuthState>? _sub;
  Session? _session;

  @override
  void initState() {
    super.initState();
    _session = widget.auth.currentSession;
    _sub = widget.auth.onAuthStateChange.listen(_onAuthState, onError: (Object _) {
      // e.g. an invalid / expired deep link; the sign-in screen stays.
    });
  }

  void _onAuthState(AuthState data) {
    final AuthChangeEvent event = data.event;
    if (event == AuthChangeEvent.signedIn) {
      // A real sign-in (not a restored session): record it server-side.
      unawaited(widget.auth.recordSignIn(widget.auth.takePendingProvider()));
    }
    if (event == AuthChangeEvent.passwordRecovery) {
      // On a cold start from the reset link the navigator may not exist yet.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        widget.navigatorKey.currentState?.push(MaterialPageRoute<void>(
          builder: (_) => UpdatePasswordScreen(auth: widget.auth),
        ));
      });
    }
    final bool changedUser = data.session?.user.id != _session?.user.id;
    if (!mounted) return;
    setState(() => _session = data.session);
    if (changedUser && event != AuthChangeEvent.passwordRecovery) {
      // Drop routes pushed on top (sign-up, settings) so the new root shows.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        widget.navigatorKey.currentState?.popUntil((Route<dynamic> r) => r.isFirst);
      });
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Session? session = _session;
    if (session == null) {
      return SignInScreen(auth: widget.auth, analytics: widget.analytics);
    }
    return MainScaffold(
      key: ValueKey<String>('user-${session.user.id}'),
      prefs: widget.prefs,
      user: session.user,
      auth: widget.auth,
      analytics: widget.analytics,
    );
  }
}

/// Shown when the app can't start (storage or configuration problems).
class StartupMessageApp extends StatelessWidget {
  final String title;
  final String message;
  const StartupMessageApp({super.key, required this.title, required this.message});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: Scaffold(
        backgroundColor: AppColors.background,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Icon(Icons.settings_suggest_rounded, color: AppColors.warning, size: 48),
                  const SizedBox(height: 16),
                  Text(
                    title,
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SelectableText(
                    message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppColors.textSecondary, height: 1.5),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
