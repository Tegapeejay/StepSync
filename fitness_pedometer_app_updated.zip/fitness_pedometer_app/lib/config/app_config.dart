/// Build-time configuration, read from `--dart-define` /
/// `--dart-define-from-file=.env`. See `.env.example`.
///
/// Only client-safe values belong here. The Supabase service-role key and
/// OAuth client secrets must never be compiled into the app.
class AppConfig {
  AppConfig._();

  static const String supabaseUrl = String.fromEnvironment('SUPABASE_URL');

  /// The project's publishable key, or the legacy `anon` key.
  static const String supabasePublishableKey =
      String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

  /// Deep link Supabase redirects to after Google / Facebook sign-in.
  static const String authRedirectUrl = String.fromEnvironment(
    'AUTH_REDIRECT_URL',
    defaultValue: 'io.stepsync.app://login-callback',
  );

  static const String environment =
      String.fromEnvironment('APP_ENV', defaultValue: 'development');

  static const String appVersion = '1.1.0';

  /// Lists what is missing, so the app can show a setup screen instead of
  /// crashing when it was started without `--dart-define-from-file`.
  static List<String> get missing => <String>[
        if (supabaseUrl.isEmpty) 'SUPABASE_URL',
        if (supabasePublishableKey.isEmpty) 'SUPABASE_PUBLISHABLE_KEY',
      ];

  static bool get isConfigured => missing.isEmpty;
}
