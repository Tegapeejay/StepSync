// StepSync — fitness pedometer with GPS distance, history, music and
// Supabase sync.
//
// The original single-file app has been split into modules:
//
//   config/    build-time configuration (.env via --dart-define-from-file)
//   core/      theme, formatting, distance & GPS maths, reports
//   models/    profile, daily activity, GPS sessions
//   services/  auth, profile, pedometer, GPS, sync, history, analytics,
//              admin, music
//   widgets/   reusable UI from the original app
//   screens/   auth, home, activity, music, profile, admin
//
// Everything is null-safe and avoids experimental Dart features.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'config/app_config.dart';
import 'core/theme.dart';
import 'services/analytics_service.dart';
import 'services/auth_service.dart';
import 'services/backend.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.background,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  SharedPreferences prefs;
  try {
    prefs = await SharedPreferences.getInstance();
  } catch (_) {
    // If local storage somehow fails to initialise we still launch the app in
    // a safe state rather than crashing.
    runApp(const StartupMessageApp(
      title: 'Storage unavailable',
      message: 'Local storage is unavailable, so the app cannot start.\n'
          'Please restart the app or reinstall it.',
    ));
    return;
  }

  if (!AppConfig.isConfigured) {
    runApp(StartupMessageApp(
      title: 'Setup needed',
      message: 'This build has no Supabase configuration (missing: '
          '${AppConfig.missing.join(', ')}).\n\n'
          'Copy .env.example to .env, fill in your project values and run:\n'
          'flutter run --dart-define-from-file=.env',
    ));
    return;
  }

  try {
    await Backend.initialize();
  } catch (_) {
    runApp(const StartupMessageApp(
      title: 'Could not start',
      message: 'The app could not initialise its backend connection. '
          'Check SUPABASE_URL and the publishable key, then restart.',
    ));
    return;
  }

  final AuthService auth = AuthService(prefs);
  await auth.enforceRememberMe();
  final AnalyticsService analytics = AnalyticsService(prefs);
  unawaited(analytics.recordLaunch());

  runApp(StepSyncApp(prefs: prefs, auth: auth, analytics: analytics));
}
