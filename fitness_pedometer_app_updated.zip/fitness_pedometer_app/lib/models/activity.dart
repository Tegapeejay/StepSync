import '../core/formatters.dart';

/// One row of `public.daily_activity`: a user's totals for one LOCAL date.
class DailyActivity {
  const DailyActivity({
    required this.date,
    required this.steps,
    required this.strideDistanceMeters,
    required this.gpsDistanceMeters,
    required this.activeMinutes,
    required this.dailyGoal,
  });

  final DateTime date;
  final int steps;
  final double strideDistanceMeters;
  final double gpsDistanceMeters;
  final int activeMinutes;
  final int dailyGoal;

  bool get goalAchieved => dailyGoal > 0 && steps >= dailyGoal;

  factory DailyActivity.fromRow(Map<String, dynamic> row) => DailyActivity(
        date: parseDateKey(row['activity_date'] as String),
        steps: (row['steps'] as num?)?.toInt() ?? 0,
        strideDistanceMeters: (row['stride_distance_m'] as num?)?.toDouble() ?? 0,
        gpsDistanceMeters: (row['gps_distance_m'] as num?)?.toDouble() ?? 0,
        activeMinutes: (row['active_minutes'] as num?)?.toInt() ?? 0,
        dailyGoal: (row['daily_goal'] as num?)?.toInt() ?? 0,
      );
}

/// Pending upload of a day's totals (kept in the offline queue).
class DailyUpload {
  const DailyUpload({
    required this.dateKey,
    required this.steps,
    required this.strideDistanceMeters,
    required this.activeMinutes,
    required this.dailyGoal,
  });

  final String dateKey;
  final int steps;
  final double strideDistanceMeters;
  final int activeMinutes;
  final int dailyGoal;

  /// Merging two pending uploads for the same day keeps the larger values,
  /// matching the server's reconciliation rule.
  DailyUpload merge(DailyUpload other) => DailyUpload(
        dateKey: dateKey,
        steps: other.steps > steps ? other.steps : steps,
        strideDistanceMeters: other.strideDistanceMeters > strideDistanceMeters
            ? other.strideDistanceMeters
            : strideDistanceMeters,
        activeMinutes: other.activeMinutes > activeMinutes ? other.activeMinutes : activeMinutes,
        dailyGoal: other.dailyGoal,
      );

  Map<String, dynamic> toRpcParams() => <String, dynamic>{
        'p_activity_date': dateKey,
        'p_steps': steps,
        'p_stride_distance_m': double.parse(strideDistanceMeters.toStringAsFixed(1)),
        'p_active_minutes': activeMinutes,
        'p_daily_goal': dailyGoal,
      };

  Map<String, dynamic> toJson() => <String, dynamic>{
        'date': dateKey,
        'steps': steps,
        'stride_m': strideDistanceMeters,
        'active_min': activeMinutes,
        'goal': dailyGoal,
      };

  factory DailyUpload.fromJson(Map<String, dynamic> j) => DailyUpload(
        dateKey: j['date'] as String,
        steps: (j['steps'] as num).toInt(),
        strideDistanceMeters: (j['stride_m'] as num).toDouble(),
        activeMinutes: (j['active_min'] as num?)?.toInt() ?? 0,
        dailyGoal: (j['goal'] as num).toInt(),
      );
}

enum GpsSessionStatus {
  completed,
  discarded;

  static GpsSessionStatus parse(String? s) =>
      s == 'discarded' ? GpsSessionStatus.discarded : GpsSessionStatus.completed;
}

/// Summary of one GPS tracking session. Individual coordinates are NOT
/// stored or uploaded — only these totals.
class GpsSession {
  const GpsSession({
    required this.id,
    required this.startedAt,
    required this.endedAt,
    required this.gpsDistanceMeters,
    required this.durationSeconds,
    required this.steps,
    required this.strideMeters,
    this.status = GpsSessionStatus.completed,
  });

  /// Client-generated UUID, so retried uploads are idempotent.
  final String id;
  final DateTime startedAt;
  final DateTime endedAt;
  final double gpsDistanceMeters;
  final int durationSeconds;

  /// Steps counted by the pedometer during this session; null if they could
  /// not be attributed (e.g. sensor unavailable or the day rolled over).
  final int? steps;

  /// Stride length in use when the session was recorded.
  final double strideMeters;
  final GpsSessionStatus status;

  double? get strideDistanceMeters => steps == null ? null : steps! * strideMeters;

  /// Average speed in m/s, or null for very short sessions.
  double? get averageSpeedMps =>
      durationSeconds >= 10 ? gpsDistanceMeters / durationSeconds : null;

  String get activityDateKey => dateKey(startedAt.toLocal());

  Map<String, dynamic> toRow(String userId) => <String, dynamic>{
        'id': id,
        'user_id': userId,
        'activity_date': activityDateKey,
        'started_at': startedAt.toUtc().toIso8601String(),
        'ended_at': endedAt.toUtc().toIso8601String(),
        'gps_distance_m': double.parse(gpsDistanceMeters.toStringAsFixed(1)),
        'duration_seconds': durationSeconds,
        'avg_speed_mps': averageSpeedMps == null
            ? null
            : double.parse(averageSpeedMps!.toStringAsFixed(3)),
        'steps': steps,
        'stride_length_m': double.parse(strideMeters.toStringAsFixed(3)),
        'status': status.name,
      };

  factory GpsSession.fromRow(Map<String, dynamic> row) => GpsSession(
        id: row['id'] as String,
        startedAt: DateTime.parse(row['started_at'] as String).toLocal(),
        endedAt: DateTime.parse(row['ended_at'] as String).toLocal(),
        gpsDistanceMeters: (row['gps_distance_m'] as num).toDouble(),
        durationSeconds: (row['duration_seconds'] as num).toInt(),
        steps: (row['steps'] as num?)?.toInt(),
        strideMeters: (row['stride_length_m'] as num?)?.toDouble() ?? 0,
        status: GpsSessionStatus.parse(row['status'] as String?),
      );
}
