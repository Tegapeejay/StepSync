import '../core/formatters.dart';
import '../core/theme.dart';

/// The user's profile, stored in Supabase `public.profiles` and cached
/// locally so the dashboard can start offline.
class Profile {
  String id; // auth.users.id
  String name;
  String email;
  String? avatarUrl;
  double heightCm;
  String sex; // 'male' | 'female' | 'unspecified'
  double? strideOverride; // when non-null, used instead of the height estimate
  int dailyGoal;
  DistanceUnit unit;

  Profile({
    required this.id,
    required this.name,
    required this.email,
    this.avatarUrl,
    required this.heightCm,
    required this.sex,
    required this.strideOverride,
    required this.dailyGoal,
    this.unit = DistanceUnit.km,
  });

  factory Profile.defaults({required String id, required String email, String name = ''}) =>
      Profile(
        id: id,
        name: name,
        email: email,
        heightCm: 170.0,
        sex: 'unspecified',
        strideOverride: null,
        dailyGoal: kDefaultDailyGoal,
      );

  /// The stride length actually used for distance calculations.
  double get effectiveStrideMeters {
    if (strideOverride != null && strideOverride! > 0) {
      return strideOverride!;
    }
    return estimateStrideMeters(heightCm: heightCm, sex: sex);
  }

  /// Row for `profiles` (only the columns users may update).
  Map<String, dynamic> toUpdateRow() => <String, dynamic>{
        'full_name': name.trim(),
        'height_cm': heightCm,
        'sex': sex,
        'stride_length_m': double.parse(effectiveStrideMeters.toStringAsFixed(3)),
        'stride_is_custom': strideOverride != null,
        'daily_step_goal': dailyGoal,
        'preferred_distance_unit': unit.name,
      };

  factory Profile.fromRow(Map<String, dynamic> row) {
    final bool custom = row['stride_is_custom'] as bool? ?? false;
    return Profile(
      id: row['id'] as String,
      name: row['full_name'] as String? ?? '',
      email: row['email'] as String? ?? '',
      avatarUrl: row['avatar_url'] as String?,
      heightCm: (row['height_cm'] as num?)?.toDouble() ?? 170.0,
      sex: row['sex'] as String? ?? 'unspecified',
      strideOverride: custom ? (row['stride_length_m'] as num?)?.toDouble() : null,
      dailyGoal: (row['daily_step_goal'] as num?)?.toInt() ?? kDefaultDailyGoal,
      unit: DistanceUnit.parse(row['preferred_distance_unit'] as String?),
    );
  }

  /// Local cache format.
  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'full_name': name,
        'email': email,
        'avatar_url': avatarUrl,
        'height_cm': heightCm,
        'sex': sex,
        'stride_length_m': strideOverride ?? effectiveStrideMeters,
        'stride_is_custom': strideOverride != null,
        'daily_step_goal': dailyGoal,
        'preferred_distance_unit': unit.name,
      };

  factory Profile.fromJson(Map<String, dynamic> json) => Profile.fromRow(json);
}
