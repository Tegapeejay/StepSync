import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config/app_config.dart';
import '../core/ids.dart';
import 'backend.dart';

/// Best-effort product analytics written to `public.analytics_events`.
///
/// - Never sends passwords, tokens, emails or coordinates.
/// - The installation id is a random UUID created on first launch, stored
///   only in this app's preferences; it is reset by reinstalling or clearing
///   app data. A "first open" is NOT a verified store download.
/// - Failures are swallowed so analytics can never break the app.
class AnalyticsService {
  AnalyticsService(this._prefs);

  final SharedPreferences _prefs;

  static const String _installIdKey = 'analytics:installation_id';
  static const String _firstOpenSentKey = 'analytics:first_open_sent';
  static const String _lastActiveKey = 'analytics:last_active_day';

  String get installationId {
    String? id = _prefs.getString(_installIdKey);
    if (id == null) {
      id = uuidV4();
      _prefs.setString(_installIdKey, id);
    }
    return id;
  }

  /// Sends `app_first_open` once per installation (retried until it
  /// succeeds) and `app_open` on every launch.
  Future<void> recordLaunch() async {
    if (!(_prefs.getBool(_firstOpenSentKey) ?? false)) {
      final bool ok = await _insert('app_first_open', anonymous: true);
      if (ok) await _prefs.setBool(_firstOpenSentKey, true);
    }
    await _insert('app_open', anonymous: Backend.client.auth.currentUser == null);
  }

  /// `user_active` at most once per local day per signed-in user.
  Future<void> recordActiveToday(String userId, String todayKey) async {
    final String key = '$_lastActiveKey:$userId';
    if (_prefs.getString(key) == todayKey) return;
    if (await track('user_active')) await _prefs.setString(key, todayKey);
  }

  /// Events for the signed-in user. Allowed names are enforced by the
  /// database (see supabase_setup.sql).
  Future<bool> track(String eventName, {Map<String, Object?> metadata = const <String, Object?>{}}) {
    return _insert(eventName, metadata: metadata);
  }

  Future<bool> _insert(
    String eventName, {
    bool anonymous = false,
    Map<String, Object?> metadata = const <String, Object?>{},
  }) async {
    if (!Backend.isInitialized) return false;
    final String? userId = anonymous ? null : Backend.client.auth.currentUser?.id;
    if (!anonymous && userId == null) return false;
    try {
      await Backend.client.from('analytics_events').insert(<String, dynamic>{
        'user_id': userId,
        'installation_id': installationId,
        'event_name': eventName,
        'app_version': AppConfig.appVersion,
        'platform': Backend.platform,
        'metadata': metadata,
      });
      return true;
    } catch (e) {
      debugPrint('analytics: "$eventName" not sent (${e.runtimeType})');
      return false;
    }
  }
}
