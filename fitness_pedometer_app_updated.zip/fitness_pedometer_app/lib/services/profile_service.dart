import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/profile.dart';
import 'backend.dart';

/// Loads and saves the profile in Supabase (`public.profiles`, protected by
/// RLS) with a local cache so the dashboard works offline.
class ProfileService {
  ProfileService(this._prefs);

  final SharedPreferences _prefs;

  String _cacheKey(String userId) => 'profile:cache:$userId';

  Profile? cached(String userId) {
    final String? raw = _prefs.getString(_cacheKey(userId));
    if (raw == null) return null;
    try {
      return Profile.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> _cache(Profile p) =>
      _prefs.setString(_cacheKey(p.id), jsonEncode(p.toJson()));

  /// Fresh profile from the server; falls back to the cache, then to
  /// defaults built from the Auth user (e.g. when offline).
  Future<Profile> load(User user) async {
    try {
      final Map<String, dynamic>? row = await Backend.client
          .from('profiles')
          .select()
          .eq('id', user.id)
          .maybeSingle();
      if (row != null) {
        final Profile p = Profile.fromRow(row);
        if (p.email.isEmpty) p.email = user.email ?? '';
        await _cache(p);
        return p;
      }
    } catch (_) {
      // Fall through to the cache.
    }
    return cached(user.id) ?? _defaultsFor(user);
  }

  Profile _defaultsFor(User user) {
    final Map<String, dynamic> meta = user.userMetadata ?? const <String, dynamic>{};
    return Profile.defaults(
      id: user.id,
      email: user.email ?? '',
      name: (meta['full_name'] ?? meta['name'] ?? '') as String,
    );
  }

  /// Saves editable fields. Protected columns (email, account status) are
  /// not sent and are blocked by column privileges on the server anyway.
  Future<void> save(Profile profile) async {
    final List<Map<String, dynamic>> updated = await Backend.client
        .from('profiles')
        .update(profile.toUpdateRow())
        .eq('id', profile.id)
        .select('id');
    if (updated.isEmpty) {
      // No profile row (e.g. the SQL setup wasn't run): don't report success.
      throw StateError('Profile not found on the server.');
    }
    await _cache(profile);
  }
}
