import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

import '../core/formatters.dart';
import '../core/gps_math.dart';
import '../core/ids.dart';
import '../models/activity.dart';
import 'pedometer_service.dart';

enum GpsPermission { unknown, granted, denied, deniedForever, serviceDisabled }

enum GpsTrackingState { idle, starting, tracking }

/// Explicit start/stop GPS distance tracking, independent of step counting.
///
/// - Location permission is requested only when the user taps Start.
/// - Tracking runs while the app is open (foreground). No background
///   location service is configured, so the OS may pause updates when the
///   app is backgrounded or the screen is off; the UI says so.
/// - Only the session summary is kept; coordinates stay in memory and are
///   discarded when the session ends.
class GpsTracker extends ChangeNotifier {
  GpsTracker({required this.pedometer});

  final PedometerService pedometer;

  GpsTrackingState state = GpsTrackingState.idle;
  GpsPermission permission = GpsPermission.unknown;
  String? errorMessage;

  final GpsDistanceAccumulator _accumulator = GpsDistanceAccumulator();
  StreamSubscription<Position>? _positionSub;
  StreamSubscription<ServiceStatus>? _serviceSub;
  Timer? _ticker;

  DateTime? _startedAt;
  int? _startSteps;
  String? _startDateKey;
  DateTime? _lastFixAt;
  double? lastAccuracyMeters;

  bool get isTracking => state == GpsTrackingState.tracking;
  double get distanceMeters => _accumulator.totalMeters;
  DateTime? get startedAt => _startedAt;

  Duration get elapsed =>
      _startedAt == null ? Duration.zero : DateTime.now().difference(_startedAt!);

  /// No usable fix for 20 s while tracking (indoors, tunnel, weak signal).
  bool get signalWeak {
    if (!isTracking) return false;
    final DateTime ref = _lastFixAt ?? _startedAt ?? DateTime.now();
    return DateTime.now().difference(ref) > const Duration(seconds: 20);
  }

  /// Steps counted by the pedometer since this session started, or null when
  /// they can't be attributed to the session.
  int? get sessionSteps {
    final int? start = _startSteps;
    if (start == null || !pedometer.isCounting) return null;
    if (_startDateKey != dateKey(DateTime.now())) return null; // crossed midnight
    final int diff = pedometer.todaySteps - start;
    return diff < 0 ? null : diff;
  }

  /// Checks service + permission, requesting permission if needed.
  Future<bool> ensurePermission() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        permission = GpsPermission.serviceDisabled;
        notifyListeners();
        return false;
      }
      LocationPermission p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) {
        p = await Geolocator.requestPermission();
      }
      switch (p) {
        case LocationPermission.always:
        case LocationPermission.whileInUse:
          permission = GpsPermission.granted;
          break;
        case LocationPermission.deniedForever:
          permission = GpsPermission.deniedForever;
          break;
        case LocationPermission.denied:
        case LocationPermission.unableToDetermine:
          permission = GpsPermission.denied;
          break;
      }
    } catch (e) {
      errorMessage = 'Location is not available on this device.';
      permission = GpsPermission.denied;
    }
    notifyListeners();
    return permission == GpsPermission.granted;
  }

  Future<void> openSettings() async {
    if (permission == GpsPermission.serviceDisabled) {
      await Geolocator.openLocationSettings();
    } else {
      await Geolocator.openAppSettings();
    }
  }

  Future<bool> start() async {
    if (state != GpsTrackingState.idle) return false;
    errorMessage = null;
    state = GpsTrackingState.starting;
    notifyListeners();

    final bool permitted = await ensurePermission();
    if (_disposed) return false; // signed out while the dialog was open
    if (!permitted) {
      state = GpsTrackingState.idle;
      notifyListeners();
      return false;
    }

    _accumulator.reset();
    _startedAt = DateTime.now();
    _startDateKey = dateKey(_startedAt!);
    _startSteps = pedometer.isCounting ? pedometer.todaySteps : null;
    _lastFixAt = null;
    lastAccuracyMeters = null;

    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 3,
      ),
    ).listen(_onPosition, onError: _onPositionError, cancelOnError: false);

    try {
      _serviceSub = Geolocator.getServiceStatusStream().listen((ServiceStatus s) {
        if (s == ServiceStatus.disabled) {
          errorMessage = 'Location services were turned off. Distance is paused.';
        } else {
          errorMessage = null;
        }
        notifyListeners();
      });
    } catch (_) {
      // Not supported on every platform; the position stream errors instead.
    }

    // Repaint the timer once a second.
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => notifyListeners());
    state = GpsTrackingState.tracking;
    notifyListeners();
    return true;
  }

  void _onPosition(Position p) {
    lastAccuracyMeters = p.accuracy;
    final FixDecision d = _accumulator.add(GpsFix(
      latitude: p.latitude,
      longitude: p.longitude,
      accuracyMeters: p.accuracy,
      timestamp: p.timestamp,
    ));
    if (d != FixDecision.rejectedInaccurate && d != FixDecision.rejectedStale) {
      _lastFixAt = DateTime.now();
    }
    if (errorMessage != null && d == FixDecision.accepted) errorMessage = null;
    notifyListeners();
  }

  void _onPositionError(Object error) {
    // Temporary signal loss: keep the session and the distance so far.
    errorMessage = error is LocationServiceDisabledException
        ? 'Location services were turned off. Distance is paused.'
        : 'GPS signal lost. Keep the app open; distance resumes when the signal returns.';
    notifyListeners();
  }

  /// Ends the session and returns its summary (not yet saved).
  Future<GpsSession?> stop() async {
    if (state != GpsTrackingState.tracking || _startedAt == null) return null;
    final DateTime end = DateTime.now();
    final int? steps = sessionSteps;
    await _cancelStreams();
    final GpsSession session = GpsSession(
      id: uuidV4(),
      startedAt: _startedAt!,
      endedAt: end,
      gpsDistanceMeters: _accumulator.totalMeters,
      durationSeconds: end.difference(_startedAt!).inSeconds,
      steps: steps,
      strideMeters: pedometer.strideLengthMeters,
    );
    state = GpsTrackingState.idle;
    _startedAt = null;
    _startSteps = null;
    errorMessage = null;
    notifyListeners();
    return session;
  }

  Future<void> _cancelStreams() async {
    _ticker?.cancel();
    _ticker = null;
    await _positionSub?.cancel();
    _positionSub = null;
    await _serviceSub?.cancel();
    _serviceSub = null;
  }

  bool _disposed = false;

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _ticker?.cancel();
    _positionSub?.cancel();
    _serviceSub?.cancel();
    super.dispose();
  }
}
