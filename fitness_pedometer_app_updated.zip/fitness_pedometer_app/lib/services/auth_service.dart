import 'dart:async';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; // re-exports LaunchMode

import '../config/app_config.dart';
import 'backend.dart';

class AuthResult {
  final bool success;
  final String? error;

  /// Sign-up succeeded but the project requires email confirmation first.
  final bool needsEmailConfirmation;

  const AuthResult(this.success, this.error, {this.needsEmailConfirmation = false});
}

/// Supabase Auth: email/password, Google and Facebook (browser OAuth with a
/// deep-link callback), sign-out, session restore and account deletion.
///
/// Sessions are persisted by supabase_flutter and restored automatically on
/// launch. Passwords and tokens are never logged or stored by this app.
class AuthService {
  AuthService(this._prefs);

  final SharedPreferences _prefs;
  GoTrueClient get _auth => Backend.client.auth;

  static const String _ephemeralKey = 'auth:ephemeral_session';
  static const String _pendingProviderKey = 'auth:pending_oauth_provider';

  Session? get currentSession => _auth.currentSession;
  User? get currentUser => _auth.currentUser;
  Stream<AuthState> get onAuthStateChange => _auth.onAuthStateChange;

  /// Applies the "Remember me" choice from the last sign-in: if the user
  /// didn't want to stay signed in, the restored session is ended at launch.
  Future<void> enforceRememberMe() async {
    if ((_prefs.getBool(_ephemeralKey) ?? false) && currentSession != null) {
      await _prefs.remove(_ephemeralKey);
      try {
        await _auth.signOut(scope: SignOutScope.local);
      } catch (_) {
        // Offline: the local session is cleared either way.
      }
    }
  }

  Future<AuthResult> register({
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      final AuthResponse res = await _auth.signUp(
        email: email.trim().toLowerCase(),
        password: password,
        data: <String, dynamic>{'full_name': name.trim()},
        emailRedirectTo: AppConfig.authRedirectUrl,
      );
      await _prefs.remove(_ephemeralKey);
      if (res.session == null) {
        // Email confirmation is enabled in Supabase.
        return const AuthResult(true, null, needsEmailConfirmation: true);
      }
      return const AuthResult(true, null);
    } catch (e) {
      return AuthResult(false, friendlyBackendError(e));
    }
  }

  Future<AuthResult> login({
    required String email,
    required String password,
    required bool rememberMe,
  }) async {
    try {
      await _auth.signInWithPassword(
        email: email.trim().toLowerCase(),
        password: password,
      );
      await _setRememberMe(rememberMe);
      return const AuthResult(true, null);
    } catch (e) {
      return AuthResult(false, friendlyBackendError(e));
    }
  }

  /// Opens the provider's sign-in page in the browser. The result arrives
  /// later through [onAuthStateChange] when the deep link returns to the app;
  /// if the user cancels, no event arrives (the screen handles that).
  Future<AuthResult> signInWithProvider(OAuthProvider provider) async {
    try {
      await _prefs.setString(_pendingProviderKey, provider.name);
      await _prefs.remove(_ephemeralKey);
      final bool launched = await _auth.signInWithOAuth(
        provider,
        redirectTo: AppConfig.authRedirectUrl,
        authScreenLaunchMode: LaunchMode.externalApplication,
      );
      if (!launched) {
        await _prefs.remove(_pendingProviderKey);
        return const AuthResult(false, 'Could not open the sign-in page.');
      }
      return const AuthResult(true, null);
    } catch (e) {
      await _prefs.remove(_pendingProviderKey);
      return AuthResult(false, friendlyBackendError(e));
    }
  }

  /// The provider of an OAuth flow started by this device, consumed once.
  String takePendingProvider() {
    final String? p = _prefs.getString(_pendingProviderKey);
    _prefs.remove(_pendingProviderKey);
    return p ?? 'email';
  }

  void clearPendingProvider() => _prefs.remove(_pendingProviderKey);

  Future<void> _setRememberMe(bool rememberMe) async {
    if (rememberMe) {
      await _prefs.remove(_ephemeralKey);
    } else {
      await _prefs.setBool(_ephemeralKey, true);
    }
  }

  /// Records a sign-in on the server. The server derives the method from the
  /// JWT and stores at most one row per Auth session.
  Future<void> recordSignIn(String provider) async {
    try {
      await Backend.client.rpc('record_sign_in', params: <String, dynamic>{
        'p_provider': provider,
        'p_app_version': AppConfig.appVersion,
        'p_platform': Backend.platform,
      });
    } catch (_) {
      // Analytics must never block the user.
    }
  }

  Future<void> logout() async {
    await _prefs.remove(_ephemeralKey);
    try {
      await _auth.signOut();
    } catch (_) {
      // Offline: supabase_flutter still clears the local session.
      await _auth.signOut(scope: SignOutScope.local);
    }
  }

  Future<AuthResult> sendPasswordReset(String email) async {
    try {
      await _auth.resetPasswordForEmail(
        email.trim().toLowerCase(),
        redirectTo: AppConfig.authRedirectUrl,
      );
      return const AuthResult(true, null);
    } catch (e) {
      return AuthResult(false, friendlyBackendError(e));
    }
  }

  /// Deletes the account and all associated data via the `delete-account`
  /// Edge Function (which uses the service role on the server).
  Future<AuthResult> deleteAccount() async {
    try {
      final FunctionResponse res = await Backend.client.functions.invoke('delete-account');
      if (res.status >= 200 && res.status < 300) {
        await _auth.signOut(scope: SignOutScope.local);
        return const AuthResult(true, null);
      }
      return AuthResult(false, 'Account deletion failed (${res.status}).');
    } catch (e) {
      return AuthResult(false, friendlyBackendError(e));
    }
  }
}
