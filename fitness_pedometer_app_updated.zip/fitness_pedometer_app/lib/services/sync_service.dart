import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/formatters.dart';
import '../models/activity.dart';
import 'backend.dart';
import 'pedometer_service.dart';

/// Offline-first upload queue for daily totals and GPS session summaries.
///
/// - Everything is first written to a local queue (SharedPreferences), then
///   flushed to Supabase. Failed uploads stay queued and are retried on a
///   timer, on app resume, and after each new item.
/// - Daily totals go through `upsert_daily_activity`, which only ever keeps
///   the larger value per day, so retries and late uploads are safe.
/// - GPS sessions use a client-generated UUID and "insert, ignore
///   duplicates", so a retried upload never creates a second row.
/// - Recently completed sessions are also kept locally (no coordinates) so
///   today's GPS distance shows offline.
class SyncService extends ChangeNotifier {
  SyncService({
    required this.userId,
    required this.prefs,
    required this.pedometer,
  });

  final String userId;
  final SharedPreferences prefs;
  final PedometerService pedometer;

  Timer? _timer;
  bool _flushing = false;
  int _lastQueuedSteps = -1;

  DateTime? lastSyncedAt;
  String? lastError;

  String get _dailyKey => 'sync:daily:$userId';
  String get _sessionsKey => 'sync:sessions:$userId';
  String get _recentKey => 'gps:recent:$userId';

  // ---------------------------------------------------------------- Queue

  Map<String, DailyUpload> _readDaily() {
    final String? raw = prefs.getString(_dailyKey);
    if (raw == null) return <String, DailyUpload>{};
    try {
      final Map<String, dynamic> m = jsonDecode(raw) as Map<String, dynamic>;
      return m.map((String k, dynamic v) =>
          MapEntry<String, DailyUpload>(k, DailyUpload.fromJson(v as Map<String, dynamic>)));
    } catch (_) {
      return <String, DailyUpload>{};
    }
  }

  Future<void> _writeDaily(Map<String, DailyUpload> m) => prefs.setString(
        _dailyKey,
        jsonEncode(m.map((String k, DailyUpload v) => MapEntry<String, dynamic>(k, v.toJson()))),
      );

  List<Map<String, dynamic>> _readSessions(String key) {
    final String? raw = prefs.getString(key);
    if (raw == null) return <Map<String, dynamic>>[];
    try {
      return (jsonDecode(raw) as List<dynamic>).cast<Map<String, dynamic>>();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  int get pendingCount => _readDaily().length + _readSessions(_sessionsKey).length;

  Future<void> queueDaily(DailyUpload upload) async {
    final Map<String, DailyUpload> m = _readDaily();
    final DailyUpload? existing = m[upload.dateKey];
    m[upload.dateKey] = existing == null ? upload : existing.merge(upload);
    await _writeDaily(m);
  }

  /// Snapshot of today's live pedometer total.
  Future<void> queueToday() async {
    if (!pedometer.isCounting) return;
    final int steps = pedometer.todaySteps;
    if (steps == _lastQueuedSteps) return;
    _lastQueuedSteps = steps;
    await queueDaily(DailyUpload(
      dateKey: dateKey(DateTime.now()),
      steps: steps,
      strideDistanceMeters: pedometer.distanceMeters,
      activeMinutes: pedometer.activeMinutes,
      dailyGoal: pedometer.dailyGoal,
    ));
  }

  /// Called by the pedometer when a day ends.
  Future<void> onDayClosed(String date, int steps, int activeMinutes) async {
    await queueDaily(DailyUpload(
      dateKey: date,
      steps: steps,
      strideDistanceMeters: steps * pedometer.strideLengthMeters,
      activeMinutes: activeMinutes,
      dailyGoal: pedometer.dailyGoal,
    ));
    unawaited(flush());
  }

  Future<void> saveSession(GpsSession session) async {
    final Map<String, dynamic> row = session.toRow(userId);
    final List<Map<String, dynamic>> pending = _readSessions(_sessionsKey)..add(row);
    await prefs.setString(_sessionsKey, jsonEncode(pending));
    final List<Map<String, dynamic>> recent = _readSessions(_recentKey)..insert(0, row);
    await prefs.setString(_recentKey, jsonEncode(recent.take(50).toList()));
    notifyListeners();
    unawaited(flush());
  }

  /// Forgets a deleted session locally (pending upload and recent cache).
  Future<void> removeLocalSession(String id) async {
    bool keep(Map<String, dynamic> r) => r['id'] != id;
    await prefs.setString(_sessionsKey, jsonEncode(_readSessions(_sessionsKey).where(keep).toList()));
    await prefs.setString(_recentKey, jsonEncode(_readSessions(_recentKey).where(keep).toList()));
    notifyListeners();
  }

  /// Completed sessions recorded on this device (newest first).
  List<GpsSession> get recentLocalSessions =>
      _readSessions(_recentKey).map(GpsSession.fromRow).toList();

  /// GPS distance from sessions recorded on this device today.
  double get todayGpsMeters {
    final String today = dateKey(DateTime.now());
    return recentLocalSessions
        .where((GpsSession s) =>
            s.activityDateKey == today && s.status == GpsSessionStatus.completed)
        .fold<double>(0, (double sum, GpsSession s) => sum + s.gpsDistanceMeters);
  }

  // ---------------------------------------------------------------- Flush

  void start() {
    _timer ??= Timer.periodic(const Duration(minutes: 2), (_) => syncNow());
    unawaited(syncNow());
  }

  Future<void> syncNow() async {
    await queueToday();
    await flush();
  }

  Future<void> flush() async {
    if (_flushing || !Backend.isInitialized) return;
    if (Backend.client.auth.currentUser?.id != userId) return;
    _flushing = true;
    String? error;
    try {
      // Daily totals.
      final Map<String, DailyUpload> daily = _readDaily();
      for (final DailyUpload u in daily.values.toList()) {
        try {
          await Backend.client.rpc('upsert_daily_activity', params: u.toRpcParams());
          final Map<String, DailyUpload> latest = _readDaily();
          // Only drop the entry if nothing newer was queued meanwhile.
          final DailyUpload? now = latest[u.dateKey];
          if (now != null && now.steps <= u.steps) {
            latest.remove(u.dateKey);
            await _writeDaily(latest);
          }
        } on PostgrestException catch (e) {
          if (e.code == '22023' || e.code == '23514') {
            // Out of range / check violation — retrying won't help.
            final Map<String, DailyUpload> latest = _readDaily()..remove(u.dateKey);
            await _writeDaily(latest);
          } else {
            error = friendlyBackendError(e);
          }
        }
      }

      // GPS sessions.
      // Ids uploaded or permanently rejected. The queue is re-read at the end
      // so sessions added or deleted while uploading aren't lost or revived.
      final Set<Object?> done = <Object?>{};
      try {
        for (final Map<String, dynamic> row in _readSessions(_sessionsKey)) {
          try {
            await Backend.client
                .from('gps_sessions')
                .upsert(row, onConflict: 'id', ignoreDuplicates: true);
            done.add(row['id']);
          } on PostgrestException catch (e) {
            // A check-constraint violation (23514) will never succeed; drop it.
            if (e.code == '23514') {
              done.add(row['id']);
            } else {
              error = friendlyBackendError(e);
            }
          }
        }
      } finally {
        if (done.isNotEmpty) {
          await prefs.setString(
            _sessionsKey,
            jsonEncode(_readSessions(_sessionsKey)
                .where((Map<String, dynamic> r) => !done.contains(r['id']))
                .toList()),
          );
        }
      }
      if (error == null) lastSyncedAt = DateTime.now();
    } catch (e) {
      error = friendlyBackendError(e);
    } finally {
      lastError = error;
      _flushing = false;
      if (!_disposed) notifyListeners();
    }
  }

  bool _disposed = false;

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    super.dispose();
  }
}
