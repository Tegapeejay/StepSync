import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/formatters.dart';
import '../core/theme.dart';

enum PermissionState { unknown, granted, denied, permanentlyDenied }

enum SensorState { unknown, available, unavailable }

enum WalkStatus { unknown, walking, stopped }

/// Final totals for a calendar day that has ended (sent to the sync queue).
typedef DayClosedCallback = void Function(
  String dateKey,
  int steps,
  int activeMinutes,
);

/// The heart of the app: subscribes to the pedometer streams, keeps today's
/// step total (using a persisted daily baseline), and exposes derived values
/// such as distance and goal progress. It is a [ChangeNotifier] so any number
/// of screens can rebuild via [ListenableBuilder] without extra packages.
///
/// Unchanged from the original app except that storage keys use the Supabase
/// user id, it reports the final total when a day ends, and it measures
/// "active minutes" from the walking/stopped status.
class PedometerService extends ChangeNotifier {
  final String userId;
  final SharedPreferences prefs;
  DayClosedCallback? onDayClosed;

  StreamSubscription<StepCount>? _stepSubscription;
  StreamSubscription<PedestrianStatus>? _statusSubscription;

  bool loading = true;
  PermissionState permission = PermissionState.unknown;
  SensorState sensor = SensorState.unknown;
  WalkStatus walkStatus = WalkStatus.unknown;
  String? errorMessage;

  int todaySteps = 0;

  int _baselineSteps = 0;
  String _baselineDate = '';
  bool _hasBaseline = false;

  // Active time: seconds spent in the "walking" status today.
  int _activeSecondsToday = 0;
  DateTime? _walkingSince;

  // Distance / goal inputs, kept in sync with the profile.
  double strideLengthMeters = kFallbackStrideMeters;
  int dailyGoal = kDefaultDailyGoal;

  PedometerService({
    required this.userId,
    required this.prefs,
    required this.strideLengthMeters,
    required this.dailyGoal,
    this.onDayClosed,
  });

  // -- Derived values --------------------------------------------------------

  double get distanceMeters => todaySteps * strideLengthMeters;
  double get distanceKm => distanceMeters / 1000.0;
  double get distanceMiles => distanceKm * 0.621371;

  double get goalProgress {
    if (dailyGoal <= 0) return 0.0;
    return todaySteps / dailyGoal;
  }

  /// Clamped to 0..1 so the progress ring can never visually break, even if
  /// the user walks well past their goal.
  double get goalProgressClamped => goalProgress.clamp(0.0, 1.0);

  int get goalPercent => (goalProgress * 100).round();

  bool get goalReached => todaySteps >= dailyGoal && dailyGoal > 0;

  /// Minutes in the "walking" state today, including the current stretch.
  int get activeMinutes {
    int seconds = _activeSecondsToday;
    final DateTime? since = _walkingSince;
    if (since != null) {
      seconds += _cappedSeconds(DateTime.now().difference(since));
    }
    return seconds ~/ 60;
  }

  bool get isCounting => permission == PermissionState.granted && sensor != SensorState.unavailable;

  String get _todayKey => dateKey(DateTime.now());

  String _baselineStepsKey() => 'ped:baseline:$userId';
  String _baselineDateKey() => 'ped:baselineDate:$userId';
  String _todayStepsKey() => 'ped:today:$userId';
  String _todayDateKey() => 'ped:todayDate:$userId';
  String _activeKey() => 'ped:activeSec:$userId';

  // -- Lifecycle -------------------------------------------------------------

  Future<void> init() async {
    loading = true;
    notifyListeners();

    _loadPersisted();
    await _checkAndRequestPermission();

    if (permission == PermissionState.granted) {
      _startStreams();
    }

    loading = false;
    notifyListeners();
  }

  void _loadPersisted() {
    _baselineSteps = prefs.getInt(_baselineStepsKey()) ?? 0;
    _baselineDate = prefs.getString(_baselineDateKey()) ?? '';
    _hasBaseline = prefs.containsKey(_baselineStepsKey());

    final String storedTodayDate = prefs.getString(_todayDateKey()) ?? '';
    final int storedSteps = prefs.getInt(_todayStepsKey()) ?? 0;
    final int storedActive = prefs.getInt(_activeKey()) ?? 0;
    if (storedTodayDate == _todayKey) {
      todaySteps = storedSteps;
      _activeSecondsToday = storedActive;
    } else {
      // A new day since the last run: hand the previous day's final total to
      // the sync layer, then show 0 until the first sensor event recomputes
      // the baseline.
      if (storedTodayDate.isNotEmpty && storedSteps > 0) {
        onDayClosed?.call(storedTodayDate, storedSteps, storedActive ~/ 60);
      }
      todaySteps = 0;
      _activeSecondsToday = 0;
    }
  }

  Future<void> _checkAndRequestPermission() async {
    try {
      PermissionStatus status = await Permission.activityRecognition.status;
      if (status.isGranted) {
        permission = PermissionState.granted;
        return;
      }
      if (status.isPermanentlyDenied) {
        permission = PermissionState.permanentlyDenied;
        return;
      }
      status = await Permission.activityRecognition.request();
      if (status.isGranted) {
        permission = PermissionState.granted;
      } else if (status.isPermanentlyDenied) {
        permission = PermissionState.permanentlyDenied;
      } else {
        permission = PermissionState.denied;
      }
    } catch (_) {
      // Some platforms/OS versions do not gate this permission at runtime.
      // Fall through and let the sensor streams tell us whether it works.
      permission = PermissionState.granted;
    }
  }

  /// Called from the "Grant Permission" button.
  Future<void> requestPermission() async {
    try {
      final PermissionStatus current = await Permission.activityRecognition.status;
      if (current.isPermanentlyDenied) {
        await openAppSettings();
        return;
      }
      final PermissionStatus result = await Permission.activityRecognition.request();
      if (result.isGranted) {
        permission = PermissionState.granted;
        _startStreams();
      } else if (result.isPermanentlyDenied) {
        permission = PermissionState.permanentlyDenied;
      } else {
        permission = PermissionState.denied;
      }
    } catch (e) {
      errorMessage = 'Could not request permission.';
    }
    notifyListeners();
  }

  void _startStreams() {
    if (_disposed || _stepSubscription != null) return; // avoid duplicate subscriptions
    errorMessage = null;
    _stepSubscription = Pedometer.stepCountStream.listen(
      _onStepCount,
      onError: _onStepError,
      cancelOnError: false,
    );
    _statusSubscription = Pedometer.pedestrianStatusStream.listen(
      _onPedestrianStatus,
      onError: _onStatusError,
      cancelOnError: false,
    );
  }

  void _onStepCount(StepCount event) {
    sensor = SensorState.available;
    final int cumulative = event.steps;
    final String today = _todayKey;

    final bool newDay = _baselineDate != today;
    final bool sensorReset = cumulative < _baselineSteps; // e.g. after reboot

    if (newDay) {
      // The app stayed open across midnight: close yesterday first.
      final String lastDate = prefs.getString(_todayDateKey()) ?? '';
      if (lastDate.isNotEmpty && lastDate != today && todaySteps > 0) {
        onDayClosed?.call(lastDate, todaySteps, activeMinutes);
      }
      _activeSecondsToday = 0;
      if (_walkingSince != null) _walkingSince = DateTime.now();
    }

    if (!_hasBaseline || newDay || sensorReset) {
      // After a reboot mid-day keep what was already counted today.
      final int carried = (sensorReset && !newDay) ? todaySteps : 0;
      _baselineSteps = cumulative - carried;
      _baselineDate = today;
      _hasBaseline = true;
      _persistBaseline();
    }

    int computed = cumulative - _baselineSteps;
    if (computed < 0) computed = 0;
    todaySteps = computed;
    _persistToday();
    notifyListeners();
  }

  void _onStepError(Object error) {
    // The step-count stream failing almost always means the device lacks a
    // usable step-counter sensor (common on emulators).
    sensor = SensorState.unavailable;
    errorMessage = 'Step counter unavailable on this device.';
    notifyListeners();
  }

  void _onPedestrianStatus(PedestrianStatus event) {
    final WalkStatus next;
    switch (event.status) {
      case 'walking':
        next = WalkStatus.walking;
        break;
      case 'stopped':
        next = WalkStatus.stopped;
        break;
      default:
        next = WalkStatus.unknown;
    }
    _trackActiveTime(next);
    walkStatus = next;
    notifyListeners();
  }

  void _trackActiveTime(WalkStatus next) {
    final DateTime now = DateTime.now();
    if (next == WalkStatus.walking) {
      _walkingSince ??= now;
      return;
    }
    final DateTime? since = _walkingSince;
    if (since != null) {
      _activeSecondsToday += _cappedSeconds(now.difference(since));
      _walkingSince = null;
      prefs.setInt(_activeKey(), _activeSecondsToday);
    }
  }

  /// One "walking" stretch counts for at most 3 hours, so a missed "stopped"
  /// event can't inflate active time.
  static int _cappedSeconds(Duration d) {
    final int s = d.inSeconds;
    if (s < 0) return 0;
    return s > 3 * 3600 ? 3 * 3600 : s;
  }

  void _onStatusError(Object error) {
    // Losing the pedestrian-status stream should not take down step counting.
    _trackActiveTime(WalkStatus.unknown);
    walkStatus = WalkStatus.unknown;
    notifyListeners();
  }

  Future<void> _persistBaseline() async {
    await prefs.setInt(_baselineStepsKey(), _baselineSteps);
    await prefs.setString(_baselineDateKey(), _baselineDate);
  }

  Future<void> _persistToday() async {
    await prefs.setInt(_todayStepsKey(), todaySteps);
    await prefs.setString(_todayDateKey(), _todayKey);
    await prefs.setInt(_activeKey(), _activeSecondsToday);
  }

  /// Applies updated profile-derived values (called after the user edits their
  /// height, stride, or goal on the Profile screen).
  void applyProfile({required double strideMeters, required int goal}) {
    strideLengthMeters = strideMeters > 0 ? strideMeters : kFallbackStrideMeters;
    dailyGoal = goal > 0 ? goal : kDefaultDailyGoal;
    notifyListeners();
  }

  /// Retries after a sensor error (used by the "Try again" button).
  Future<void> retry() async {
    errorMessage = null;
    sensor = SensorState.unknown;
    await _stepSubscription?.cancel();
    await _statusSubscription?.cancel();
    _stepSubscription = null;
    _statusSubscription = null;
    if (permission == PermissionState.granted) {
      _startStreams();
    }
    notifyListeners();
  }

  bool _disposed = false;

  // init() and requestPermission() can finish after sign-out disposed us.
  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _trackActiveTime(WalkStatus.unknown);
    _stepSubscription?.cancel();
    _statusSubscription?.cancel();
    _stepSubscription = null;
    _statusSubscription = null;
    super.dispose();
  }
}
