import 'dart:async';
import 'dart:convert';

import 'package:audio_session/audio_session.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

enum MusicProvider { spotify, youtube, youtubeMusic, local }

extension MusicProviderLabel on MusicProvider {
  String get label => switch (this) {
        MusicProvider.spotify => 'Spotify',
        MusicProvider.youtube => 'YouTube',
        MusicProvider.youtubeMusic => 'YouTube Music',
        MusicProvider.local => 'On this phone',
      };
}

/// A playlist / video / search the user can open in the provider's app.
class MusicLink {
  const MusicLink({
    required this.provider,
    required this.title,
    required this.url,
    this.openedAt,
  });

  final MusicProvider provider;
  final String title;
  final String url;
  final DateTime? openedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'p': provider.name,
        't': title,
        'u': url,
        'o': openedAt?.toIso8601String(),
      };

  factory MusicLink.fromJson(Map<String, dynamic> j) => MusicLink(
        provider: MusicProvider.values.asNameMap()[j['p']] ?? MusicProvider.youtube,
        title: j['t'] as String? ?? '',
        url: j['u'] as String,
        openedAt: j['o'] == null ? null : DateTime.tryParse(j['o'] as String),
      );

  MusicLink opened(DateTime when) =>
      MusicLink(provider: provider, title: title, url: url, openedAt: when);
}

/// Built-in workout shortcuts. These are ordinary public search links —
/// nothing is scraped, downloaded or played inside this app.
const List<MusicLink> kWorkoutShortcuts = <MusicLink>[
  MusicLink(
    provider: MusicProvider.spotify,
    title: 'Workout playlists',
    url: 'https://open.spotify.com/search/workout%20playlist',
  ),
  MusicLink(
    provider: MusicProvider.spotify,
    title: 'Running mixes',
    url: 'https://open.spotify.com/search/running%20mix',
  ),
  MusicLink(
    provider: MusicProvider.youtubeMusic,
    title: 'Workout music',
    url: 'https://music.youtube.com/search?q=workout+music',
  ),
  MusicLink(
    provider: MusicProvider.youtube,
    title: 'Walking music',
    url: 'https://www.youtube.com/results?search_query=walking+workout+music',
  ),
];

/// Validates a user-pasted link and works out which provider it belongs to.
/// Returns null for anything that isn't a Spotify or YouTube URL.
MusicProvider? providerForUrl(String input) {
  final String url = input.trim();
  if (url.startsWith('spotify:')) return MusicProvider.spotify;
  final Uri? uri = Uri.tryParse(url);
  if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) return null;
  final String host = uri.host.toLowerCase();
  if (host == 'open.spotify.com' || host == 'spotify.link') return MusicProvider.spotify;
  if (host == 'music.youtube.com') return MusicProvider.youtubeMusic;
  if (host == 'youtu.be' || host == 'youtube.com' || host.endsWith('.youtube.com')) {
    return MusicProvider.youtube;
  }
  return null;
}

/// Opens music in the provider's own app (or the browser as a fallback) and
/// remembers recently opened / saved links on this device.
///
/// Playback for Spotify and YouTube happens in THEIR apps; this app does not
/// control or embed it. Opening another app never stops step counting, which
/// runs from the phone's sensor.
class MusicService extends ChangeNotifier {
  MusicService({required this.prefs, required this.userId});

  final SharedPreferences prefs;
  final String userId;

  String get _recentKey => 'music:recent:$userId';
  String get _savedKey => 'music:saved:$userId';

  List<MusicLink> _read(String key) {
    final String? raw = prefs.getString(key);
    if (raw == null) return <MusicLink>[];
    try {
      return (jsonDecode(raw) as List<dynamic>)
          .map((dynamic e) => MusicLink.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return <MusicLink>[];
    }
  }

  Future<void> _write(String key, List<MusicLink> links) =>
      prefs.setString(key, jsonEncode(links.map((MusicLink l) => l.toJson()).toList()));

  List<MusicLink> get recent => _read(_recentKey);
  List<MusicLink> get saved => _read(_savedKey);

  Future<void> saveLink(MusicLink link) async {
    final List<MusicLink> list = saved..removeWhere((MusicLink l) => l.url == link.url);
    list.insert(0, link);
    await _write(_savedKey, list.take(30).toList());
    notifyListeners();
  }

  Future<void> removeSaved(MusicLink link) async {
    await _write(_savedKey, saved..removeWhere((MusicLink l) => l.url == link.url));
    notifyListeners();
  }

  Future<void> clearRecent() async {
    await prefs.remove(_recentKey);
    notifyListeners();
  }

  /// Opens the link. Returns false if no app or browser could handle it.
  Future<bool> open(MusicLink link) async {
    final List<Uri> candidates = <Uri>[];
    final Uri? uri = Uri.tryParse(link.url);
    if (uri == null) return false;
    candidates.add(uri);
    // spotify: URIs need the Spotify app; fall back to the web player.
    if (uri.scheme == 'spotify') {
      final List<String> parts = uri.path.split(':');
      if (parts.length >= 2) {
        candidates.add(Uri.parse('https://open.spotify.com/${parts[0]}/${parts[1]}'));
      }
    }
    bool ok = false;
    for (final Uri u in candidates) {
      try {
        ok = await launchUrl(u, mode: LaunchMode.externalApplication);
      } catch (_) {
        ok = false;
      }
      if (ok) break;
    }
    if (ok) {
      final List<MusicLink> list = recent..removeWhere((MusicLink l) => l.url == link.url);
      list.insert(0, link.opened(DateTime.now()));
      await _write(_recentKey, list.take(10).toList());
      notifyListeners();
    }
    return ok;
  }
}

/// Plays audio files the user picks from their device (they choose the file
/// through the system picker, so no storage permission is needed).
///
/// Audio focus and interruptions are handled by `audio_session`: calls and
/// other apps pause playback, and unplugging headphones pauses it. Playback
/// stops when the app is closed — there is no background media service.
class LocalAudioPlayer extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<PlayerState>? _stateSub;
  StreamSubscription<Duration>? _posSub;
  StreamSubscription<void>? _noisySub;

  String? trackName;
  String? error;
  bool _sessionReady = false;

  bool get playing => _player.playing;
  Duration get position => _player.position;
  Duration? get duration => _player.duration;
  bool get hasTrack => trackName != null;

  Future<void> _ensureSession() async {
    if (_sessionReady) return;
    final AudioSession session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
    _noisySub = session.becomingNoisyEventStream.listen((_) => _player.pause());
    _stateSub = _player.playerStateStream.listen((_) => notifyListeners());
    _posSub = _player.positionStream.listen((_) => notifyListeners());
    _sessionReady = true;
  }

  Future<void> pickAndPlay() async {
    error = null;
    try {
      final FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.audio);
      final String? path = result?.files.single.path;
      if (path == null) return; // cancelled
      await _ensureSession();
      await _player.setFilePath(path);
      trackName = result!.files.single.name;
      notifyListeners();
      // play() completes only when playback pauses/ends, so don't await it.
      unawaited(_player.play());
    } catch (e) {
      error = 'That file could not be played.';
      notifyListeners();
    }
  }

  Future<void> togglePlay() async {
    if (!hasTrack) return;
    if (_player.playing) {
      await _player.pause();
    } else {
      unawaited(_player.play());
    }
  }

  Future<void> seek(Duration d) => _player.seek(d);

  Future<void> stop() async {
    await _player.stop();
    trackName = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _stateSub?.cancel();
    _posSub?.cancel();
    _noisySub?.cancel();
    _player.dispose();
    super.dispose();
  }
}
