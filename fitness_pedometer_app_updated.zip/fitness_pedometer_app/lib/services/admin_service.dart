import 'backend.dart';

class AdminUserRow {
  const AdminUserRow({
    required this.id,
    required this.name,
    required this.email,
    required this.createdAt,
    required this.lastSignInAt,
    required this.providers,
    required this.status,
  });

  final String id;
  final String name;
  final String email;
  final DateTime? createdAt;
  final DateTime? lastSignInAt;
  final String providers;
  final String status;

  factory AdminUserRow.fromRow(Map<String, dynamic> r) => AdminUserRow(
        id: r['user_id'] as String,
        name: r['full_name'] as String? ?? '',
        email: r['email'] as String? ?? '',
        createdAt: _ts(r['created_at']),
        lastSignInAt: _ts(r['last_sign_in_at']),
        providers: r['providers'] as String? ?? '',
        status: r['account_status'] as String? ?? 'active',
      );

  static DateTime? _ts(Object? v) => v is String ? DateTime.tryParse(v)?.toLocal() : null;
}

class AdminUserPage {
  const AdminUserPage(this.rows, this.total);
  final List<AdminUserRow> rows;
  final int total;
}

class DailySignIns {
  const DailySignIns(this.day, this.signIns, this.uniqueUsers);
  final DateTime day;
  final int signIns;
  final int uniqueUsers;
}

/// Admin data access. Every call is authorised on the SERVER (`is_admin()`
/// inside each SECURITY DEFINER function, or the Edge Function's own check).
/// Hiding the Admin tab in the UI is only a convenience, not the protection.
class AdminService {
  Future<bool> isAdmin() async {
    try {
      final dynamic res = await Backend.client.rpc('is_admin');
      return res == true;
    } catch (_) {
      return false;
    }
  }

  Future<Map<String, dynamic>> dashboardStats() async {
    final dynamic res = await Backend.client.rpc('admin_dashboard_stats');
    return Map<String, dynamic>.from(res as Map);
  }

  Future<List<DailySignIns>> signInsDaily({int days = 30}) async {
    final dynamic res =
        await Backend.client.rpc('admin_sign_ins_daily', params: <String, dynamic>{'p_days': days});
    return (res as List<dynamic>).map((dynamic r) {
      final Map<String, dynamic> m = Map<String, dynamic>.from(r as Map);
      return DailySignIns(
        DateTime.parse(m['day'] as String),
        (m['sign_ins'] as num).toInt(),
        (m['unique_users'] as num).toInt(),
      );
    }).toList();
  }

  Future<AdminUserPage> listUsers({String? search, int page = 0, int pageSize = 25}) async {
    final dynamic res = await Backend.client.rpc('admin_list_users', params: <String, dynamic>{
      'p_search': (search == null || search.trim().isEmpty) ? null : search.trim(),
      'p_limit': pageSize,
      'p_offset': page * pageSize,
    });
    final List<Map<String, dynamic>> rows =
        (res as List<dynamic>).map((dynamic r) => Map<String, dynamic>.from(r as Map)).toList();
    final int total = rows.isEmpty ? 0 : (rows.first['total_count'] as num).toInt();
    return AdminUserPage(rows.map(AdminUserRow.fromRow).toList(), total);
  }

  /// Suspends or reactivates an account through the `admin-set-user-status`
  /// Edge Function, which re-checks admin rights and uses the service role
  /// server-side to ban/unban the Auth user.
  Future<void> setUserStatus(String userId, {required bool suspended}) async {
    await Backend.client.functions.invoke(
      'admin-set-user-status',
      body: <String, dynamic>{'user_id': userId, 'suspended': suspended},
    );
  }
}
