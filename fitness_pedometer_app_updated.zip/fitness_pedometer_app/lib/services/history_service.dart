import '../core/formatters.dart';
import '../models/activity.dart';
import 'backend.dart';

/// Read-only access to the signed-in user's history. RLS guarantees only the
/// caller's own rows are returned; the explicit `user_id` filter keeps the
/// queries index-friendly.
class HistoryService {
  HistoryService(this.userId);

  final String userId;

  Future<List<DailyActivity>> dailyRange(DateTime from, DateTime to) async {
    final List<Map<String, dynamic>> rows = await Backend.client
        .from('daily_activity')
        .select()
        .eq('user_id', userId)
        .gte('activity_date', dateKey(from))
        .lte('activity_date', dateKey(to))
        .order('activity_date', ascending: true);
    return rows.map(DailyActivity.fromRow).toList();
  }

  Future<List<GpsSession>> sessions({int limit = 50}) async {
    final List<Map<String, dynamic>> rows = await Backend.client
        .from('gps_sessions')
        .select()
        .eq('user_id', userId)
        .eq('status', 'completed')
        .order('started_at', ascending: false)
        .limit(limit);
    return rows.map(GpsSession.fromRow).toList();
  }

  Future<void> deleteSession(String id) async {
    await Backend.client.from('gps_sessions').delete().eq('id', id).eq('user_id', userId);
  }
}
