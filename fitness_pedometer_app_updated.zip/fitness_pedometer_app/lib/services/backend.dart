import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

/// The single place Supabase is initialised and accessed.
class Backend {
  Backend._();

  static bool _initialized = false;
  static bool get isInitialized => _initialized;

  static Future<void> initialize() async {
    if (_initialized) return;
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabasePublishableKey,
      authOptions: const FlutterAuthClientOptions(
        // PKCE: the browser returns a one-time code to the deep link; tokens
        // never appear in the redirect URL.
        authFlowType: AuthFlowType.pkce,
      ),
      debug: false, // never log auth traffic
    );
    _initialized = true;
  }

  static SupabaseClient get client => Supabase.instance.client;

  static String get platform {
    if (kIsWeb) return 'web';
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return 'android';
      case TargetPlatform.iOS:
        return 'ios';
      default:
        return 'other';
    }
  }
}

/// Turns Supabase / network errors into short, user-facing messages without
/// leaking tokens or server internals.
String friendlyBackendError(Object error) {
  if (error is AuthException) {
    final String msg = error.message.toLowerCase();
    if (msg.contains('invalid login credentials')) {
      return 'Incorrect email or password.';
    }
    if (msg.contains('email not confirmed')) {
      return 'Please confirm your email address first — check your inbox.';
    }
    if (msg.contains('already registered') || msg.contains('already been registered')) {
      return 'An account with this email already exists.';
    }
    if (msg.contains('password')) {
      return error.message;
    }
    if (msg.contains('rate limit') || error.statusCode == '429') {
      return 'Too many attempts. Please wait a minute and try again.';
    }
    return error.message;
  }
  if (error is PostgrestException) {
    if (error.code == '42501') return 'You are not allowed to do that.';
    return 'The server rejected the request. Please try again.';
  }
  if (error is FunctionException) {
    return 'The server could not complete the request (${error.status}).';
  }
  final String text = error.toString().toLowerCase();
  if (text.contains('socket') || text.contains('network') || text.contains('timed out') ||
      text.contains('failed host lookup') || text.contains('clientexception')) {
    return 'No connection. Check your internet and try again.';
  }
  return 'Something went wrong. Please try again.';
}
