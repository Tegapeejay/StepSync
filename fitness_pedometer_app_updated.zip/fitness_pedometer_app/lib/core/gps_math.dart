import 'dart:math' as math;

/// One location fix, decoupled from the geolocator plugin so the filtering
/// logic can be unit tested.
class GpsFix {
  const GpsFix({
    required this.latitude,
    required this.longitude,
    required this.accuracyMeters,
    required this.timestamp,
  });

  final double latitude;
  final double longitude;

  /// Horizontal accuracy radius reported by the OS (68% confidence).
  final double accuracyMeters;
  final DateTime timestamp;
}

/// Great-circle distance in metres (haversine).
double haversineMeters(double lat1, double lon1, double lat2, double lon2) {
  const double earthRadius = 6371000.0;
  double rad(double deg) => deg * math.pi / 180.0;
  final double dLat = rad(lat2 - lat1);
  final double dLon = rad(lon2 - lon1);
  final double a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(rad(lat1)) * math.cos(rad(lat2)) * math.sin(dLon / 2) * math.sin(dLon / 2);
  return 2 * earthRadius * math.asin(math.min(1.0, math.sqrt(a)));
}

enum FixDecision {
  /// First good fix: becomes the anchor, adds no distance.
  anchored,

  /// Distance from the previous accepted fix was added.
  accepted,

  /// Fix too inaccurate to use.
  rejectedInaccurate,

  /// Movement smaller than the noise floor; ignored to avoid accumulating
  /// jitter while standing still.
  ignoredJitter,

  /// Implausible jump (implied speed too high).
  rejectedJump,

  /// Out-of-order or duplicate timestamp.
  rejectedStale,
}

/// Accumulates GPS distance from successive fixes while filtering noise.
///
/// Rules (tuned for walking / running):
/// - Fixes worse than [maxAccuracyMeters] are dropped.
/// - Movement below the combined accuracy of the two fixes (min
///   [minStepMeters]) is treated as jitter: the anchor is kept, so slow real
///   movement still accumulates once it exceeds the noise floor.
/// - A segment implying more than [maxSpeedMps] is a jump and is dropped.
/// - After a signal gap longer than [gapThreshold], the next good fix
///   re-anchors without adding the straight-line gap distance (we don't know
///   the path taken), unless the implied speed is plausible.
class GpsDistanceAccumulator {
  GpsDistanceAccumulator({
    this.maxAccuracyMeters = 25,
    this.minStepMeters = 3,
    this.maxSpeedMps = 12, // ~43 km/h — well above sprinting
    this.gapThreshold = const Duration(seconds: 30),
  });

  final double maxAccuracyMeters;
  final double minStepMeters;
  final double maxSpeedMps;
  final Duration gapThreshold;

  GpsFix? _anchor;
  double _totalMeters = 0;
  int acceptedCount = 0;
  int rejectedCount = 0;

  double get totalMeters => _totalMeters;
  GpsFix? get lastFix => _anchor;

  void reset() {
    _anchor = null;
    _totalMeters = 0;
    acceptedCount = 0;
    rejectedCount = 0;
  }

  FixDecision add(GpsFix fix) {
    if (fix.accuracyMeters.isNaN ||
        fix.accuracyMeters <= 0 ||
        fix.accuracyMeters > maxAccuracyMeters) {
      rejectedCount++;
      return FixDecision.rejectedInaccurate;
    }
    final GpsFix? prev = _anchor;
    if (prev == null) {
      _anchor = fix;
      return FixDecision.anchored;
    }
    final Duration dt = fix.timestamp.difference(prev.timestamp);
    if (dt <= Duration.zero) {
      rejectedCount++;
      return FixDecision.rejectedStale;
    }

    final double d = haversineMeters(
      prev.latitude,
      prev.longitude,
      fix.latitude,
      fix.longitude,
    );
    final double seconds = dt.inMilliseconds / 1000.0;
    final double speed = d / seconds;

    if (speed > maxSpeedMps) {
      if (dt > gapThreshold) {
        // Long signal loss and we can't trust the straight line: restart
        // from here without adding the gap.
        _anchor = fix;
        return FixDecision.anchored;
      }
      rejectedCount++;
      return FixDecision.rejectedJump;
    }

    final double noiseFloor =
        math.max(minStepMeters, (prev.accuracyMeters + fix.accuracyMeters) / 2);
    if (d < noiseFloor) {
      return FixDecision.ignoredJitter;
    }

    _totalMeters += d;
    _anchor = fix;
    acceptedCount++;
    return FixDecision.accepted;
  }
}
