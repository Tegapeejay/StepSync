import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFF121212);
  static const Color surface = Color(0xFF1C1C1E);
  static const Color surfaceAlt = Color(0xFF242426);
  static const Color surfaceHigh = Color(0xFF2A2A2D);
  static const Color accent = Color(0xFF00E5A0); // mint
  static const Color accentSoft = Color(0xFF00B382);
  static const Color info = Color(0xFF4F8CFF); // blue for distance
  static const Color gps = Color(0xFFB388FF); // violet for GPS distance
  static const Color warning = Color(0xFFFFB300);
  static const Color danger = Color(0xFFFF5252);
  static const Color textPrimary = Color(0xFFF5F5F7);
  static const Color textSecondary = Color(0xFFB5B5BC);
  static const Color textMuted = Color(0xFF7C7C85);
}

const int kDefaultDailyGoal = 10000;
const double kFallbackStrideMeters = 0.75;

ThemeData buildAppTheme() {
  const ColorScheme scheme = ColorScheme.dark(
    primary: AppColors.accent,
    secondary: AppColors.info,
    surface: AppColors.surface,
    error: AppColors.danger,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.background,
    colorScheme: scheme,
    fontFamily: 'Roboto',
    splashColor: AppColors.accent.withValues(alpha: 0.12),
    highlightColor: Colors.transparent,
  );
}
