/// Compares the stride-based estimate with the GPS-recorded distance for the
/// SAME activity period (one GPS session and the steps counted during it).
///
///   Absolute difference  = |stride − GPS|
///   Difference %         = absolute difference / GPS × 100
///
/// When GPS distance is zero the percentage is undefined, so it is `null`.
class DistanceComparison {
  const DistanceComparison({
    required this.strideMeters,
    required this.gpsMeters,
  });

  final double strideMeters;
  final double gpsMeters;

  double get absoluteDifferenceMeters => (strideMeters - gpsMeters).abs();

  /// Positive when the stride estimate is longer than the GPS distance.
  double get signedDifferenceMeters => strideMeters - gpsMeters;

  double? get differencePercent {
    if (gpsMeters <= 0) return null;
    return absoluteDifferenceMeters / gpsMeters * 100.0;
  }

  /// A comparison is only meaningful once both sides have measured something.
  bool get isMeaningful => gpsMeters >= 50 && strideMeters > 0;
}

/// Stride distance for a step count, rejecting nonsense inputs.
double strideDistanceMeters(int steps, double strideMeters) {
  if (steps <= 0 || strideMeters <= 0) return 0;
  return steps * strideMeters;
}
