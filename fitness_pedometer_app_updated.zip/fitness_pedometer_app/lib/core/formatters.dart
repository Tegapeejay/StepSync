import 'theme.dart';

/// Formats a non-negative integer with thousands separators, e.g. 10245 -> "10,245".
String formatSteps(int value) {
  if (value < 0) value = 0;
  final String digits = value.toString();
  final StringBuffer buffer = StringBuffer();
  int counter = 0;
  for (int i = digits.length - 1; i >= 0; i--) {
    buffer.write(digits[i]);
    counter++;
    if (counter % 3 == 0 && i != 0) {
      buffer.write(',');
    }
  }
  return buffer.toString().split('').reversed.join();
}

/// Formats a distance in kilometres for display, choosing sensible precision.
String formatKm(double km) {
  if (km >= 10) {
    return km.toStringAsFixed(1);
  }
  return km.toStringAsFixed(2);
}

enum DistanceUnit {
  km,
  mi;

  static DistanceUnit parse(String? value) =>
      value == 'mi' ? DistanceUnit.mi : DistanceUnit.km;

  String get label => this == DistanceUnit.km ? 'km' : 'mi';
}

const double kMetersPerMile = 1609.344;

/// Converts metres to the user's unit and formats it, e.g. "6.20 km".
String formatDistance(double meters, DistanceUnit unit) {
  final double value =
      unit == DistanceUnit.km ? meters / 1000.0 : meters / kMetersPerMile;
  return '${formatKm(value)} ${unit.label}';
}

/// Estimates stride length (in metres) from height and sex.
///
/// Uses commonly cited multipliers of standing height:
///   male   ~ 0.415, female ~ 0.413, unspecified ~ 0.414.
/// Falls back to a reasonable default when height is missing.
double estimateStrideMeters({required double heightCm, required String sex}) {
  double factor;
  switch (sex) {
    case 'male':
      factor = 0.415;
      break;
    case 'female':
      factor = 0.413;
      break;
    default:
      factor = 0.414;
  }
  final double stride = (heightCm * factor) / 100.0;
  if (stride <= 0) {
    return kFallbackStrideMeters;
  }
  return stride;
}

/// The user's LOCAL calendar date as `yyyy-MM-dd`. Every daily record uses
/// this, so "today" means the date shown on the user's phone.
String dateKey(DateTime date) {
  return '${date.year.toString().padLeft(4, '0')}-'
      '${date.month.toString().padLeft(2, '0')}-'
      '${date.day.toString().padLeft(2, '0')}';
}

DateTime parseDateKey(String key) {
  final List<String> p = key.split('-');
  return DateTime(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
}

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

/// Calendar arithmetic (not Duration) so DST changes can't shift the day.
DateTime addDays(DateTime d, int days) => DateTime(d.year, d.month, d.day + days);

DateTime startOfWeek(DateTime d) => DateTime(d.year, d.month, d.day - (d.weekday - 1));

DateTime startOfMonth(DateTime d) => DateTime(d.year, d.month, 1);

DateTime endOfMonth(DateTime d) => DateTime(d.year, d.month + 1, 0);

String formatDuration(Duration d) {
  final int h = d.inHours;
  final int m = d.inMinutes.remainder(60);
  final int s = d.inSeconds.remainder(60);
  String two(int v) => v.toString().padLeft(2, '0');
  return h > 0 ? '$h:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
}

const List<String> kWeekdayShort = <String>['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const List<String> kMonthShort = <String>[
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

/// "Mon 19 Oct"
String formatDayLabel(DateTime d) =>
    '${kWeekdayShort[d.weekday - 1]} ${d.day} ${kMonthShort[d.month - 1]}';
