import 'dart:math';

/// RFC 4122 version-4 UUID from a cryptographically secure RNG.
String uuidV4() {
  final Random rng = Random.secure();
  final List<int> b = List<int>.generate(16, (_) => rng.nextInt(256));
  b[6] = (b[6] & 0x0f) | 0x40; // version 4
  b[8] = (b[8] & 0x3f) | 0x80; // RFC 4122 variant
  String hex(int i) => b[i].toRadixString(16).padLeft(2, '0');
  final String s = List<String>.generate(16, hex).join();
  return '${s.substring(0, 8)}-${s.substring(8, 12)}-${s.substring(12, 16)}-'
      '${s.substring(16, 20)}-${s.substring(20)}';
}
