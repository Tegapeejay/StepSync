import '../models/activity.dart';
import 'formatters.dart';

enum ReportPeriod { day, week, month }

/// Aggregates stored daily records for a date range. Days without a record
/// count as zero steps (we never invent activity) and future days in the
/// range are excluded from averages and goal rates.
class ActivityReport {
  ActivityReport._({
    required this.period,
    required this.from,
    required this.to,
    required this.days,
    required this.elapsedDays,
  });

  final ReportPeriod period;
  final DateTime from;
  final DateTime to;

  /// One entry per calendar day in [from]..[to], in order. Missing days are
  /// `null` (no data recorded).
  final List<MapEntry<DateTime, DailyActivity?>> days;

  /// Days in the range up to and including today.
  final int elapsedDays;

  factory ActivityReport.build({
    required ReportPeriod period,
    required DateTime anchor,
    required List<DailyActivity> records,
    required DateTime today,
  }) {
    final DateTime a = dateOnly(anchor);
    late DateTime from;
    late DateTime to;
    switch (period) {
      case ReportPeriod.day:
        from = a;
        to = a;
        break;
      case ReportPeriod.week:
        from = startOfWeek(a);
        to = addDays(from, 6);
        break;
      case ReportPeriod.month:
        from = startOfMonth(a);
        to = endOfMonth(a);
        break;
    }
    final Map<String, DailyActivity> byKey = <String, DailyActivity>{
      for (final DailyActivity r in records) dateKey(r.date): r,
    };
    final List<MapEntry<DateTime, DailyActivity?>> days = <MapEntry<DateTime, DailyActivity?>>[];
    int elapsed = 0;
    final DateTime t = dateOnly(today);
    for (DateTime d = from; !d.isAfter(to); d = addDays(d, 1)) {
      days.add(MapEntry<DateTime, DailyActivity?>(d, byKey[dateKey(d)]));
      if (!d.isAfter(t)) elapsed++;
    }
    return ActivityReport._(
      period: period,
      from: from,
      to: to,
      days: days,
      elapsedDays: elapsed,
    );
  }

  Iterable<DailyActivity> get _records =>
      days.map((MapEntry<DateTime, DailyActivity?> e) => e.value).whereType<DailyActivity>();

  int get totalSteps => _records.fold<int>(0, (int s, DailyActivity r) => s + r.steps);

  double get totalStrideMeters =>
      _records.fold<double>(0, (double s, DailyActivity r) => s + r.strideDistanceMeters);

  double get totalGpsMeters =>
      _records.fold<double>(0, (double s, DailyActivity r) => s + r.gpsDistanceMeters);

  int get totalActiveMinutes =>
      _records.fold<int>(0, (int s, DailyActivity r) => s + r.activeMinutes);

  /// Average over elapsed days, counting days with no record as zero.
  double get averageDailySteps => elapsedDays == 0 ? 0 : totalSteps / elapsedDays;

  int get goalDays => _records.where((DailyActivity r) => r.goalAchieved).length;

  /// Share of elapsed days on which the goal was met (0..1).
  double get goalRate => elapsedDays == 0 ? 0 : goalDays / elapsedDays;

  int get daysWithActivity => _records.where((DailyActivity r) => r.steps > 0).length;

  /// Day with the most steps (null when nothing was recorded).
  DailyActivity? get bestDay {
    DailyActivity? best;
    for (final DailyActivity r in _records) {
      if (r.steps > 0 && (best == null || r.steps > best.steps)) best = r;
    }
    return best;
  }
}

/// Merges the live on-device total for today over the server copy, keeping
/// the larger values (same rule as the server).
List<DailyActivity> mergeLiveToday(
  List<DailyActivity> records, {
  required DateTime today,
  required int steps,
  required double strideMeters,
  required int activeMinutes,
  required int dailyGoal,
  required double localGpsMeters,
}) {
  final String key = dateKey(today);
  final List<DailyActivity> out = <DailyActivity>[];
  DailyActivity? server;
  for (final DailyActivity r in records) {
    if (dateKey(r.date) == key) {
      server = r;
    } else {
      out.add(r);
    }
  }
  double maxD(double a, double b) => a > b ? a : b;
  int maxI(int a, int b) => a > b ? a : b;
  out.add(DailyActivity(
    date: dateOnly(today),
    steps: maxI(server?.steps ?? 0, steps),
    strideDistanceMeters: maxD(server?.strideDistanceMeters ?? 0, steps * strideMeters),
    gpsDistanceMeters: maxD(server?.gpsDistanceMeters ?? 0, localGpsMeters),
    activeMinutes: maxI(server?.activeMinutes ?? 0, activeMinutes),
    dailyGoal: dailyGoal,
  ));
  out.sort((DailyActivity a, DailyActivity b) => a.date.compareTo(b.date));
  return out;
}
