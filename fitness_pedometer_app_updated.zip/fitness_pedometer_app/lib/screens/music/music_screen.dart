import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/formatters.dart';
import '../../core/theme.dart';
import '../../services/music_service.dart';
import '../../widgets/common.dart';
import '../main_scaffold.dart';

/// Music while you move. Each provider is independent: if one fails (app not
/// installed, link invalid, file unplayable) the rest of the app — including
/// step counting — is unaffected.
class MusicScreen extends StatelessWidget {
  final UserServices services;
  const MusicScreen({super.key, required this.services});

  MusicService get music => services.music;

  Future<void> _open(BuildContext context, MusicLink link) async {
    final bool ok = await music.open(link);
    unawaited(services.analytics.track('music_opened', metadata: <String, Object?>{
      'provider': link.provider.name, // no URL or title is sent
      'ok': ok,
    }));
    if (!ok && context.mounted) {
      showAppSnack(
        context,
        'Couldn\'t open ${link.provider.label}. Is the app or a browser installed?',
        error: true,
      );
    }
  }

  Future<void> _addLink(BuildContext context) async {
    final MusicLink? link = await showModalBottomSheet<MusicLink>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const _AddLinkSheet(),
    );
    if (link != null) await music.saveLink(link);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[music, services.player]),
        builder: (BuildContext context, Widget? _) {
          final List<MusicLink> recent = music.recent;
          final List<MusicLink> saved = music.saved;
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
            children: <Widget>[
              const Text(
                'Music',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 26, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              const Text(
                'Your steps keep counting while music plays in any app.',
                style: TextStyle(color: AppColors.textMuted, fontSize: 14),
              ),
              const SizedBox(height: 20),
              _LocalPlayerCard(player: services.player),
              const SizedBox(height: 22),
              const SectionLabel('Workout shortcuts'),
              for (final MusicLink l in kWorkoutShortcuts)
                _LinkTile(link: l, onTap: () => _open(context, l)),
              const SizedBox(height: 16),
              SectionLabel(
                'My playlists',
                trailing: TextButton.icon(
                  onPressed: () => _addLink(context),
                  icon: const Icon(Icons.add_rounded, size: 18),
                  label: const Text('Add'),
                ),
              ),
              if (saved.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Text(
                    'Paste a Spotify or YouTube playlist / video link to keep it here.',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                  ),
                ),
              for (final MusicLink l in saved)
                _LinkTile(
                  link: l,
                  onTap: () => _open(context, l),
                  onRemove: () => music.removeSaved(l),
                ),
              if (recent.isNotEmpty) ...<Widget>[
                const SizedBox(height: 16),
                SectionLabel(
                  'Recently opened',
                  trailing: TextButton(onPressed: music.clearRecent, child: const Text('Clear')),
                ),
                for (final MusicLink l in recent) _LinkTile(link: l, onTap: () => _open(context, l)),
              ],
              const SizedBox(height: 16),
              const SurfaceCard(
                color: AppColors.surfaceAlt,
                child: Text(
                  'Spotify and YouTube open in their own apps, where their terms, ads and '
                  'subscription rules apply. StepSync does not play, download or control '
                  'their audio. Tap back to return here.',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12, height: 1.4),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _LinkTile extends StatelessWidget {
  final MusicLink link;
  final VoidCallback onTap;
  final VoidCallback? onRemove;
  const _LinkTile({required this.link, required this.onTap, this.onRemove});

  @override
  Widget build(BuildContext context) {
    final (IconData icon, Color color) = switch (link.provider) {
      MusicProvider.spotify => (Icons.music_note_rounded, const Color(0xFF1DB954)),
      MusicProvider.youtube => (Icons.smart_display_rounded, const Color(0xFFFF4E45)),
      MusicProvider.youtubeMusic => (Icons.album_rounded, const Color(0xFFFF4E45)),
      MusicProvider.local => (Icons.audio_file_rounded, AppColors.accent),
    };
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        child: ListTile(
          onTap: onTap,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          leading: CircleAvatar(
            backgroundColor: color.withValues(alpha: 0.15),
            child: Icon(icon, color: color),
          ),
          title: Text(link.title, style: const TextStyle(color: AppColors.textPrimary)),
          subtitle: Text(
            'Open in ${link.provider.label}',
            style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
          ),
          trailing: onRemove == null
              ? const Icon(Icons.open_in_new_rounded, color: AppColors.textMuted, size: 18)
              : IconButton(
                  tooltip: 'Remove',
                  onPressed: onRemove,
                  icon: const Icon(Icons.close_rounded, color: AppColors.textMuted),
                ),
        ),
      ),
    );
  }
}

class _LocalPlayerCard extends StatelessWidget {
  final LocalAudioPlayer player;
  const _LocalPlayerCard({required this.player});

  @override
  Widget build(BuildContext context) {
    final Duration pos = player.position;
    final Duration? dur = player.duration;
    final double max = (dur?.inMilliseconds ?? 0).toDouble();
    return SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Row(
            children: <Widget>[
              Icon(Icons.library_music_rounded, color: AppColors.accent),
              SizedBox(width: 10),
              Text(
                'Music on this phone',
                style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (player.hasTrack) ...<Widget>[
            Text(
              player.trackName!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppColors.textSecondary),
            ),
            Slider(
              value: pos.inMilliseconds.clamp(0, max <= 0 ? 0 : max.toInt()).toDouble(),
              max: max <= 0 ? 1 : max,
              activeColor: AppColors.accent,
              onChanged: max <= 0 ? null : (double v) => player.seek(Duration(milliseconds: v.round())),
            ),
            Row(
              children: <Widget>[
                Text(formatDuration(pos), style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                const Spacer(),
                IconButton(
                  tooltip: 'Stop',
                  onPressed: player.stop,
                  icon: const Icon(Icons.stop_rounded, color: AppColors.textSecondary),
                ),
                IconButton.filled(
                  tooltip: player.playing ? 'Pause' : 'Play',
                  onPressed: player.togglePlay,
                  style: IconButton.styleFrom(backgroundColor: AppColors.accent),
                  icon: Icon(player.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                      color: Colors.black),
                ),
                const Spacer(),
                Text(dur == null ? '--:--' : formatDuration(dur),
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ] else
            const Text(
              'Pick an audio file you have on this phone. It plays here while your steps count.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
            ),
          if (player.error != null) ...<Widget>[
            const SizedBox(height: 8),
            ErrorBanner(message: player.error!),
          ],
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: player.pickAndPlay,
            icon: const Icon(Icons.folder_open_rounded),
            label: Text(player.hasTrack ? 'Choose another file' : 'Choose audio file'),
          ),
        ],
      ),
    );
  }
}

class _AddLinkSheet extends StatefulWidget {
  const _AddLinkSheet();

  @override
  State<_AddLinkSheet> createState() => _AddLinkSheetState();
}

class _AddLinkSheetState extends State<_AddLinkSheet> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _title = TextEditingController();
  final TextEditingController _url = TextEditingController();

  @override
  void dispose() {
    _title.dispose();
    _url.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final MusicProvider provider = providerForUrl(_url.text)!;
    Navigator.of(context).pop(MusicLink(
      provider: provider,
      title: _title.text.trim().isEmpty ? '${provider.label} link' : _title.text.trim(),
      url: _url.text.trim(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.viewInsetsOf(context).bottom),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            const Text(
              'Add a playlist or video',
              style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 16),
            AppTextField(
              controller: _url,
              label: 'Spotify or YouTube link',
              icon: Icons.link_rounded,
              keyboardType: TextInputType.url,
              validator: (String? v) => providerForUrl(v ?? '') == null
                  ? 'Paste an https://open.spotify.com/… or YouTube link.'
                  : null,
            ),
            const SizedBox(height: 12),
            AppTextField(
              controller: _title,
              label: 'Name (optional)',
              icon: Icons.label_outline_rounded,
              validator: (String? v) => (v ?? '').length > 60 ? 'Keep it under 60 characters.' : null,
            ),
            const SizedBox(height: 18),
            PrimaryButton(label: 'Save', onPressed: _save),
          ],
        ),
      ),
    );
  }
}
