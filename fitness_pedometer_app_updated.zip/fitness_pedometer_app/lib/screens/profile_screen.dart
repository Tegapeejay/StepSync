import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/profile.dart';
import '../services/auth_service.dart';
import '../services/backend.dart';
import '../widgets/common.dart';
import 'main_scaffold.dart';

class ProfileScreen extends StatefulWidget {
  final UserServices services;
  final Profile profile;
  final void Function(Profile) onSaved;
  final Future<void> Function() onLogout;

  const ProfileScreen({
    super.key,
    required this.services,
    required this.profile,
    required this.onSaved,
    required this.onLogout,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _heightController;
  late final TextEditingController _strideController;
  late final TextEditingController _goalController;
  late String _sex;
  late DistanceUnit _unit;
  bool _autoStride = true;
  bool _saving = false;

  /// Set once the user edits a field, so a late server refresh doesn't
  /// overwrite their changes.
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _heightController = TextEditingController();
    _strideController = TextEditingController();
    _goalController = TextEditingController();
    _fillFrom(widget.profile);
  }

  @override
  void didUpdateWidget(covariant ProfileScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    // The server copy can arrive after the cached one: refresh the form if
    // the user hasn't started editing.
    if (!identical(oldWidget.profile, widget.profile) && !_saving && !_dirty) {
      _fillFrom(widget.profile);
    }
  }

  void _fillFrom(Profile p) {
    _nameController.text = p.name;
    _heightController.text = p.heightCm.toStringAsFixed(0);
    _sex = p.sex;
    _unit = p.unit;
    _autoStride = p.strideOverride == null;
    _strideController.text = p.effectiveStrideMeters.toStringAsFixed(2);
    _goalController.text = p.dailyGoal.toString();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _heightController.dispose();
    _strideController.dispose();
    _goalController.dispose();
    super.dispose();
  }

  void _recomputeEstimatedStride() {
    if (!_autoStride) return;
    final double? height = double.tryParse(_heightController.text.trim());
    if (height == null || height <= 0) return;
    final double stride = estimateStrideMeters(heightCm: height, sex: _sex);
    _strideController.text = stride.toStringAsFixed(2);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final double height = double.tryParse(_heightController.text.trim()) ?? 170.0;
      final int goal = int.tryParse(_goalController.text.trim()) ?? kDefaultDailyGoal;
      double? strideOverride;
      if (!_autoStride) {
        strideOverride = double.tryParse(_strideController.text.trim());
      }

      final Profile updated = Profile(
        id: widget.profile.id,
        name: _nameController.text.trim(),
        email: widget.profile.email,
        avatarUrl: widget.profile.avatarUrl,
        heightCm: height,
        sex: _sex,
        strideOverride: strideOverride,
        dailyGoal: goal,
        unit: _unit,
      );
      await widget.services.profileService.save(updated);
      _dirty = false;
      widget.onSaved(updated);
      if (!mounted) return;
      showAppSnack(context, 'Profile saved');
    } catch (e) {
      if (!mounted) return;
      showAppSnack(context, 'Could not save profile. ${friendlyBackendError(e)}', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _deleteAccount() async {
    String typed = '';
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Delete account?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'This permanently deletes your account, profile, step history, GPS sessions '
              'and analytics linked to you. It cannot be undone.\n\nType DELETE to confirm.',
            ),
            const SizedBox(height: 12),
            // No controller, so nothing to dispose while the dialog animates out.
            TextField(autofocus: true, onChanged: (String v) => typed = v),
          ],
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, typed.trim() == 'DELETE'),
            style: TextButton.styleFrom(foregroundColor: AppColors.danger),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _saving = true);
    final AuthResult r = await widget.services.auth.deleteAccount();
    if (!mounted) return; // on success AuthGate has already shown sign-in
    setState(() => _saving = false);
    if (!r.success) showAppSnack(context, r.error ?? 'Could not delete the account.', error: true);
  }

  void _showPrivacy() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      builder: (_) => const _PrivacySheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
        child: Form(
          key: _formKey,
          onChanged: () => _dirty = true,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  const Text(
                    'Profile',
                    style: TextStyle(color: AppColors.textPrimary, fontSize: 26, fontWeight: FontWeight.w800),
                  ),
                  IconButton(
                    onPressed: widget.onLogout,
                    icon: const Icon(Icons.logout_rounded, color: AppColors.textMuted),
                    tooltip: 'Sign out',
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Center(
                child: Column(
                  children: <Widget>[
                    Container(
                      height: 84,
                      width: 84,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(colors: <Color>[AppColors.accentSoft, AppColors.accent]),
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        _initials(widget.profile.name),
                        style: const TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w800),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(widget.profile.email, style: const TextStyle(color: AppColors.textMuted)),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const SectionLabel('Account'),
              AppTextField(
                controller: _nameController,
                label: 'Name',
                icon: Icons.person_outline_rounded,
                validator: (String? v) {
                  final String t = (v ?? '').trim();
                  if (t.isEmpty) return 'Name is required.';
                  if (t.length > 80) return 'Name must be 80 characters or fewer.';
                  return null;
                },
              ),
              const SizedBox(height: 22),
              const SectionLabel('Body & distance'),
              AppTextField(
                controller: _heightController,
                label: 'Height (cm)',
                icon: Icons.height_rounded,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                ],
                onChanged: (String _) => setState(_recomputeEstimatedStride),
                validator: (String? v) {
                  final double? h = double.tryParse((v ?? '').trim());
                  if (h == null || h < 80 || h > 250) return 'Enter a height between 80 and 250 cm.';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              _sexSelector(),
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  Checkbox(
                    value: _autoStride,
                    activeColor: AppColors.accent,
                    checkColor: Colors.black,
                    onChanged: (bool? v) {
                      setState(() {
                        _dirty = true;
                        _autoStride = v ?? true;
                        _recomputeEstimatedStride();
                      });
                    },
                  ),
                  const Expanded(
                    child: Text(
                      'Estimate stride length from my height',
                      style: TextStyle(color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
              AppTextField(
                controller: _strideController,
                label: 'Stride length (m)',
                icon: Icons.straighten_rounded,
                enabled: !_autoStride,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                ],
                validator: (String? v) {
                  final double? s = double.tryParse((v ?? '').trim());
                  if (s == null || s < 0.3 || s > 1.5) return 'Enter a stride between 0.3 and 1.5 m.';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              SegmentedButton<DistanceUnit>(
                segments: const <ButtonSegment<DistanceUnit>>[
                  ButtonSegment<DistanceUnit>(value: DistanceUnit.km, label: Text('Kilometres')),
                  ButtonSegment<DistanceUnit>(value: DistanceUnit.mi, label: Text('Miles')),
                ],
                selected: <DistanceUnit>{_unit},
                showSelectedIcon: false,
                onSelectionChanged: (Set<DistanceUnit> s) => setState(() {
                  _dirty = true;
                  _unit = s.first;
                }),
              ),
              const SizedBox(height: 22),
              const SectionLabel('Goal'),
              AppTextField(
                controller: _goalController,
                label: 'Daily step goal',
                icon: Icons.flag_outlined,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
                validator: (String? v) {
                  final int? g = int.tryParse((v ?? '').trim());
                  if (g == null || g < 1000 || g > 100000) return 'Enter a goal between 1,000 and 100,000.';
                  return null;
                },
              ),
              const SizedBox(height: 26),
              PrimaryButton(
                label: 'Save Changes',
                loading: _saving,
                icon: Icons.check_rounded,
                onPressed: _save,
              ),
              const SizedBox(height: 14),
              SizedBox(
                height: 52,
                child: OutlinedButton.icon(
                  onPressed: widget.onLogout,
                  icon: const Icon(Icons.logout_rounded, size: 18),
                  label: const Text('Sign Out'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.danger,
                    side: BorderSide(color: AppColors.danger.withValues(alpha: 0.5)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              const SectionLabel('Privacy'),
              TextButton.icon(
                onPressed: _showPrivacy,
                icon: const Icon(Icons.shield_outlined),
                label: const Text('How your data is used'),
              ),
              TextButton.icon(
                onPressed: _saving ? null : _deleteAccount,
                style: TextButton.styleFrom(foregroundColor: AppColors.danger),
                icon: const Icon(Icons.delete_forever_outlined),
                label: const Text('Delete my account and data'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sexSelector() {
    final List<MapEntry<String, String>> options = <MapEntry<String, String>>[
      const MapEntry<String, String>('male', 'Male'),
      const MapEntry<String, String>('female', 'Female'),
      const MapEntry<String, String>('unspecified', 'Prefer not'),
    ];
    return Row(
      children: options.map((MapEntry<String, String> option) {
        final bool selected = _sex == option.key;
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: Semantics(
              button: true,
              selected: selected,
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    _dirty = true;
                    _sex = option.key;
                    _recomputeEstimatedStride();
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: selected ? AppColors.accent.withValues(alpha: 0.18) : AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: selected ? AppColors.accent : AppColors.surfaceHigh),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    option.value,
                    style: TextStyle(
                      color: selected ? AppColors.accent : AppColors.textSecondary,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  static String _initials(String name) {
    final List<String> parts =
        name.trim().split(RegExp(r'\s+')).where((String p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1)).toUpperCase();
  }
}

class _PrivacySheet extends StatelessWidget {
  const _PrivacySheet();

  @override
  Widget build(BuildContext context) {
    const List<String> points = <String>[
      'Your account is managed by Supabase Auth. StepSync never sees or stores your password; '
          'Google and Facebook sign-in happen on their own pages.',
      'Daily step totals, distance estimates, active minutes and GPS session summaries are '
          'stored in your private rows. Database rules block other users from reading them.',
      'Location is used only while you run a GPS session you started, and only the session '
          'summary (distance, duration, steps) is saved — never your route or coordinates.',
      'Usage events (app opened, session started, music opened…) help us count installs and '
          'active users. The first-launch event is anonymous; events after you sign in are linked '
          'to your account. They never contain passwords, tokens, locations or link titles.',
      'Administrators see aggregated statistics and basic account details (name, email, sign-up '
          'and last sign-in dates). They cannot see passwords.',
      'You can delete your account at any time from this screen; all linked data is removed.',
    ];
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'How your data is used',
              style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),
            for (final String p in points)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Icon(Icons.circle, size: 6, color: AppColors.accent),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(p, style: const TextStyle(color: AppColors.textSecondary, height: 1.4)),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
