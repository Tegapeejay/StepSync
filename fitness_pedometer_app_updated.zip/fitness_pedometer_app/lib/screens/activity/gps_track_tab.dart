import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/formatters.dart';
import '../../core/theme.dart';
import '../../models/activity.dart';
import '../../models/profile.dart';
import '../../services/gps_tracker.dart';
import '../../widgets/common.dart';
import '../main_scaffold.dart';
import 'comparison_card.dart';
import 'session_history_screen.dart';

/// Start / stop a GPS session and compare it with the stride estimate for the
/// same period.
class GpsTrackTab extends StatefulWidget {
  final UserServices services;
  final Profile profile;
  const GpsTrackTab({super.key, required this.services, required this.profile});

  @override
  State<GpsTrackTab> createState() => _GpsTrackTabState();
}

class _GpsTrackTabState extends State<GpsTrackTab> with AutomaticKeepAliveClientMixin {
  GpsSession? _lastSession;
  bool _busy = false;

  // Keep the last-session comparison when switching tabs.
  @override
  bool get wantKeepAlive => true;

  GpsTracker get gps => widget.services.gps;

  Future<void> _start() async {
    setState(() => _busy = true);
    final bool started = await gps.start();
    if (started) {
      unawaited(widget.services.analytics.track('tracking_started'));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _stop() async {
    setState(() => _busy = true);
    final GpsSession? session = await gps.stop();
    if (session == null) {
      if (mounted) setState(() => _busy = false);
      return;
    }
    if (!mounted) {
      // Never drop a finished session just because the screen went away.
      await widget.services.sync.saveSession(session);
      return;
    }
    setState(() => _busy = false);

    if (session.gpsDistanceMeters < 10 || session.durationSeconds < 20) {
      final bool keep = await _confirm(
        'Very short session',
        'Only ${formatDistance(session.gpsDistanceMeters, widget.profile.unit)} '
            'in ${formatDuration(Duration(seconds: session.durationSeconds))} was recorded. Save it anyway?',
      );
      if (!keep) {
        if (mounted) showAppSnack(context, 'Session discarded');
        return;
      }
    }
    await widget.services.sync.saveSession(session);
    unawaited(widget.services.analytics.track('tracking_completed', metadata: <String, Object?>{
      // Rounded summary only — no coordinates.
      'distance_m': session.gpsDistanceMeters.round(),
      'duration_s': session.durationSeconds,
    }));
    if (!mounted) return;
    setState(() => _lastSession = session);
    showAppSnack(context, 'Session saved');
  }

  Future<bool> _confirm(String title, String message) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Discard')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
        ],
      ),
    );
    return ok ?? false;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[gps, widget.services.pedometer]),
      builder: (BuildContext context, Widget? _) {
        final DistanceUnit unit = widget.profile.unit;
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _permissionBanner(),
              SurfaceCard(
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Icon(
                          gps.isTracking ? Icons.gps_fixed_rounded : Icons.gps_not_fixed_rounded,
                          color: gps.isTracking ? AppColors.gps : AppColors.textMuted,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            gps.isTracking ? 'Tracking with GPS' : 'GPS tracking is off',
                            style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        if (gps.isTracking && gps.lastAccuracyMeters != null)
                          Text(
                            '±${gps.lastAccuracyMeters!.round()} m',
                            style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                          ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: <Widget>[
                        _stat('Time', formatDuration(gps.elapsed), AppColors.textPrimary),
                        _stat('GPS distance', formatDistance(gps.distanceMeters, unit), AppColors.gps),
                        _stat(
                          'Steps',
                          gps.isTracking
                              ? (gps.sessionSteps == null ? '—' : formatSteps(gps.sessionSteps!))
                              : '—',
                          AppColors.accent,
                        ),
                      ],
                    ),
                    if (gps.isTracking && (gps.signalWeak || gps.errorMessage != null)) ...<Widget>[
                      const SizedBox(height: 14),
                      ErrorBanner(
                        message: gps.errorMessage ??
                            'Waiting for a good GPS signal… Move outdoors with a clear view of the sky.',
                        color: AppColors.warning,
                        icon: Icons.gps_off_rounded,
                      ),
                    ],
                    const SizedBox(height: 18),
                    PrimaryButton(
                      label: gps.isTracking ? 'Stop & save' : 'Start GPS session',
                      icon: gps.isTracking ? Icons.stop_rounded : Icons.play_arrow_rounded,
                      color: gps.isTracking ? AppColors.danger : AppColors.accent,
                      foreground: gps.isTracking ? Colors.white : Colors.black,
                      loading: _busy || gps.state == GpsTrackingState.starting,
                      onPressed: gps.isTracking ? _stop : _start,
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Keep the app open while tracking. Location is used only while a '
                      'session is running; only the session summary is saved, never your route.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textMuted, fontSize: 11.5, height: 1.4),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              if (gps.isTracking)
                ComparisonCard(
                  title: 'This session so far',
                  steps: gps.sessionSteps,
                  strideLengthMeters: widget.services.pedometer.strideLengthMeters,
                  gpsMeters: gps.distanceMeters,
                  unit: unit,
                )
              else if (_lastSession != null)
                ComparisonCard(
                  title: 'Last session',
                  steps: _lastSession!.steps,
                  strideLengthMeters: _lastSession!.strideMeters,
                  gpsMeters: _lastSession!.gpsDistanceMeters,
                  unit: unit,
                ),
              const SizedBox(height: 16),
              SizedBox(
                height: 50,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => SessionHistoryScreen(services: widget.services, unit: unit),
                  )),
                  icon: const Icon(Icons.history_rounded),
                  label: const Text('Session history & comparisons'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.accent,
                    side: BorderSide(color: AppColors.accent.withValues(alpha: 0.5)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _permissionBanner() {
    final String? message = switch (gps.permission) {
      GpsPermission.serviceDisabled => 'Location services are off. Turn them on to track distance.',
      GpsPermission.deniedForever =>
        'Location permission is blocked. Enable it in Settings to use GPS sessions. '
            'Step counting keeps working without it.',
      GpsPermission.denied =>
        'Location permission was not granted. GPS sessions need it; step counting does not.',
      _ => null,
    };
    if (message == null || gps.isTracking) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          ErrorBanner(message: message, color: AppColors.warning, icon: Icons.location_off_rounded),
          if (gps.permission != GpsPermission.denied)
            TextButton(onPressed: gps.openSettings, child: const Text('Open settings')),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, Color color) {
    return Expanded(
      child: Column(
        children: <Widget>[
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
        ],
      ),
    );
  }
}
