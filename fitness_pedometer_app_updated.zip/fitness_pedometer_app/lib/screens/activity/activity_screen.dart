import 'package:flutter/material.dart';

import '../../core/formatters.dart';
import '../../core/theme.dart';
import '../../models/profile.dart';
import '../../services/pedometer_service.dart';
import '../../widgets/common.dart';
import '../main_scaffold.dart';
import '../pedometer_views.dart';
import 'gps_track_tab.dart';
import 'reports_tab.dart';

/// Activity tab: Today's breakdown (original screen), GPS tracking with the
/// stride-vs-GPS comparison, and daily / weekly / monthly reports.
class ActivityScreen extends StatelessWidget {
  final UserServices services;
  final Profile profile;

  const ActivityScreen({super.key, required this.services, required this.profile});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Text(
                'Activity',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const TabBar(
              indicatorColor: AppColors.accent,
              labelColor: AppColors.accent,
              unselectedLabelColor: AppColors.textMuted,
              dividerColor: Colors.transparent,
              tabs: <Widget>[
                Tab(text: 'Today'),
                Tab(text: 'GPS track'),
                Tab(text: 'Reports'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: <Widget>[
                  _TodayTab(services: services, profile: profile),
                  GpsTrackTab(services: services, profile: profile),
                  ReportsTab(services: services, profile: profile),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TodayTab extends StatelessWidget {
  final UserServices services;
  final Profile profile;
  const _TodayTab({required this.services, required this.profile});

  PedometerService get service => services.pedometer;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[service, services.sync]),
      builder: (BuildContext context, Widget? _) {
        final Widget? state = pedometerStateView(service, loadingTitle: 'Loading activity');
        if (state != null) return state;
        final DistanceUnit unit = profile.unit;
        final double gps = services.sync.todayGpsMeters;
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text(
                'Detailed breakdown for today',
                style: TextStyle(color: AppColors.textMuted, fontSize: 14),
              ),
              const SizedBox(height: 16),
              SurfaceCard(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        _bigStat('Steps', formatSteps(service.todaySteps), AppColors.accent),
                        _bigStat('Stride est.', formatDistance(service.distanceMeters, unit),
                            AppColors.info),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        _bigStat('GPS recorded', gps > 0 ? formatDistance(gps, unit) : '—',
                            AppColors.gps),
                        _bigStat('Goal', '${service.goalPercent}%', AppColors.accent),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        _bigStat('Active', '${service.activeMinutes} min', AppColors.warning),
                        _bigStat('Daily goal', formatSteps(service.dailyGoal), AppColors.textSecondary),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SurfaceCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'How this is calculated',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 12),
                    InfoRow('Status', _statusLabel(service.walkStatus)),
                    InfoRow('Stride length', '${service.strideLengthMeters.toStringAsFixed(2)} m'),
                    const InfoRow('Stride distance', 'steps × stride length'),
                    const InfoRow('GPS distance', 'sum of today\'s GPS sessions'),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceAlt,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(Icons.info_outline_rounded, color: AppColors.textMuted, size: 18),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Stride distance is an estimate for the whole day. GPS distance '
                              'only covers the sessions you recorded, so the two daily totals '
                              'are not directly comparable — compare them per session on the '
                              'GPS track tab.',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 12.5, height: 1.4),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  static String _statusLabel(WalkStatus status) {
    switch (status) {
      case WalkStatus.walking:
        return 'Walking';
      case WalkStatus.stopped:
        return 'Stopped';
      case WalkStatus.unknown:
        return 'Unknown';
    }
  }

  Widget _bigStat(String label, String value, Color color) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: TextStyle(color: color, fontSize: 26, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
        ],
      ),
    );
  }
}
