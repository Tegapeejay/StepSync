import 'package:flutter/material.dart';

import '../../core/formatters.dart';
import '../../core/theme.dart';
import '../../models/activity.dart';
import '../../services/backend.dart';
import '../../widgets/common.dart';
import '../main_scaffold.dart';
import 'comparison_card.dart';

/// Completed GPS sessions with a stride-vs-GPS comparison for each one.
/// Loads from Supabase; falls back to sessions recorded on this device.
class SessionHistoryScreen extends StatefulWidget {
  final UserServices services;
  final DistanceUnit unit;
  const SessionHistoryScreen({super.key, required this.services, required this.unit});

  @override
  State<SessionHistoryScreen> createState() => _SessionHistoryScreenState();
}

class _SessionHistoryScreenState extends State<SessionHistoryScreen> {
  List<GpsSession>? _sessions;
  String? _notice;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final List<GpsSession> remote = await widget.services.history.sessions(limit: 100);
      // Include sessions still waiting to upload.
      final Set<String> ids = remote.map((GpsSession s) => s.id).toSet();
      final List<GpsSession> local = widget.services.sync.recentLocalSessions
          .where((GpsSession s) => !ids.contains(s.id))
          .toList();
      final List<GpsSession> all = <GpsSession>[...local, ...remote]
        ..sort((GpsSession a, GpsSession b) => b.startedAt.compareTo(a.startedAt));
      if (mounted) setState(() => _sessions = all);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _sessions = widget.services.sync.recentLocalSessions;
        _notice = '${friendlyBackendError(e)} Showing sessions saved on this phone.';
      });
    }
  }

  Future<void> _delete(GpsSession s) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Delete session?'),
        content: const Text('This removes the session and its distance from your history.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.danger),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await widget.services.history.deleteSession(s.id);
      await widget.services.sync.removeLocalSession(s.id);
      if (!mounted) return;
      setState(() => _sessions = _sessions?.where((GpsSession x) => x.id != s.id).toList());
    } catch (e) {
      if (mounted) showAppSnack(context, friendlyBackendError(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<GpsSession>? sessions = _sessions;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        title: const Text('GPS sessions'),
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(24),
          child: Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text(
              'Long-press a session to delete it',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: sessions == null
            ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
            : sessions.isEmpty
                ? const StateMessage(
                    icon: Icons.satellite_alt_rounded,
                    title: 'No GPS sessions yet',
                    message: 'Start a session on the GPS track tab to compare GPS '
                        'distance with your stride estimate.',
                  )
                : RefreshIndicator(
                    color: AppColors.accent,
                    onRefresh: _load,
                    child: ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: sessions.length + (_notice == null ? 0 : 1),
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (BuildContext context, int i) {
                        if (_notice != null && i == 0) {
                          return ErrorBanner(
                            message: _notice!,
                            color: AppColors.warning,
                            icon: Icons.cloud_off_rounded,
                          );
                        }
                        final GpsSession s = sessions[i - (_notice == null ? 0 : 1)];
                        final String speed = s.averageSpeedMps == null
                            ? ''
                            : ' · ${(s.averageSpeedMps! * 3.6).toStringAsFixed(1)} km/h';
                        return GestureDetector(
                          onLongPress: () => _delete(s),
                          child: ComparisonCard(
                            title: '${formatDayLabel(s.startedAt)}, '
                                '${s.startedAt.hour.toString().padLeft(2, '0')}:'
                                '${s.startedAt.minute.toString().padLeft(2, '0')} · '
                                '${formatDuration(Duration(seconds: s.durationSeconds))}$speed',
                            steps: s.steps,
                            strideLengthMeters: s.strideMeters,
                            gpsMeters: s.gpsDistanceMeters,
                            unit: widget.unit,
                          ),
                        );
                      },
                    ),
                  ),
      ),
    );
  }
}
