import 'package:flutter/material.dart';

import '../../core/distance_comparison.dart';
import '../../core/formatters.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';

/// Side-by-side stride estimate vs GPS measurement for ONE activity period.
class ComparisonCard extends StatelessWidget {
  final String title;
  final int? steps;
  final double strideLengthMeters;
  final double gpsMeters;
  final DistanceUnit unit;

  const ComparisonCard({
    super.key,
    required this.title,
    required this.steps,
    required this.strideLengthMeters,
    required this.gpsMeters,
    required this.unit,
  });

  @override
  Widget build(BuildContext context) {
    final int? s = steps;
    final double stride = s == null ? 0 : strideDistanceMeters(s, strideLengthMeters);
    final DistanceComparison cmp = DistanceComparison(strideMeters: stride, gpsMeters: gpsMeters);
    final double? pct = cmp.differencePercent;

    return SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(
                child: _side(
                  'Stride estimate',
                  s == null ? '—' : formatDistance(stride, unit),
                  s == null ? 'steps not available' : '${formatSteps(s)} steps × ${strideLengthMeters.toStringAsFixed(2)} m',
                  AppColors.info,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _side(
                  'GPS recorded',
                  formatDistance(gpsMeters, unit),
                  'from location fixes',
                  AppColors.gps,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (s == null)
            const Text(
              'Steps could not be matched to this session (step counter unavailable, '
              'or the session crossed midnight), so no comparison is shown.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12.5, height: 1.4),
            )
          else ...<Widget>[
            InfoRow('Difference', formatDistance(cmp.absoluteDifferenceMeters, unit)),
            InfoRow(
              'Difference %',
              pct == null ? 'n/a (no GPS distance)' : '${pct.toStringAsFixed(2)}%',
            ),
            InfoRow(
              'Direction',
              cmp.signedDifferenceMeters == 0
                  ? 'equal'
                  : (cmp.signedDifferenceMeters > 0 ? 'stride estimate is longer' : 'GPS is longer'),
            ),
            if (!cmp.isMeaningful)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                  'Too short to judge accuracy — record at least ~50 m outdoors.',
                  style: TextStyle(color: AppColors.warning, fontSize: 12.5),
                ),
              ),
          ],
          const SizedBox(height: 8),
          const Text(
            'Difference % = |stride − GPS| ÷ GPS × 100. Neither value is ground truth: '
            'stride length varies with pace, and GPS drifts indoors, near tall buildings '
            'and with a weak signal.',
            style: TextStyle(color: AppColors.textMuted, fontSize: 11.5, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _side(String label, String value, String sub, Color color) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(sub, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
        ],
      ),
    );
  }
}
