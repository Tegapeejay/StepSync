import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../core/formatters.dart';
import '../../core/reports.dart';
import '../../core/theme.dart';
import '../../models/activity.dart';
import '../../models/profile.dart';
import '../../services/backend.dart';
import '../../widgets/common.dart';
import '../main_scaffold.dart';

/// Daily / weekly / monthly history from Supabase, with today's live
/// pedometer total merged in.
class ReportsTab extends StatefulWidget {
  final UserServices services;
  final Profile profile;
  const ReportsTab({super.key, required this.services, required this.profile});

  @override
  State<ReportsTab> createState() => _ReportsTabState();
}

class _ReportsTabState extends State<ReportsTab> with AutomaticKeepAliveClientMixin {
  ReportPeriod _period = ReportPeriod.week;
  DateTime _anchor = dateOnly(DateTime.now());
  List<DailyActivity>? _records;
  String? _error;
  int _request = 0;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    // _load() calls setState, which isn't allowed during initState.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _load();
    });
  }

  (DateTime, DateTime) _range() {
    switch (_period) {
      case ReportPeriod.day:
        return (_anchor, _anchor);
      case ReportPeriod.week:
        final DateTime s = startOfWeek(_anchor);
        return (s, addDays(s, 6));
      case ReportPeriod.month:
        return (startOfMonth(_anchor), endOfMonth(_anchor));
    }
  }

  Future<void> _load() async {
    final int request = ++_request;
    setState(() {
      _records = null;
      _error = null;
    });
    final (DateTime from, DateTime to) = _range();
    try {
      // Push the latest local total first so the server copy is current.
      await widget.services.sync.syncNow();
      final List<DailyActivity> rows = await widget.services.history.dailyRange(from, to);
      if (!mounted || request != _request) return;
      setState(() => _records = rows);
    } catch (e) {
      if (!mounted || request != _request) return;
      setState(() {
        _records = const <DailyActivity>[];
        _error = '${friendlyBackendError(e)} Only today\'s on-device total is shown.';
      });
    }
  }

  void _shift(int direction) {
    setState(() {
      switch (_period) {
        case ReportPeriod.day:
          _anchor = addDays(_anchor, direction);
          break;
        case ReportPeriod.week:
          _anchor = addDays(_anchor, 7 * direction);
          break;
        case ReportPeriod.month:
          _anchor = DateTime(_anchor.year, _anchor.month + direction, 1);
          break;
      }
    });
    _load();
  }

  String _rangeLabel() {
    final (DateTime from, DateTime to) = _range();
    switch (_period) {
      case ReportPeriod.day:
        return formatDayLabel(from);
      case ReportPeriod.week:
        return '${from.day} ${kMonthShort[from.month - 1]} – ${to.day} ${kMonthShort[to.month - 1]}';
      case ReportPeriod.month:
        return '${kMonthShort[from.month - 1]} ${from.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final DateTime today = dateOnly(DateTime.now());
    final (DateTime from, DateTime to) = _range();
    final bool canGoForward = to.isBefore(today);

    return ListenableBuilder(
      listenable: widget.services.pedometer,
      builder: (BuildContext context, Widget? _) {
        final List<DailyActivity>? records = _records;
        Widget body;
        if (records == null) {
          body = const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: CircularProgressIndicator(color: AppColors.accent)),
          );
        } else {
          final bool includesToday = !today.isBefore(from) && !today.isAfter(to);
          final List<DailyActivity> merged = includesToday && widget.services.pedometer.isCounting
              ? mergeLiveToday(
                  records,
                  today: today,
                  steps: widget.services.pedometer.todaySteps,
                  strideMeters: widget.services.pedometer.strideLengthMeters,
                  activeMinutes: widget.services.pedometer.activeMinutes,
                  dailyGoal: widget.services.pedometer.dailyGoal,
                  localGpsMeters: widget.services.sync.todayGpsMeters,
                )
              : records;
          final ActivityReport report = ActivityReport.build(
            period: _period,
            anchor: _anchor,
            records: merged,
            today: today,
          );
          body = _ReportBody(report: report, unit: widget.profile.unit, error: _error);
        }

        return RefreshIndicator(
          color: AppColors.accent,
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
            children: <Widget>[
              SegmentedButton<ReportPeriod>(
                segments: const <ButtonSegment<ReportPeriod>>[
                  ButtonSegment<ReportPeriod>(value: ReportPeriod.day, label: Text('Day')),
                  ButtonSegment<ReportPeriod>(value: ReportPeriod.week, label: Text('Week')),
                  ButtonSegment<ReportPeriod>(value: ReportPeriod.month, label: Text('Month')),
                ],
                selected: <ReportPeriod>{_period},
                showSelectedIcon: false,
                onSelectionChanged: (Set<ReportPeriod> s) {
                  setState(() => _period = s.first);
                  _load();
                },
              ),
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  IconButton(
                    tooltip: 'Previous',
                    onPressed: () => _shift(-1),
                    icon: const Icon(Icons.chevron_left_rounded, color: AppColors.textPrimary),
                  ),
                  Expanded(
                    child: Text(
                      _rangeLabel(),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Next',
                    onPressed: canGoForward ? () => _shift(1) : null,
                    icon: Icon(
                      Icons.chevron_right_rounded,
                      color: canGoForward ? AppColors.textPrimary : AppColors.surfaceHigh,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              body,
            ],
          ),
        );
      },
    );
  }
}

class _ReportBody extends StatelessWidget {
  final ActivityReport report;
  final DistanceUnit unit;
  final String? error;
  const _ReportBody({required this.report, required this.unit, this.error});

  @override
  Widget build(BuildContext context) {
    final DailyActivity? best = report.bestDay;
    final List<Widget> children = <Widget>[
      if (error != null) ...<Widget>[
        ErrorBanner(message: error!, color: AppColors.warning, icon: Icons.cloud_off_rounded),
        const SizedBox(height: 12),
      ],
    ];

    if (report.period == ReportPeriod.day) {
      final DailyActivity? d = report.days.first.value;
      if (d == null || (d.steps == 0 && d.gpsDistanceMeters == 0)) {
        children.add(const StateMessage(
          icon: Icons.event_busy_rounded,
          title: 'No activity recorded',
          message: 'There is no stored activity for this day.',
        ));
        return Column(children: children);
      }
      children.add(SurfaceCard(
        child: Column(
          children: <Widget>[
            InfoRow('Steps', formatSteps(d.steps), valueColor: AppColors.accent),
            InfoRow('Stride distance (est.)', formatDistance(d.strideDistanceMeters, unit),
                valueColor: AppColors.info),
            InfoRow('GPS distance (sessions)', formatDistance(d.gpsDistanceMeters, unit),
                valueColor: AppColors.gps),
            InfoRow('Active time', '${d.activeMinutes} min'),
            InfoRow('Daily goal', formatSteps(d.dailyGoal)),
            InfoRow(
              'Goal completion',
              d.dailyGoal > 0 ? '${(d.steps * 100 / d.dailyGoal).round()}%' : '—',
              valueColor: d.goalAchieved ? AppColors.accent : null,
            ),
          ],
        ),
      ));
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children);
    }

    if (report.daysWithActivity == 0 && report.totalGpsMeters == 0) {
      children.add(const StateMessage(
        icon: Icons.event_busy_rounded,
        title: 'No activity recorded',
        message: 'Nothing was stored for this period yet.',
      ));
      return Column(children: children);
    }

    final bool week = report.period == ReportPeriod.week;
    children.addAll(<Widget>[
      SurfaceCard(
        padding: const EdgeInsets.fromLTRB(12, 18, 12, 8),
        child: _StepsChart(report: report),
      ),
      const SizedBox(height: 14),
      SurfaceCard(
        child: Column(
          children: <Widget>[
            InfoRow('Total steps', formatSteps(report.totalSteps), valueColor: AppColors.accent),
            InfoRow('Stride distance (est.)', formatDistance(report.totalStrideMeters, unit),
                valueColor: AppColors.info),
            InfoRow('GPS distance (sessions)', formatDistance(report.totalGpsMeters, unit),
                valueColor: AppColors.gps),
            InfoRow('Average per day', formatSteps(report.averageDailySteps.round())),
            InfoRow('Active time', '${report.totalActiveMinutes} min'),
            InfoRow(
              week ? 'Most active day' : 'Best day',
              best == null ? '—' : '${formatDayLabel(best.date)} · ${formatSteps(best.steps)}',
            ),
            InfoRow(
              'Goal reached',
              week
                  ? '${report.goalDays} of ${report.elapsedDays} days'
                  : '${(report.goalRate * 100).round()}% (${report.goalDays}/${report.elapsedDays} days)',
            ),
          ],
        ),
      ),
      const SizedBox(height: 10),
      const Text(
        'Days without a record count as zero. Averages and goal rates only include '
        'days up to today. Dates are your phone\'s local calendar days.',
        style: TextStyle(color: AppColors.textMuted, fontSize: 11.5, height: 1.4),
      ),
    ]);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children);
  }
}

class _StepsChart extends StatelessWidget {
  final ActivityReport report;
  const _StepsChart({required this.report});

  @override
  Widget build(BuildContext context) {
    final List<MapEntry<DateTime, DailyActivity?>> days = report.days;
    final List<int> steps = days.map((MapEntry<DateTime, DailyActivity?> e) => e.value?.steps ?? 0).toList();
    final int goal = days
        .map((MapEntry<DateTime, DailyActivity?> e) => e.value?.dailyGoal ?? 0)
        .fold<int>(0, (int a, int b) => b > a ? b : a);
    final int maxSteps = steps.fold<int>(goal, (int a, int b) => b > a ? b : a);
    final double maxY = (maxSteps <= 0 ? 1000 : maxSteps) * 1.15;
    final bool week = report.period == ReportPeriod.week;

    return Semantics(
      label: 'Steps per day: ${List<String>.generate(days.length, (int i) => '${formatDayLabel(days[i].key)} ${steps[i]}').join(', ')}',
      excludeSemantics: true,
      child: SizedBox(
        height: 190,
        child: BarChart(
          BarChartData(
            maxY: maxY,
            minY: 0,
            barTouchData: BarTouchData(enabled: false),
            borderData: FlBorderData(show: false),
            gridData: FlGridData(show: false),
            extraLinesData: goal > 0
                ? ExtraLinesData(horizontalLines: <HorizontalLine>[
                    HorizontalLine(
                      y: goal.toDouble(),
                      color: AppColors.textMuted.withValues(alpha: 0.6),
                      strokeWidth: 1,
                      dashArray: <int>[4, 4],
                    ),
                  ])
                : ExtraLinesData(),
            titlesData: FlTitlesData(
              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 22,
                  getTitlesWidget: (double value, TitleMeta meta) {
                    final int i = value.toInt();
                    if (i < 0 || i >= days.length) return const SizedBox.shrink();
                    final DateTime d = days[i].key;
                    // Month view: label every 5th day to avoid clutter.
                    if (!week && d.day != 1 && d.day % 5 != 0) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        week ? kWeekdayShort[d.weekday - 1] : '${d.day}',
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 10),
                      ),
                    );
                  },
                ),
              ),
            ),
            barGroups: <BarChartGroupData>[
              for (int i = 0; i < days.length; i++)
                BarChartGroupData(
                  x: i,
                  barRods: <BarChartRodData>[
                    BarChartRodData(
                      toY: steps[i].toDouble(),
                      width: week ? 18 : 6,
                      color: (days[i].value?.goalAchieved ?? false)
                          ? AppColors.accent
                          : AppColors.accent.withValues(alpha: 0.45),
                      borderRadius: BorderRadius.circular(week ? 6 : 3),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}
