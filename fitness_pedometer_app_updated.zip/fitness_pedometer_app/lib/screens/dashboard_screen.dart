import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/profile.dart';
import '../services/pedometer_service.dart';
import '../widgets/common.dart';
import 'main_scaffold.dart';
import 'pedometer_views.dart';

class DashboardScreen extends StatelessWidget {
  final UserServices services;
  final Profile profile;

  const DashboardScreen({
    super.key,
    required this.services,
    required this.profile,
  });

  PedometerService get service => services.pedometer;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[service, services.sync]),
        builder: (BuildContext context, Widget? _) {
          return pedometerStateView(service) ?? _buildContent(context);
        },
      ),
    );
  }

  Widget _buildContent(BuildContext context) {
    final String greetingName =
        profile.name.trim().isEmpty ? 'there' : profile.name.trim().split(' ').first;
    final DistanceUnit unit = profile.unit;
    final double gpsToday = services.sync.todayGpsMeters;

    return RefreshIndicator(
      color: AppColors.accent,
      onRefresh: services.sync.syncNow,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Hi, $greetingName',
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 2),
                      const Text(
                        "Today's activity",
                        style: TextStyle(color: AppColors.textMuted, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                StatusChip(status: service.walkStatus),
              ],
            ),
            const SizedBox(height: 24),
            Center(
              child: Semantics(
                label: '${service.todaySteps} steps today, ${service.goalPercent} percent of goal',
                excludeSemantics: true,
                child: ProgressRing(
                  progress: service.goalProgressClamped,
                  center: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        formatSteps(service.todaySteps),
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 44,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -1,
                        ),
                      ),
                      const SizedBox(height: 2),
                      const Text(
                        'STEPS',
                        style: TextStyle(color: AppColors.textMuted, fontSize: 13, letterSpacing: 3),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          color: AppColors.accent.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${service.goalPercent}% of goal',
                          style: const TextStyle(
                            color: AppColors.accent,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: <Widget>[
                Expanded(
                  child: MetricTile(
                    icon: Icons.straighten_rounded,
                    iconColor: AppColors.info,
                    value: formatDistance(service.distanceMeters, unit),
                    label: 'STRIDE EST.',
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: MetricTile(
                    icon: Icons.satellite_alt_rounded,
                    iconColor: AppColors.gps,
                    value: gpsToday > 0 ? formatDistance(gpsToday, unit) : '—',
                    label: 'GPS TODAY',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                Expanded(
                  child: MetricTile(
                    icon: Icons.flag_rounded,
                    iconColor: AppColors.accent,
                    value: '${service.goalPercent}%',
                    label: 'GOAL',
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: MetricTile(
                    icon: Icons.timer_outlined,
                    iconColor: AppColors.warning,
                    value: '${service.activeMinutes} min',
                    label: 'ACTIVE',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            SurfaceCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      const Text(
                        'Daily goal',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        '${formatSteps(service.todaySteps)} / ${formatSteps(service.dailyGoal)}',
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: TweenAnimationBuilder<double>(
                      tween: Tween<double>(begin: 0, end: service.goalProgressClamped),
                      duration: const Duration(milliseconds: 600),
                      curve: Curves.easeOut,
                      builder: (BuildContext context, double value, Widget? _) {
                        return LinearProgressIndicator(
                          value: value,
                          minHeight: 10,
                          backgroundColor: AppColors.surfaceHigh,
                          valueColor: const AlwaysStoppedAnimation<Color>(AppColors.accent),
                        );
                      },
                    ),
                  ),
                  if (service.goalReached) ...<Widget>[
                    const SizedBox(height: 12),
                    const Row(
                      children: <Widget>[
                        Icon(Icons.emoji_events_rounded, color: AppColors.warning, size: 18),
                        SizedBox(width: 8),
                        Text(
                          'Goal reached — nice work!',
                          style: TextStyle(
                            color: AppColors.warning,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 14),
            _SyncStatus(services: services),
          ],
        ),
      ),
    );
  }
}

class _SyncStatus extends StatelessWidget {
  final UserServices services;
  const _SyncStatus({required this.services});

  @override
  Widget build(BuildContext context) {
    final int pending = services.sync.pendingCount;
    final String? error = services.sync.lastError;
    final DateTime? last = services.sync.lastSyncedAt;
    final String text;
    final IconData icon;
    final Color color;
    if (error != null) {
      text = '$error Saved on this phone; will retry.';
      icon = Icons.cloud_off_rounded;
      color = AppColors.warning;
    } else if (pending > 0) {
      text = 'Syncing $pending item${pending == 1 ? '' : 's'}…';
      icon = Icons.cloud_upload_outlined;
      color = AppColors.textMuted;
    } else if (last != null) {
      text = 'Synced at ${last.hour.toString().padLeft(2, '0')}:${last.minute.toString().padLeft(2, '0')}';
      icon = Icons.cloud_done_outlined;
      color = AppColors.textMuted;
    } else {
      text = 'Waiting to sync';
      icon = Icons.cloud_queue_rounded;
      color = AppColors.textMuted;
    }
    return Row(
      children: <Widget>[
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 8),
        Expanded(child: Text(text, style: TextStyle(color: color, fontSize: 12))),
      ],
    );
  }
}
