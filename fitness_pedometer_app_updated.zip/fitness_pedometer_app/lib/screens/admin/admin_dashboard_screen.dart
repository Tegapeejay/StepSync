import 'dart:async';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../core/formatters.dart';
import '../../core/theme.dart';
import '../../services/admin_service.dart';
import '../../services/backend.dart';
import '../../widgets/common.dart';

/// Admin-only statistics and user management. Every request is authorised
/// on the server; this screen is merely hidden from non-admins.
class AdminDashboardScreen extends StatelessWidget {
  final AdminService admin;
  const AdminDashboardScreen({super.key, required this.admin});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Text(
                'Admin',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 26, fontWeight: FontWeight.w800),
              ),
            ),
            const TabBar(
              indicatorColor: AppColors.accent,
              labelColor: AppColors.accent,
              unselectedLabelColor: AppColors.textMuted,
              dividerColor: Colors.transparent,
              tabs: <Widget>[Tab(text: 'Overview'), Tab(text: 'Users')],
            ),
            Expanded(
              child: TabBarView(
                children: <Widget>[
                  _OverviewTab(admin: admin),
                  _UsersTab(admin: admin),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Overview

class _OverviewTab extends StatefulWidget {
  final AdminService admin;
  const _OverviewTab({required this.admin});

  @override
  State<_OverviewTab> createState() => _OverviewTabState();
}

class _OverviewTabState extends State<_OverviewTab> with AutomaticKeepAliveClientMixin {
  Map<String, dynamic>? _stats;
  List<DailySignIns> _daily = const <DailySignIns>[];
  String? _error;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final Map<String, dynamic> stats = await widget.admin.dashboardStats();
      final List<DailySignIns> daily = await widget.admin.signInsDaily(days: 30);
      if (!mounted) return;
      setState(() {
        _stats = stats;
        _daily = daily;
        _error = null;
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyBackendError(e));
    }
  }

  Map<String, dynamic> _section(String key) =>
      Map<String, dynamic>.from((_stats?[key] as Map?) ?? const <String, dynamic>{});

  String _n(Map<String, dynamic> m, String key) => formatSteps((m[key] as num?)?.toInt() ?? 0);

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_error != null) {
      return StateMessage(
        icon: Icons.lock_outline_rounded,
        title: 'Could not load statistics',
        message: _error!,
        action: SizedBox(width: 160, child: PrimaryButton(label: 'Retry', onPressed: _load)),
      );
    }
    if (_stats == null) {
      return const Center(child: CircularProgressIndicator(color: AppColors.accent));
    }
    final Map<String, dynamic> users = _section('users');
    final Map<String, dynamic> signIns = _section('sign_ins');
    final Map<String, dynamic> active = _section('active_users');
    final Map<String, dynamic> fitness = _section('fitness');
    final Map<String, dynamic> installs = _section('installs');
    final Map<String, dynamic> byProvider =
        Map<String, dynamic>.from((signIns['by_provider'] as Map?) ?? const <String, dynamic>{});

    return RefreshIndicator(
      color: AppColors.accent,
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
        children: <Widget>[
          const SectionLabel('Registered users'),
          _grid(<_Stat>[
            _Stat('Total', _n(users, 'total')),
            _Stat('New today', _n(users, 'new_today')),
            _Stat('New this week', _n(users, 'new_week')),
            _Stat('New this month', _n(users, 'new_month')),
          ]),
          const SizedBox(height: 18),
          const SectionLabel('Sign-ins'),
          _grid(<_Stat>[
            _Stat('Sign-in events (all)', _n(signIns, 'total')),
            _Stat('Events today', _n(signIns, 'today')),
            _Stat('Unique users today', _n(signIns, 'unique_today')),
            _Stat('Unique this week', _n(signIns, 'unique_week')),
            _Stat('Events this month', _n(signIns, 'month')),
            _Stat('Unique this month', _n(signIns, 'unique_month')),
            _Stat('Email/password', _n(byProvider, 'email')),
            _Stat('Google', _n(byProvider, 'google')),
            _Stat('Facebook', _n(byProvider, 'facebook')),
          ]),
          const SizedBox(height: 8),
          const Text(
            'Events count every sign-in; unique users count each person once per period.',
            style: TextStyle(color: AppColors.textMuted, fontSize: 11.5),
          ),
          const SizedBox(height: 14),
          if (_daily.isNotEmpty)
            SurfaceCard(
              padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
              child: _SignInChart(daily: _daily),
            ),
          const SizedBox(height: 18),
          const SectionLabel('Active users'),
          _grid(<_Stat>[
            _Stat('Today', _n(active, 'today')),
            _Stat('This week', _n(active, 'week')),
            _Stat('This month', _n(active, 'month')),
          ]),
          const SizedBox(height: 8),
          const Text(
            'Active = signed in, recorded steps, saved a GPS session or used the app in the period '
            '(UTC calendar days/weeks/months).',
            style: TextStyle(color: AppColors.textMuted, fontSize: 11.5),
          ),
          const SizedBox(height: 18),
          const SectionLabel('Fitness (aggregated)'),
          _grid(<_Stat>[
            _Stat('Users with steps today', _n(fitness, 'users_with_activity_today')),
            _Stat('Users with steps this week', _n(fitness, 'users_with_activity_week')),
            _Stat('Avg daily steps (30 d)', _n(fitness, 'avg_daily_steps_30d')),
            _Stat('GPS sessions this week', _n(fitness, 'gps_sessions_week')),
            _Stat('GPS sessions this month', _n(fitness, 'gps_sessions_month')),
            _Stat('Reached goal today', _n(fitness, 'users_reached_goal_today')),
          ]),
          const SizedBox(height: 18),
          const SectionLabel('Installs (first launches)'),
          _grid(<_Stat>[
            _Stat('All time', _n(installs, 'first_opens_total')),
            _Stat('This week', _n(installs, 'first_opens_week')),
            _Stat('This month', _n(installs, 'first_opens_month')),
          ]),
          const SizedBox(height: 10),
          _breakdown('By platform', installs['by_platform']),
          _breakdown('By app version (last 30 days)', installs['by_app_version']),
          const SizedBox(height: 10),
          const SurfaceCard(
            color: AppColors.surfaceAlt,
            child: Text(
              'Downloads ≠ installs ≠ accounts ≠ sign-ins ≠ active users.\n\n'
              '• Store downloads are only known to Google Play Console / App Store Connect; '
              'Supabase cannot see them.\n'
              '• "First launches" are anonymous installation IDs sent the first time the app '
              'opens. Reinstalls and cleared app data create new IDs, and installs that are '
              'never opened (or are offline) are missed.\n'
              '• Registered accounts come from Supabase Auth; sign-ins from one record per '
              'Auth session.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _breakdown(String title, Object? data) {
    final Map<String, dynamic> m = Map<String, dynamic>.from((data as Map?) ?? const <String, dynamic>{});
    if (m.isEmpty) return const SizedBox.shrink();
    return SurfaceCard(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: const TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w700)),
          for (final MapEntry<String, dynamic> e in m.entries)
            InfoRow(e.key, formatSteps((e.value as num).toInt())),
        ],
      ),
    );
  }

  Widget _grid(List<_Stat> stats) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints c) {
        final double w = (c.maxWidth - 12) / 2;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: <Widget>[
            for (final _Stat s in stats)
              SizedBox(
                width: w,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        s.value,
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(s.label, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _Stat {
  const _Stat(this.label, this.value);
  final String label;
  final String value;
}

class _SignInChart extends StatelessWidget {
  final List<DailySignIns> daily;
  const _SignInChart({required this.daily});

  @override
  Widget build(BuildContext context) {
    final int maxV = daily.fold<int>(1, (int a, DailySignIns d) => d.signIns > a ? d.signIns : a);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Padding(
          padding: EdgeInsets.only(left: 6, bottom: 10),
          child: Text('Sign-ins per day (last 30 days, UTC)',
              style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w700)),
        ),
        Semantics(
          label: 'Sign-ins per day over the last 30 days, peak $maxV',
          excludeSemantics: true,
          child: SizedBox(
            height: 150,
            child: BarChart(
              BarChartData(
                maxY: maxV * 1.2,
                minY: 0,
                barTouchData: BarTouchData(enabled: false),
                borderData: FlBorderData(show: false),
                gridData: FlGridData(show: false),
                titlesData: FlTitlesData(
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 20,
                      getTitlesWidget: (double v, TitleMeta meta) {
                        final int i = v.toInt();
                        if (i < 0 || i >= daily.length || i % 7 != 0) return const SizedBox.shrink();
                        final DateTime d = daily[i].day;
                        return Text('${d.day}/${d.month}',
                            style: const TextStyle(color: AppColors.textMuted, fontSize: 10));
                      },
                    ),
                  ),
                ),
                barGroups: <BarChartGroupData>[
                  for (int i = 0; i < daily.length; i++)
                    BarChartGroupData(x: i, barRods: <BarChartRodData>[
                      BarChartRodData(
                        toY: daily[i].signIns.toDouble(),
                        width: 5,
                        color: AppColors.info,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ]),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------- Users

class _UsersTab extends StatefulWidget {
  final AdminService admin;
  const _UsersTab({required this.admin});

  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> with AutomaticKeepAliveClientMixin {
  static const int _pageSize = 25;
  final TextEditingController _search = TextEditingController();
  Timer? _debounce;
  int _page = 0;
  AdminUserPage? _data;
  String? _error;
  bool _loading = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _load();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final AdminUserPage page =
          await widget.admin.listUsers(search: _search.text, page: _page, pageSize: _pageSize);
      if (mounted) setState(() => _data = page);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyBackendError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _onSearch(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      _page = 0;
      _load();
    });
  }

  Future<void> _toggleStatus(AdminUserRow u) async {
    final bool suspend = u.status != 'suspended';
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text(suspend ? 'Suspend account?' : 'Reactivate account?'),
        content: Text(suspend
            ? '${u.email} will be signed out and unable to sign in until reactivated.'
            : '${u.email} will be able to sign in again.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: suspend ? AppColors.danger : AppColors.accent),
            child: Text(suspend ? 'Suspend' : 'Reactivate'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await widget.admin.setUserStatus(u.id, suspended: suspend);
      await _load();
    } catch (e) {
      if (mounted) showAppSnack(context, friendlyBackendError(e), error: true);
    }
  }

  String _date(DateTime? d) => d == null
      ? '—'
      : '${d.day} ${kMonthShort[d.month - 1]} ${d.year}';

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AdminUserPage? data = _data;
    final int totalPages = data == null ? 1 : ((data.total + _pageSize - 1) ~/ _pageSize).clamp(1, 1 << 30);
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: AppTextField(
            controller: _search,
            label: 'Search name or email',
            icon: Icons.search_rounded,
            onChanged: _onSearch,
          ),
        ),
        if (_loading) const LinearProgressIndicator(color: AppColors.accent, minHeight: 2),
        Expanded(
          child: _error != null
              ? StateMessage(icon: Icons.error_outline_rounded, title: 'Could not load users', message: _error!)
              : data == null
                  ? const SizedBox.shrink()
                  : data.rows.isEmpty
                      ? const StateMessage(
                          icon: Icons.person_search_rounded,
                          title: 'No users found',
                          message: 'Try a different search.',
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                          itemCount: data.rows.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (BuildContext context, int i) {
                            final AdminUserRow u = data.rows[i];
                            final bool suspended = u.status == 'suspended';
                            return SurfaceCard(
                              padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Text(
                                          u.name.isEmpty ? '(no name)' : u.name,
                                          style: const TextStyle(
                                            color: AppColors.textPrimary,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        Text(u.email, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                                        const SizedBox(height: 4),
                                        Text(
                                          'Joined ${_date(u.createdAt)} · last sign-in ${_date(u.lastSignInAt)}\n'
                                          '${u.providers} · ${suspended ? 'SUSPENDED' : 'active'}',
                                          style: TextStyle(
                                            color: suspended ? AppColors.danger : AppColors.textMuted,
                                            fontSize: 11.5,
                                          ),
                                        ),
                                        SelectableText(
                                          u.id,
                                          style: const TextStyle(color: AppColors.textMuted, fontSize: 10),
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: suspended ? 'Reactivate' : 'Suspend',
                                    onPressed: () => _toggleStatus(u),
                                    icon: Icon(
                                      suspended ? Icons.lock_open_rounded : Icons.block_rounded,
                                      color: suspended ? AppColors.accent : AppColors.danger,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
        ),
        if (data != null && data.total > 0)
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
            child: Row(
              children: <Widget>[
                IconButton(
                  tooltip: 'Previous page',
                  onPressed: _page > 0 && !_loading
                      ? () {
                          _page--;
                          _load();
                        }
                      : null,
                  icon: const Icon(Icons.chevron_left_rounded),
                ),
                Expanded(
                  child: Text(
                    'Page ${_page + 1} of $totalPages · ${data.total} users',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppColors.textMuted),
                  ),
                ),
                IconButton(
                  tooltip: 'Next page',
                  onPressed: _page + 1 < totalPages && !_loading
                      ? () {
                          _page++;
                          _load();
                        }
                      : null,
                  icon: const Icon(Icons.chevron_right_rounded),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
