import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/pedometer_service.dart';
import '../widgets/common.dart';

/// Loading / permission / sensor-unavailable states for pedometer screens.
/// Returns null when the step counter is ready.
Widget? pedometerStateView(PedometerService service, {String loadingTitle = 'Getting things ready'}) {
  if (service.loading) {
    return StateMessage(
      icon: Icons.hourglass_empty_rounded,
      title: loadingTitle,
      message: 'Setting up permissions and the step counter…',
      showSpinner: true,
    );
  }
  if (service.permission != PermissionState.granted) {
    return PermissionView(service: service);
  }
  if (service.sensor == SensorState.unavailable) {
    return SensorUnavailableView(service: service);
  }
  return null;
}

class PermissionView extends StatelessWidget {
  final PedometerService service;
  const PermissionView({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    final bool permanent = service.permission == PermissionState.permanentlyDenied;
    return StateMessage(
      icon: Icons.directions_walk_rounded,
      title: 'Activity permission needed',
      message: permanent
          ? 'Activity permission is turned off. Please enable it in Settings '
              'so we can count your steps.'
          : 'Activity permission is required to count your steps.',
      action: SizedBox(
        width: 220,
        child: PrimaryButton(
          label: permanent ? 'Open Settings' : 'Grant Permission',
          onPressed: () => service.requestPermission(),
        ),
      ),
    );
  }
}

class SensorUnavailableView extends StatelessWidget {
  final PedometerService service;
  const SensorUnavailableView({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return StateMessage(
      icon: Icons.sensors_off_rounded,
      title: 'Step counter unavailable',
      message: 'Your device does not appear to support the required activity '
          'sensor, or the sensor could not be reached. Pedometer features '
          'work best on a physical phone.',
      action: SizedBox(
        width: 200,
        child: OutlinedButton.icon(
          onPressed: () => service.retry(),
          icon: const Icon(Icons.refresh_rounded, size: 18),
          label: const Text('Try again'),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.accent,
            side: BorderSide(color: AppColors.accent.withValues(alpha: 0.5)),
            minimumSize: const Size.fromHeight(50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
    );
  }
}
