import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/profile.dart';
import '../services/admin_service.dart';
import '../services/analytics_service.dart';
import '../services/auth_service.dart';
import '../services/gps_tracker.dart';
import '../services/history_service.dart';
import '../services/music_service.dart';
import '../services/pedometer_service.dart';
import '../services/profile_service.dart';
import '../services/sync_service.dart';
import 'activity/activity_screen.dart';
import 'admin/admin_dashboard_screen.dart';
import 'dashboard_screen.dart';
import 'music/music_screen.dart';
import 'profile_screen.dart';

/// Everything a signed-in screen needs, created once per user.
class UserServices {
  UserServices({
    required this.user,
    required this.prefs,
    required this.auth,
    required this.analytics,
    required this.profileService,
    required this.pedometer,
    required this.gps,
    required this.sync,
    required this.history,
    required this.music,
    required this.player,
    required this.admin,
  });

  final User user;
  final SharedPreferences prefs;
  final AuthService auth;
  final AnalyticsService analytics;
  final ProfileService profileService;
  final PedometerService pedometer;
  final GpsTracker gps;
  final SyncService sync;
  final HistoryService history;
  final MusicService music;
  final LocalAudioPlayer player;
  final AdminService admin;
}

class MainScaffold extends StatefulWidget {
  final SharedPreferences prefs;
  final User user;
  final AuthService auth;
  final AnalyticsService analytics;

  const MainScaffold({
    super.key,
    required this.prefs,
    required this.user,
    required this.auth,
    required this.analytics,
  });

  @override
  State<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends State<MainScaffold> with WidgetsBindingObserver {
  late final UserServices _s;
  late Profile _profile;
  int _index = 0;
  bool _isAdmin = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    final ProfileService profileService = ProfileService(widget.prefs);
    _profile = profileService.cached(widget.user.id) ??
        Profile.defaults(
          id: widget.user.id,
          email: widget.user.email ?? '',
          name: (widget.user.userMetadata?['full_name'] ?? '').toString(),
        );

    final PedometerService pedometer = PedometerService(
      userId: widget.user.id,
      prefs: widget.prefs,
      strideLengthMeters: _profile.effectiveStrideMeters,
      dailyGoal: _profile.dailyGoal,
    );
    final SyncService sync = SyncService(
      userId: widget.user.id,
      prefs: widget.prefs,
      pedometer: pedometer,
    );
    pedometer.onDayClosed = (String date, int steps, int active) {
      unawaited(sync.onDayClosed(date, steps, active));
    };

    _s = UserServices(
      user: widget.user,
      prefs: widget.prefs,
      auth: widget.auth,
      analytics: widget.analytics,
      profileService: profileService,
      pedometer: pedometer,
      gps: GpsTracker(pedometer: pedometer),
      sync: sync,
      history: HistoryService(widget.user.id),
      music: MusicService(prefs: widget.prefs, userId: widget.user.id),
      player: LocalAudioPlayer(),
      admin: AdminService(),
    );

    // Kick off permission checks and stream subscriptions.
    pedometer.init();
    sync.start();
    _refreshProfile();
    _checkAdmin();
    unawaited(widget.analytics.recordActiveToday(widget.user.id, dateKey(DateTime.now())));
  }

  Future<void> _refreshProfile() async {
    final Profile fresh = await _s.profileService.load(widget.user);
    if (!mounted) return;
    _onProfileSaved(fresh);
  }

  Future<void> _checkAdmin() async {
    final bool admin = await _s.admin.isAdmin();
    if (mounted && admin != _isAdmin) setState(() => _isAdmin = admin);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_s.sync.syncNow());
      unawaited(widget.analytics.recordActiveToday(widget.user.id, dateKey(DateTime.now())));
    } else if (state == AppLifecycleState.paused) {
      // Save the latest total locally before the OS may suspend the app.
      unawaited(_s.sync.queueToday());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _s.gps.dispose();
    _s.sync.dispose();
    _s.music.dispose();
    _s.player.dispose();
    _s.pedometer.dispose();
    super.dispose();
  }

  void _onProfileSaved(Profile updated) {
    setState(() => _profile = updated);
    _s.pedometer.applyProfile(
      strideMeters: updated.effectiveStrideMeters,
      goal: updated.dailyGoal,
    );
  }

  Future<void> _logout() async {
    if (_s.gps.isTracking) {
      showAppSnackIfMounted('Stop the GPS session before signing out.');
      return;
    }
    await _s.sync.syncNow();
    await widget.analytics.track('logout');
    await _s.player.stop();
    await widget.auth.logout();
    // AuthGate shows the sign-in screen and disposes this widget.
  }

  void showAppSnackIfMounted(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = <Widget>[
      DashboardScreen(services: _s, profile: _profile),
      ActivityScreen(services: _s, profile: _profile),
      MusicScreen(services: _s),
      ProfileScreen(
        services: _s,
        profile: _profile,
        onSaved: _onProfileSaved,
        onLogout: _logout,
      ),
      if (_isAdmin) AdminDashboardScreen(admin: _s.admin),
    ];
    final int index = _index < pages.length ? _index : 0;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          border: Border(
            top: BorderSide(color: AppColors.surfaceHigh, width: 0.6),
          ),
        ),
        child: SafeArea(
          top: false,
          child: NavigationBarTheme(
            data: NavigationBarThemeData(
              backgroundColor: AppColors.surface,
              indicatorColor: AppColors.accent.withValues(alpha: 0.18),
              labelTextStyle: WidgetStateProperty.resolveWith<TextStyle>(
                (Set<WidgetState> states) {
                  final bool selected = states.contains(WidgetState.selected);
                  return TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: selected ? AppColors.accent : AppColors.textMuted,
                  );
                },
              ),
            ),
            child: NavigationBar(
              height: 66,
              selectedIndex: index,
              onDestinationSelected: (int i) => setState(() => _index = i),
              destinations: <NavigationDestination>[
                const NavigationDestination(
                  icon: Icon(Icons.home_outlined, color: AppColors.textMuted),
                  selectedIcon: Icon(Icons.home_rounded, color: AppColors.accent),
                  label: 'Home',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.insights_outlined, color: AppColors.textMuted),
                  selectedIcon: Icon(Icons.insights_rounded, color: AppColors.accent),
                  label: 'Activity',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.headphones_outlined, color: AppColors.textMuted),
                  selectedIcon: Icon(Icons.headphones_rounded, color: AppColors.accent),
                  label: 'Music',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.person_outline_rounded, color: AppColors.textMuted),
                  selectedIcon: Icon(Icons.person_rounded, color: AppColors.accent),
                  label: 'Profile',
                ),
                if (_isAdmin)
                  const NavigationDestination(
                    icon: Icon(Icons.admin_panel_settings_outlined, color: AppColors.textMuted),
                    selectedIcon:
                        Icon(Icons.admin_panel_settings_rounded, color: AppColors.accent),
                    label: 'Admin',
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
