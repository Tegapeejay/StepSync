import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/theme.dart';
import '../../services/auth_service.dart';
import '../../widgets/common.dart';

/// "Continue with Google / Facebook" buttons.
///
/// The provider page opens in the browser. Success returns through the deep
/// link and AuthGate swaps to the app (disposing this widget). If the user
/// cancels, no callback arrives, so when the app resumes without a session
/// we clear the loading state and say so.
class OAuthSection extends StatefulWidget {
  final AuthService auth;
  final bool disabled;
  final ValueChanged<bool>? onBusyChanged;

  const OAuthSection({
    super.key,
    required this.auth,
    this.disabled = false,
    this.onBusyChanged,
  });

  @override
  State<OAuthSection> createState() => _OAuthSectionState();
}

class _OAuthSectionState extends State<OAuthSection> with WidgetsBindingObserver {
  OAuthProvider? _pending;
  String? _error;
  Timer? _resumeTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _resumeTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed || _pending == null) return;
    // Give the deep link a moment to deliver the session.
    _resumeTimer?.cancel();
    _resumeTimer = Timer(const Duration(seconds: 4), () {
      if (!mounted || _pending == null || widget.auth.currentSession != null) return;
      widget.auth.clearPendingProvider();
      _setPending(null, error: 'Sign-in was cancelled or did not finish. Please try again.');
    });
  }

  void _setPending(OAuthProvider? p, {String? error}) {
    setState(() {
      _pending = p;
      _error = error;
    });
    widget.onBusyChanged?.call(p != null);
  }

  Future<void> _start(OAuthProvider provider) async {
    _setPending(provider);
    final AuthResult result = await widget.auth.signInWithProvider(provider);
    if (!mounted) return;
    if (!result.success) _setPending(null, error: result.error);
  }

  @override
  Widget build(BuildContext context) {
    final bool busy = _pending != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const Row(
          children: <Widget>[
            Expanded(child: Divider(color: AppColors.surfaceHigh)),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Text('or', style: TextStyle(color: AppColors.textMuted)),
            ),
            Expanded(child: Divider(color: AppColors.surfaceHigh)),
          ],
        ),
        const SizedBox(height: 14),
        _ProviderButton(
          label: 'Continue with Google',
          icon: Icons.g_mobiledata_rounded,
          loading: _pending == OAuthProvider.google,
          onPressed: widget.disabled || busy ? null : () => _start(OAuthProvider.google),
        ),
        const SizedBox(height: 10),
        _ProviderButton(
          label: 'Continue with Facebook',
          icon: Icons.facebook_rounded,
          loading: _pending == OAuthProvider.facebook,
          onPressed: widget.disabled || busy ? null : () => _start(OAuthProvider.facebook),
        ),
        if (busy)
          TextButton(
            onPressed: () {
              widget.auth.clearPendingProvider();
              _setPending(null);
            },
            child: const Text('Cancel'),
          ),
        if (_error != null) ...<Widget>[
          const SizedBox(height: 10),
          ErrorBanner(message: _error!),
        ],
      ],
    );
  }
}

class _ProviderButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool loading;
  final VoidCallback? onPressed;

  const _ProviderButton({
    required this.label,
    required this.icon,
    required this.loading,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 52,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.textPrimary,
          side: const BorderSide(color: AppColors.surfaceHigh),
          backgroundColor: AppColors.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: loading
            ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(strokeWidth: 2.2, color: AppColors.accent),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(icon, size: 24),
                  const SizedBox(width: 10),
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
      ),
    );
  }
}
