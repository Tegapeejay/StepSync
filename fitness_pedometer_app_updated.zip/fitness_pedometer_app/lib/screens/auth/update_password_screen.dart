import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/theme.dart';
import '../../services/auth_service.dart';
import '../../services/backend.dart';
import '../../widgets/common.dart';

/// Shown when the user opens a password-reset link.
class UpdatePasswordScreen extends StatefulWidget {
  final AuthService auth;
  const UpdatePasswordScreen({super.key, required this.auth});

  @override
  State<UpdatePasswordScreen> createState() => _UpdatePasswordScreenState();
}

class _UpdatePasswordScreenState extends State<UpdatePasswordScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _password = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _password.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await Backend.client.auth.updateUser(UserAttributes(password: _password.text));
      if (!mounted) return;
      showAppSnack(context, 'Password updated');
      Navigator.of(context).maybePop();
    } catch (e) {
      if (mounted) setState(() => _error = friendlyBackendError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(backgroundColor: AppColors.background, title: const Text('Set a new password')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                AppTextField(
                  controller: _password,
                  label: 'New password',
                  icon: Icons.lock_outline_rounded,
                  obscure: true,
                  autofillHints: const <String>[AutofillHints.newPassword],
                  validator: (String? v) {
                    final String p = v ?? '';
                    if (p.length < 8) return 'Password must be at least 8 characters.';
                    if (!RegExp(r'[A-Za-z]').hasMatch(p) || !RegExp(r'[0-9]').hasMatch(p)) {
                      return 'Use at least one letter and one number.';
                    }
                    return null;
                  },
                ),
                if (_error != null) ...<Widget>[
                  const SizedBox(height: 12),
                  ErrorBanner(message: _error!),
                ],
                const SizedBox(height: 20),
                PrimaryButton(label: 'Update password', loading: _loading, onPressed: _save),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
