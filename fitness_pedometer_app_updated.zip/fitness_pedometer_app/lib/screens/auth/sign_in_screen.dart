import 'package:flutter/material.dart';

import '../../core/theme.dart';
import '../../services/analytics_service.dart';
import '../../services/auth_service.dart';
import '../../widgets/common.dart';
import 'oauth_section.dart';
import 'sign_up_screen.dart';

class SignInScreen extends StatefulWidget {
  final AuthService auth;
  final AnalyticsService analytics;
  const SignInScreen({super.key, required this.auth, required this.analytics});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _rememberMe = true;
  bool _loading = false;
  bool _oauthBusy = false;
  String? _formError;
  String? _info;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_loading) return;
    setState(() {
      _formError = null;
      _info = null;
    });
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);
    final AuthResult result = await widget.auth.login(
      email: _emailController.text,
      password: _passwordController.text,
      rememberMe: _rememberMe,
    );
    // On success AuthGate replaces this screen.
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (!result.success) _formError = result.error;
    });
  }

  Future<void> _forgotPassword() async {
    final String email = _emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      setState(() => _formError = 'Enter your email above, then tap "Forgot password?".');
      return;
    }
    setState(() => _loading = true);
    final AuthResult r = await widget.auth.sendPasswordReset(email);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _formError = r.success ? null : r.error;
      _info = r.success ? 'If an account exists for $email, a reset link is on its way.' : null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool busy = _loading || _oauthBusy;
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Form(
            key: _formKey,
            child: AutofillGroup(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: 40),
                  const BrandHeader(subtitle: 'Welcome back'),
                  const SizedBox(height: 36),
                  AppTextField(
                    controller: _emailController,
                    label: 'Email',
                    icon: Icons.alternate_email_rounded,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const <String>[AutofillHints.email],
                    enabled: !busy,
                    validator: (String? v) => (v ?? '').trim().isEmpty ? 'Email is required.' : null,
                  ),
                  const SizedBox(height: 14),
                  AppTextField(
                    controller: _passwordController,
                    label: 'Password',
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscurePassword,
                    autofillHints: const <String>[AutofillHints.password],
                    enabled: !busy,
                    validator: (String? v) => (v ?? '').isEmpty ? 'Password is required.' : null,
                    suffix: IconButton(
                      tooltip: _obscurePassword ? 'Show password' : 'Hide password',
                      icon: Icon(
                        _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                        color: AppColors.textMuted,
                        size: 20,
                      ),
                      onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: <Widget>[
                      Checkbox(
                        value: _rememberMe,
                        activeColor: AppColors.accent,
                        checkColor: Colors.black,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                        onChanged: busy ? null : (bool? v) => setState(() => _rememberMe = v ?? false),
                      ),
                      const Expanded(
                        child: Text('Remember me', style: TextStyle(color: AppColors.textSecondary)),
                      ),
                      TextButton(
                        onPressed: busy ? null : _forgotPassword,
                        child: const Text('Forgot password?'),
                      ),
                    ],
                  ),
                  if (_formError != null) ...<Widget>[
                    const SizedBox(height: 12),
                    ErrorBanner(message: _formError!),
                  ],
                  if (_info != null) ...<Widget>[
                    const SizedBox(height: 12),
                    ErrorBanner(
                      message: _info!,
                      color: AppColors.accent,
                      icon: Icons.mark_email_read_outlined,
                    ),
                  ],
                  const SizedBox(height: 22),
                  PrimaryButton(
                    label: 'Sign In',
                    loading: _loading,
                    onPressed: _oauthBusy ? null : _submit,
                  ),
                  const SizedBox(height: 22),
                  OAuthSection(
                    auth: widget.auth,
                    disabled: _loading,
                    onBusyChanged: (bool b) => setState(() => _oauthBusy = b),
                  ),
                  const SizedBox(height: 12),
                  AuthSwitchLink(
                    question: "Don't have an account?",
                    action: 'Sign Up',
                    onTap: busy
                        ? null
                        : () {
                            Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (_) => SignUpScreen(
                                  auth: widget.auth,
                                  analytics: widget.analytics,
                                ),
                              ),
                            );
                          },
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
