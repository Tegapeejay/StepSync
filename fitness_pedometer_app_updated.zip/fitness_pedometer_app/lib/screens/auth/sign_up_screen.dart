import 'package:flutter/material.dart';

import '../../core/theme.dart';
import '../../services/analytics_service.dart';
import '../../services/auth_service.dart';
import '../../widgets/common.dart';
import 'oauth_section.dart';

class SignUpScreen extends StatefulWidget {
  final AuthService auth;
  final AnalyticsService analytics;
  const SignUpScreen({super.key, required this.auth, required this.analytics});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmController = TextEditingController();

  bool _obscurePassword = true;
  bool _obscureConfirm = true;
  bool _loading = false;
  bool _oauthBusy = false;
  String? _formError;
  String? _confirmationSentTo;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  String? _validateEmail(String? value) {
    final String text = (value ?? '').trim();
    if (text.isEmpty) return 'Email is required.';
    final RegExp regex = RegExp(r'^[\w.+-]+@[\w-]+\.[\w.-]+$');
    if (!regex.hasMatch(text)) return 'Enter a valid email address.';
    return null;
  }

  Future<void> _submit() async {
    if (_loading) return;
    setState(() => _formError = null);
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);
    final AuthResult result = await widget.auth.register(
      name: _nameController.text,
      email: _emailController.text,
      password: _passwordController.text,
    );
    if (result.success) {
      // Event is attributed to the new user once a session exists.
      await widget.analytics.track('registration_completed');
    }
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (!result.success) {
        _formError = result.error;
      } else if (result.needsEmailConfirmation) {
        _confirmationSentTo = _emailController.text.trim();
      }
      // Otherwise AuthGate shows the app and closes this screen.
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool busy = _loading || _oauthBusy;
    if (_confirmationSentTo != null) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: SafeArea(
          child: StateMessage(
            icon: Icons.mark_email_unread_outlined,
            title: 'Confirm your email',
            message: 'We sent a confirmation link to $_confirmationSentTo. '
                'Open it on this phone to finish creating your account.',
            action: SizedBox(
              width: 220,
              child: PrimaryButton(
                label: 'Back to Sign In',
                onPressed: () => Navigator.of(context).maybePop(),
              ),
            ),
          ),
        ),
      );
    }
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Form(
            key: _formKey,
            child: AutofillGroup(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: 12),
                  const BrandHeader(subtitle: 'Create your account'),
                  const SizedBox(height: 28),
                  AppTextField(
                    controller: _nameController,
                    label: 'Full Name',
                    icon: Icons.person_outline_rounded,
                    keyboardType: TextInputType.name,
                    autofillHints: const <String>[AutofillHints.name],
                    enabled: !busy,
                    validator: (String? v) {
                      final String t = (v ?? '').trim();
                      if (t.isEmpty) return 'Full name is required.';
                      if (t.length > 80) return 'Name must be 80 characters or fewer.';
                      return null;
                    },
                  ),
                  const SizedBox(height: 14),
                  AppTextField(
                    controller: _emailController,
                    label: 'Email',
                    icon: Icons.alternate_email_rounded,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const <String>[AutofillHints.email],
                    enabled: !busy,
                    validator: _validateEmail,
                  ),
                  const SizedBox(height: 14),
                  AppTextField(
                    controller: _passwordController,
                    label: 'Password',
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscurePassword,
                    autofillHints: const <String>[AutofillHints.newPassword],
                    enabled: !busy,
                    validator: (String? v) {
                      final String p = v ?? '';
                      if (p.isEmpty) return 'Password is required.';
                      if (p.length < 8) return 'Password must be at least 8 characters.';
                      if (!RegExp(r'[A-Za-z]').hasMatch(p) || !RegExp(r'[0-9]').hasMatch(p)) {
                        return 'Use at least one letter and one number.';
                      }
                      return null;
                    },
                    suffix: IconButton(
                      tooltip: _obscurePassword ? 'Show password' : 'Hide password',
                      icon: Icon(
                        _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                        color: AppColors.textMuted,
                        size: 20,
                      ),
                      onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                  const SizedBox(height: 14),
                  AppTextField(
                    controller: _confirmController,
                    label: 'Confirm Password',
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscureConfirm,
                    enabled: !busy,
                    validator: (String? v) {
                      if ((v ?? '').isEmpty) return 'Please confirm your password.';
                      if (v != _passwordController.text) return 'Passwords do not match.';
                      return null;
                    },
                    suffix: IconButton(
                      tooltip: _obscureConfirm ? 'Show password' : 'Hide password',
                      icon: Icon(
                        _obscureConfirm ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                        color: AppColors.textMuted,
                        size: 20,
                      ),
                      onPressed: () => setState(() => _obscureConfirm = !_obscureConfirm),
                    ),
                  ),
                  if (_formError != null) ...<Widget>[
                    const SizedBox(height: 16),
                    ErrorBanner(message: _formError!),
                  ],
                  const SizedBox(height: 24),
                  PrimaryButton(
                    label: 'Create Account',
                    loading: _loading,
                    onPressed: _oauthBusy ? null : _submit,
                  ),
                  const SizedBox(height: 22),
                  OAuthSection(
                    auth: widget.auth,
                    disabled: _loading,
                    onBusyChanged: (bool b) => setState(() => _oauthBusy = b),
                  ),
                  const SizedBox(height: 12),
                  AuthSwitchLink(
                    question: 'Already have an account?',
                    action: 'Sign In',
                    onTap: busy ? null : () => Navigator.of(context).maybePop(),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
