# iOS setup

This project ships the iOS `Info.plist` with the required keys, but not the
full Xcode project (`Runner.xcodeproj`, Pods, etc.).

1. From the project root run:

       flutter create --platforms=ios .

   This generates the iOS runner without touching `lib/` or `pubspec.yaml`.

2. Replace the generated `ios/Runner/Info.plist` with the one in this folder
   (or copy these keys into it):
   - `NSMotionUsageDescription` — step counting
   - `NSLocationWhenInUseUsageDescription` — GPS sessions
   - `CFBundleURLTypes` with scheme `io.stepsync.app` — OAuth callback
   - `LSApplicationQueriesSchemes` — opening Spotify / YouTube

3. Enable the `permission_handler` macros in `ios/Podfile` (`post_install`):

       config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] ||= [
         '$(inherited)',
         'PERMISSION_SENSORS=1',
         'PERMISSION_LOCATION_WHENINUSE=0',
       ]

   (`permission_handler` is only used for motion; location is handled by
   `geolocator`, which needs no macro.)

4. Set the iOS deployment target to at least 13.0 in `ios/Podfile`
   (`platform :ios, '13.0'`), as required by `supabase_flutter`.

5. Run on a physical iPhone (Core Motion is not available in the simulator).

No background modes are enabled: GPS sessions and local music play while the
app is in the foreground.
