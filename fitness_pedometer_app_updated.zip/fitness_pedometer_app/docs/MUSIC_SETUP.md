# Music integrations — what's supported and why

The Music tab is modular: each source is independent, and a failure (app not
installed, bad link, unplayable file) shows a message without affecting step
counting, GPS sessions or sync. The pedometer reads the phone's hardware
sensor, so it keeps counting while any music app plays.

## What the app does today

| Source | Behaviour | Setup needed |
|---|---|---|
| **Music on this phone** | Plays an audio file the user picks via the system file picker (`file_picker` + `just_audio`). Audio focus via `audio_session`: phone calls / other apps pause it, unplugging headphones pauses it. Stops when the app closes. | None |
| **Spotify** | Opens playlists, tracks or searches in the **Spotify app** (or the web player if the app isn't installed). Users can save their own `open.spotify.com` / `spotify:` links. | None |
| **YouTube / YouTube Music** | Opens videos, playlists or searches in the **YouTube / YouTube Music app** (or browser). Users can save their own links. | None |
| Recently opened | Last 10 opened links, stored only on this device. | — |

No credentials are required for any of the above, and nothing is embedded,
downloaded or played from Spotify or YouTube inside StepSync.

## Why there is no in-app Spotify playback

Spotify's options, and their requirements:

1. **Deep links / web links** (implemented): open content in the Spotify
   app. No developer account needed.
2. **Spotify Web API** — metadata (playlist names, artwork) and
   *Player* endpoints that control playback on an existing Spotify device.
   Requires a Spotify developer app, user OAuth (Authorization Code with
   PKCE — no client secret in the app), and **Spotify Premium** for playback
   control. New apps start in *development mode* (limited to allow-listed
   users) and must apply for extended quota to go public.
3. **Spotify App Remote SDK** (Android/iOS native) — controls the installed
   Spotify app; also needs Premium for on-demand playback, a registered
   package name + SHA-1 fingerprint, and native platform channels.
4. **Full track playback inside your own app** — not available to ordinary
   third-party apps; requires a commercial agreement with Spotify.

So StepSync deliberately stops at option 1. To add metadata or remote
control later, register an app at <https://developer.spotify.com/dashboard>,
add the redirect URI `io.stepsync.app://spotify-callback`, use PKCE, and
implement it as a new provider class next to `MusicService` so it stays
optional. Never ship a Spotify client secret in the app.

## Why YouTube opens externally

YouTube's API Terms do not allow downloading or extracting audio, playing
audio with the video hidden, or bypassing ads. Background playback is a
YouTube Premium feature of YouTube's own apps. The compliant options are:

1. **Open in the YouTube / YouTube Music app** (implemented).
2. **Embedded player** (`youtube_player_iframe` or a WebView with the IFrame
   API): video must stay visible, ads and branding stay intact, and playback
   stops when the app is backgrounded. Requires respecting the YouTube API
   Services Terms; an API key is only needed if you also call the Data API
   (search / metadata) — create it in Google Cloud, restrict it to the YouTube
   Data API v3 and your Android package/iOS bundle id, and keep quota limits in
   mind.

Option 2 was not implemented because it would pause during exercise as soon
as the screen locks, which is a poor experience for workouts.

## Privacy

Analytics record only `music_opened` with the provider name and whether it
opened — never the link, title or file name. Saved and recent links stay on
the device and are not uploaded.
