# StepSync upgrade — audit & implementation plan

## What exists (preserved)

Single-file app (`lib/main.dart`, ~2,600 lines), `ChangeNotifier` + `ListenableBuilder`
state, no backend:

- Pedometer: `pedometer` streams, persisted daily baseline (reboot / new-day
  handling), walking/stopped status, activity-recognition permission flow,
  "sensor unavailable" state.
- Stride distance: `steps × stride`, stride from height × sex factor or manual.
- Profile: name, height, sex, stride, daily goal (SharedPreferences).
- Local auth: SHA-256(salt::password) in SharedPreferences, remember-me.
- UI: dark `#121212` theme, progress ring, metric tiles, status chip,
  Home / Activity / Profile tabs.

## Changes

| Area | Decision |
|---|---|
| Structure | Split `main.dart` into `core/`, `models/`, `services/`, `widgets/`, `screens/` (same classes and look; required to keep auth, GPS, music, sync and admin separated). |
| State | Keep `ChangeNotifier` + `ListenableBuilder` — it is sound and needs no new package. |
| Auth | **Replaced** local SharedPreferences accounts with Supabase Auth (email/password, Google, Facebook). Local accounts cannot be migrated (their passwords are only hashed on-device); users re-register. Old local step history keys are unaffected. |
| Pedometer | Kept as-is; storage keys now use the Supabase user id; emits a "day closed" total so yesterday's final steps get synced. |
| Distance | Kept stride estimate; added GPS sessions (`geolocator`) with noise/jump filtering and per-session stride-vs-GPS comparison. |
| History | Supabase `daily_activity` (one row per user per local date, max-steps reconciliation) + `gps_sessions`; offline retry queue. Daily / weekly / monthly reports with `fl_chart`. |
| Music | New Music tab: local audio files (`just_audio`, `file_picker`), Spotify and YouTube via official links/apps (`url_launcher`). No in-app Spotify/YouTube playback (see `docs/MUSIC_SETUP.md`). |
| Admin | `admin_users` table managed only from the SQL editor, `is_admin()` and `SECURITY DEFINER` stats RPCs that check it, Edge Functions for suspend/delete using the service role server-side. |

## New dependencies

`supabase_flutter`, `geolocator`, `fl_chart`, `url_launcher`, `just_audio`,
`audio_session`, `file_picker`. Removed: `crypto` (local hashing no longer used).
Dev: `flutter_test`.

## Credentials you must supply

Supabase URL + publishable/anon key; Google OAuth Web client ID/secret;
Facebook App ID/secret (both entered in the Supabase dashboard, never in the
app). Optional: your own Spotify/YouTube playlist links.

## Limits

- GPS tracks while the app is open (foreground). No background location
  service is implemented.
- Store downloads cannot be measured from Supabase; the dashboard shows
  first-launch events, labelled as such.
- Nothing could be compiled here (no Flutter SDK on this machine).
