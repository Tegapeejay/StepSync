package com.example.fitness_pedometer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
