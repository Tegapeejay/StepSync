-- =============================================================================
-- StepSync — Supabase schema, security and admin analytics
-- =============================================================================
-- Run once in a NEW Supabase project: Dashboard → SQL Editor → New query →
-- paste this whole file → Run. It is written to be re-runnable where
-- practical (IF NOT EXISTS / CREATE OR REPLACE), but review before re-running
-- on a project that already holds data.
--
-- Security model (summary)
--   * Credentials live only in Supabase Auth (auth.users). No password table.
--   * Row Level Security is ENABLED on every table; users can only reach
--     their own rows.
--   * Column privileges stop users editing protected profile fields
--     (account_status, email, signup_provider).
--   * Admins are listed in public.admin_users, which clients cannot read or
--     write. Grant admin only from this SQL editor (see the bottom section).
--   * Admin statistics are exposed through SECURITY DEFINER functions that
--     re-check public.is_admin() on every call.
--   * Sign-in events are recorded by a SECURITY DEFINER function that derives
--     the method from the caller's JWT and allows one row per session, so a
--     client cannot inflate sign-in counts.
--
-- Time zones
--   * daily_activity.activity_date and gps_sessions.activity_date are the
--     user's LOCAL calendar date, sent by the app.
--   * Admin "today / this week / this month" windows are computed in UTC.
-- =============================================================================

create extension if not exists pgcrypto;

-- -----------------------------------------------------------------------------
-- Helper: updated_at trigger
-- -----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- =============================================================================
-- A. PROFILES
-- =============================================================================
create table if not exists public.profiles (
  id                      uuid primary key references auth.users (id) on delete cascade,
  full_name               text not null default '' check (char_length(full_name) <= 80),
  email                   text,
  avatar_url              text check (avatar_url is null or char_length(avatar_url) <= 500),
  height_cm               numeric(5,1) not null default 170 check (height_cm between 80 and 250),
  sex                     text not null default 'unspecified'
                            check (sex in ('male', 'female', 'unspecified')),
  stride_length_m         numeric(4,3) not null default 0.704
                            check (stride_length_m between 0.3 and 1.5),
  stride_is_custom        boolean not null default false,
  daily_step_goal         integer not null default 10000
                            check (daily_step_goal between 1000 and 100000),
  preferred_distance_unit text not null default 'km'
                            check (preferred_distance_unit in ('km', 'mi')),
  signup_provider         text,
  account_status          text not null default 'active'
                            check (account_status in ('active', 'suspended')),
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);

create index if not exists profiles_created_at_idx on public.profiles (created_at);

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

-- Create the profile automatically when an account is created (email or OAuth).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url, signup_provider)
  values (
    new.id,
    new.email,
    left(coalesce(new.raw_user_meta_data ->> 'full_name',
                  new.raw_user_meta_data ->> 'name', ''), 80),
    left(coalesce(new.raw_user_meta_data ->> 'avatar_url',
                  new.raw_user_meta_data ->> 'picture'), 500),
    coalesce(new.raw_app_meta_data ->> 'provider', 'email')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Backfill: accounts created before this script ran get a profile too
-- (clients can't insert profiles themselves).
insert into public.profiles (id, email, signup_provider)
select u.id, u.email, coalesce(u.raw_app_meta_data ->> 'provider', 'email')
from auth.users u
on conflict (id) do nothing;

-- Keep the copied email in sync if the user changes it in Auth.
create or replace function public.handle_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.email is distinct from old.email then
    update public.profiles set email = new.email where id = new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_email_changed on auth.users;
create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row execute function public.handle_user_email_change();

-- =============================================================================
-- E. ADMINISTRATORS (server-managed; no client access at all)
-- =============================================================================
create table if not exists public.admin_users (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  granted_at timestamptz not null default now(),
  note       text
);

-- True when the CURRENT caller is an admin. Takes no argument, so it can't be
-- used to probe whether other users are admins.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users a where a.user_id = auth.uid()
  );
$$;

-- True unless the CURRENT caller's account is suspended. Used in write
-- policies so a suspended user's still-valid access token (up to 1 hour)
-- can't add or change data.
create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select not exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.account_status = 'suspended'
  );
$$;

-- =============================================================================
-- B. DAILY FITNESS RECORDS (one row per user per local date)
-- =============================================================================
create table if not exists public.daily_activity (
  id                bigint generated always as identity primary key,
  user_id           uuid not null references auth.users (id) on delete cascade,
  activity_date     date not null,
  steps             integer not null default 0 check (steps between 0 and 200000),
  stride_distance_m numeric(9,1) not null default 0 check (stride_distance_m >= 0),
  gps_distance_m    numeric(9,1) not null default 0 check (gps_distance_m >= 0),
  active_minutes    integer not null default 0 check (active_minutes between 0 and 1440),
  daily_goal        integer not null default 10000 check (daily_goal between 0 and 100000),
  goal_achieved     boolean generated always as (daily_goal > 0 and steps >= daily_goal) stored,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint daily_activity_user_date_key unique (user_id, activity_date)
);

create index if not exists daily_activity_date_idx on public.daily_activity (activity_date);

drop trigger if exists daily_activity_set_updated_at on public.daily_activity;
create trigger daily_activity_set_updated_at
  before update on public.daily_activity
  for each row execute function public.set_updated_at();

-- Upsert today's totals. Reconciliation rule: values only ever INCREASE
-- (GREATEST), so a late or retried upload carrying a smaller step count can
-- never overwrite a larger valid total. Runs with the caller's rights, so
-- RLS still applies.
create or replace function public.upsert_daily_activity(
  p_activity_date     date,
  p_steps             integer,
  p_stride_distance_m numeric,
  p_active_minutes    integer default 0,
  p_daily_goal        integer default 10000
)
returns void
language plpgsql
security invoker
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  -- Local dates can be up to ~14h ahead of UTC; allow a day of slack.
  if p_activity_date > (now() at time zone 'utc')::date + 1
     or p_activity_date < (now() at time zone 'utc')::date - 400 then
    raise exception 'activity_date out of range' using errcode = '22023';
  end if;

  insert into public.daily_activity
    (user_id, activity_date, steps, stride_distance_m, active_minutes, daily_goal)
  values
    (auth.uid(), p_activity_date, greatest(p_steps, 0),
     greatest(p_stride_distance_m, 0), greatest(coalesce(p_active_minutes, 0), 0),
     p_daily_goal)
  on conflict (user_id, activity_date) do update set
    steps             = greatest(public.daily_activity.steps, excluded.steps),
    stride_distance_m = greatest(public.daily_activity.stride_distance_m, excluded.stride_distance_m),
    active_minutes    = greatest(public.daily_activity.active_minutes, excluded.active_minutes),
    daily_goal        = excluded.daily_goal;
end;
$$;

-- =============================================================================
-- C. GPS ACTIVITY SESSIONS (summaries only — no coordinates are stored)
-- =============================================================================
create table if not exists public.gps_sessions (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references auth.users (id) on delete cascade,
  activity_date    date not null,
  started_at       timestamptz not null,
  ended_at         timestamptz not null,
  gps_distance_m   numeric(9,1) not null check (gps_distance_m between 0 and 300000),
  duration_seconds integer not null check (duration_seconds between 0 and 86400),
  avg_speed_mps    numeric(6,3) check (avg_speed_mps is null or avg_speed_mps between 0 and 15),
  steps            integer check (steps is null or steps between 0 and 200000),
  stride_length_m  numeric(4,3) check (stride_length_m is null or stride_length_m between 0 and 1.5),
  status           text not null default 'completed' check (status in ('completed', 'discarded')),
  created_at       timestamptz not null default now(),
  constraint gps_sessions_time_order check (ended_at >= started_at)
);

create index if not exists gps_sessions_user_started_idx on public.gps_sessions (user_id, started_at desc);
create index if not exists gps_sessions_created_idx on public.gps_sessions (created_at);

-- Keep daily_activity.gps_distance_m equal to the sum of that day's
-- completed sessions.
create or replace function public.refresh_daily_gps_distance()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid;
  v_date date;
  v_total numeric;
begin
  if tg_op = 'DELETE' then
    v_user := old.user_id; v_date := old.activity_date;
  else
    v_user := new.user_id; v_date := new.activity_date;
  end if;

  select coalesce(sum(gps_distance_m), 0) into v_total
  from public.gps_sessions
  where user_id = v_user and activity_date = v_date and status = 'completed';

  -- On delete, only update an existing row: during account deletion the
  -- user's daily_activity rows (and the user) may already be gone, and
  -- inserting would violate the foreign key and abort the deletion.
  if tg_op = 'DELETE' then
    update public.daily_activity set gps_distance_m = v_total
    where user_id = v_user and activity_date = v_date;
    return null;
  end if;

  insert into public.daily_activity (user_id, activity_date, gps_distance_m)
  values (v_user, v_date, v_total)
  on conflict (user_id, activity_date) do update
    set gps_distance_m = excluded.gps_distance_m;

  return null;
end;
$$;

drop trigger if exists gps_sessions_refresh_daily on public.gps_sessions;
create trigger gps_sessions_refresh_daily
  after insert or update or delete on public.gps_sessions
  for each row execute function public.refresh_daily_gps_distance();

-- =============================================================================
-- D. ANALYTICS
-- =============================================================================

-- Sign-ins: one row per Auth session, written only by record_sign_in().
create table if not exists public.sign_in_events (
  id          bigint generated always as identity primary key,
  user_id     uuid not null references auth.users (id) on delete cascade,
  session_id  uuid not null unique,
  provider    text not null check (provider in ('email', 'google', 'facebook', 'other')),
  app_version text check (app_version is null or char_length(app_version) <= 20),
  platform    text check (platform is null or platform in ('android', 'ios', 'web', 'other')),
  created_at  timestamptz not null default now()
);

create index if not exists sign_in_events_created_idx on public.sign_in_events (created_at);
create index if not exists sign_in_events_user_idx on public.sign_in_events (user_id, created_at);

-- Called by the app right after a successful sign-in (not on session
-- restore). The method comes from the JWT `amr` claim; an OAuth provider name
-- is only accepted if the user really has that identity. The unique
-- session_id makes repeated calls harmless.
create or replace function public.record_sign_in(
  p_provider    text default null,
  p_app_version text default null,
  p_platform    text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid      uuid := auth.uid();
  v_session  uuid;
  v_methods  text[];
  v_provider text := 'other';
begin
  if v_uid is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;

  v_session := nullif(auth.jwt() ->> 'session_id', '')::uuid;
  if v_session is null then
    return;
  end if;

  select coalesce(array_agg(elem ->> 'method'), '{}')
    into v_methods
  from jsonb_array_elements(coalesce(auth.jwt() -> 'amr', '[]'::jsonb)) as elem;

  if 'oauth' = any (v_methods) then
    if p_provider in ('google', 'facebook') and exists (
         select 1 from auth.identities i
         where i.user_id = v_uid and i.provider = p_provider) then
      v_provider := p_provider;
    end if;
  elsif v_methods && array['password', 'otp', 'magiclink', 'email/signup'] then
    v_provider := 'email';
  end if;

  insert into public.sign_in_events (user_id, session_id, provider, app_version, platform)
  values (
    v_uid, v_session, v_provider,
    left(p_app_version, 20),
    case when p_platform in ('android', 'ios', 'web') then p_platform else 'other' end
  )
  on conflict (session_id) do nothing;
end;
$$;

-- General product events. No passwords, tokens or precise locations.
create table if not exists public.analytics_events (
  id              bigint generated always as identity primary key,
  user_id         uuid references auth.users (id) on delete cascade,
  installation_id uuid,
  event_name      text not null check (event_name in (
                    'app_first_open', 'app_open',
                    'registration_completed', 'logout',
                    'tracking_started', 'tracking_completed',
                    'user_active', 'music_opened')),
  app_version     text check (app_version is null or char_length(app_version) <= 20),
  platform        text check (platform is null or platform in ('android', 'ios', 'web', 'other')),
  metadata        jsonb not null default '{}'::jsonb
                    check (jsonb_typeof(metadata) = 'object' and pg_column_size(metadata) <= 2048),
  created_at      timestamptz not null default now()
);

create index if not exists analytics_events_name_created_idx on public.analytics_events (event_name, created_at);
create index if not exists analytics_events_user_created_idx on public.analytics_events (user_id, created_at);

-- Clients cannot back-date or future-date events.
create or replace function public.analytics_force_timestamp()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.created_at := now();
  return new;
end;
$$;

drop trigger if exists analytics_events_force_ts on public.analytics_events;
create trigger analytics_events_force_ts
  before insert on public.analytics_events
  for each row execute function public.analytics_force_timestamp();

-- =============================================================================
-- ROW LEVEL SECURITY
-- =============================================================================
alter table public.profiles         enable row level security;
alter table public.admin_users      enable row level security;
alter table public.daily_activity   enable row level security;
alter table public.gps_sessions     enable row level security;
alter table public.sign_in_events   enable row level security;
alter table public.analytics_events enable row level security;

-- Profiles: read and update your own row only (insert happens via trigger,
-- delete via account deletion).
drop policy if exists "profiles: read own" on public.profiles;
create policy "profiles: read own" on public.profiles
  for select to authenticated
  using ((select auth.uid()) = id);

drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: update own" on public.profiles
  for update to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);

-- Daily activity: full access to own rows only.
drop policy if exists "daily_activity: read own" on public.daily_activity;
create policy "daily_activity: read own" on public.daily_activity
  for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "daily_activity: insert own" on public.daily_activity;
create policy "daily_activity: insert own" on public.daily_activity
  for insert to authenticated
  with check ((select auth.uid()) = user_id and (select public.is_active_user()));

drop policy if exists "daily_activity: update own" on public.daily_activity;
create policy "daily_activity: update own" on public.daily_activity
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id and (select public.is_active_user()));

drop policy if exists "daily_activity: delete own" on public.daily_activity;
create policy "daily_activity: delete own" on public.daily_activity
  for delete to authenticated
  using ((select auth.uid()) = user_id);

-- GPS sessions: read, insert, delete own. Sessions are immutable once saved.
drop policy if exists "gps_sessions: read own" on public.gps_sessions;
create policy "gps_sessions: read own" on public.gps_sessions
  for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "gps_sessions: insert own" on public.gps_sessions;
create policy "gps_sessions: insert own" on public.gps_sessions
  for insert to authenticated
  with check (
    (select auth.uid()) = user_id
    and started_at <= now() + interval '5 minutes'
    and (select public.is_active_user())
  );

drop policy if exists "gps_sessions: delete own" on public.gps_sessions;
create policy "gps_sessions: delete own" on public.gps_sessions
  for delete to authenticated
  using ((select auth.uid()) = user_id);

-- Analytics: insert-only. Anonymous installs may only send open events;
-- signed-in users may only send events for themselves. Nobody can read
-- events directly — admins use the RPCs below.
drop policy if exists "analytics: insert anonymous open events" on public.analytics_events;
create policy "analytics: insert anonymous open events" on public.analytics_events
  for insert to anon, authenticated
  with check (user_id is null and event_name in ('app_first_open', 'app_open'));

drop policy if exists "analytics: insert own events" on public.analytics_events;
create policy "analytics: insert own events" on public.analytics_events
  for insert to authenticated
  with check (user_id = (select auth.uid()) and event_name <> 'app_first_open'
              and (select public.is_active_user()));

-- admin_users and sign_in_events: RLS on with NO policies = no client access.

-- =============================================================================
-- TABLE & COLUMN PRIVILEGES (defence in depth on top of RLS)
-- =============================================================================
revoke all on public.profiles, public.admin_users, public.daily_activity,
              public.gps_sessions, public.sign_in_events, public.analytics_events
  from anon, authenticated;

grant select on public.profiles to authenticated;
grant update (full_name, avatar_url, height_cm, sex, stride_length_m, stride_is_custom,
              daily_step_goal, preferred_distance_unit)
  on public.profiles to authenticated;

grant select, delete on public.daily_activity to authenticated;
grant insert (user_id, activity_date, steps, stride_distance_m, active_minutes, daily_goal)
  on public.daily_activity to authenticated;
grant update (steps, stride_distance_m, active_minutes, daily_goal)
  on public.daily_activity to authenticated;

grant select, delete on public.gps_sessions to authenticated;
grant insert (id, user_id, activity_date, started_at, ended_at, gps_distance_m,
              duration_seconds, avg_speed_mps, steps, stride_length_m, status)
  on public.gps_sessions to authenticated;

grant insert (user_id, installation_id, event_name, app_version, platform, metadata)
  on public.analytics_events to anon, authenticated;

-- =============================================================================
-- ADMIN FUNCTIONS (each re-checks is_admin(); safe to expose via RPC)
-- =============================================================================

-- Dashboard numbers. Definitions:
--   registrations    = rows in auth.users created in the window
--   sign_ins         = sign-in events (one per Auth session) in the window
--   unique_sign_ins  = distinct users with ≥1 sign-in event in the window
--   active_users     = distinct users who, in the window, signed in OR
--                      recorded steps OR saved a GPS session OR sent an event
--   first_opens      = distinct installation ids sending 'app_first_open'
--                      (NOT store downloads)
create or replace function public.admin_dashboard_stats()
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  t_day   timestamptz := date_trunc('day',   now() at time zone 'utc') at time zone 'utc';
  t_week  timestamptz := date_trunc('week',  now() at time zone 'utc') at time zone 'utc';
  t_month timestamptz := date_trunc('month', now() at time zone 'utc') at time zone 'utc';
  d_day   date := (now() at time zone 'utc')::date;
  d_week  date := date_trunc('week',  now() at time zone 'utc')::date;
  d_month date := date_trunc('month', now() at time zone 'utc')::date;
  result  jsonb;
begin
  if not public.is_admin() then
    raise exception 'not authorized' using errcode = '42501';
  end if;

  with
  active as (
    select user_id, created_at::date as d from public.sign_in_events
    union all
    select user_id, activity_date from public.daily_activity where steps > 0
    union all
    select user_id, activity_date from public.gps_sessions where status = 'completed'
    union all
    select user_id, created_at::date from public.analytics_events where user_id is not null
  )
  select jsonb_build_object(
    'generated_at', now(),
    'users', jsonb_build_object(
      'total',        (select count(*) from auth.users),
      'new_today',    (select count(*) from auth.users where created_at >= t_day),
      'new_week',     (select count(*) from auth.users where created_at >= t_week),
      'new_month',    (select count(*) from auth.users where created_at >= t_month),
      'by_signup_provider', (select coalesce(jsonb_object_agg(p, c), '{}'::jsonb) from (
          select coalesce(signup_provider, 'email') p, count(*) c
          from public.profiles group by 1) s),
      'suspended',    (select count(*) from public.profiles where account_status = 'suspended')
    ),
    'sign_ins', jsonb_build_object(
      'total',        (select count(*) from public.sign_in_events),
      'today',        (select count(*) from public.sign_in_events where created_at >= t_day),
      'week',         (select count(*) from public.sign_in_events where created_at >= t_week),
      'month',        (select count(*) from public.sign_in_events where created_at >= t_month),
      'unique_today', (select count(distinct user_id) from public.sign_in_events where created_at >= t_day),
      'unique_week',  (select count(distinct user_id) from public.sign_in_events where created_at >= t_week),
      'unique_month', (select count(distinct user_id) from public.sign_in_events where created_at >= t_month),
      'by_provider',  (select coalesce(jsonb_object_agg(provider, c), '{}'::jsonb) from (
          select provider, count(*) c from public.sign_in_events group by provider) s)
    ),
    'active_users', jsonb_build_object(
      'today', (select count(distinct user_id) from active where d >= d_day),
      'week',  (select count(distinct user_id) from active where d >= d_week),
      'month', (select count(distinct user_id) from active where d >= d_month)
    ),
    'fitness', jsonb_build_object(
      'users_with_activity_today', (select count(*) from public.daily_activity
                                    where activity_date = d_day and steps > 0),
      'users_with_activity_week',  (select count(distinct user_id) from public.daily_activity
                                    where activity_date >= d_week and steps > 0),
      'avg_daily_steps_30d',       (select coalesce(round(avg(steps)), 0) from public.daily_activity
                                    where activity_date >= d_day - 29 and steps > 0),
      'gps_sessions_week',         (select count(*) from public.gps_sessions
                                    where status = 'completed' and created_at >= t_week),
      'gps_sessions_month',        (select count(*) from public.gps_sessions
                                    where status = 'completed' and created_at >= t_month),
      'users_reached_goal_today',  (select count(*) from public.daily_activity
                                    where activity_date = d_day and goal_achieved)
    ),
    'installs', jsonb_build_object(
      'first_opens_total', (select count(distinct installation_id) from public.analytics_events
                            where event_name = 'app_first_open'),
      'first_opens_today', (select count(distinct installation_id) from public.analytics_events
                            where event_name = 'app_first_open' and created_at >= t_day),
      'first_opens_week',  (select count(distinct installation_id) from public.analytics_events
                            where event_name = 'app_first_open' and created_at >= t_week),
      'first_opens_month', (select count(distinct installation_id) from public.analytics_events
                            where event_name = 'app_first_open' and created_at >= t_month),
      'by_platform', (select coalesce(jsonb_object_agg(coalesce(platform, 'unknown'), c), '{}'::jsonb) from (
          select platform, count(distinct installation_id) c from public.analytics_events
          where event_name = 'app_first_open' group by platform) s),
      'by_app_version', (select coalesce(jsonb_object_agg(coalesce(app_version, 'unknown'), c), '{}'::jsonb) from (
          select app_version, count(distinct installation_id) c from public.analytics_events
          where event_name in ('app_first_open', 'app_open') and created_at >= now() - interval '30 days'
          group by app_version order by c desc limit 10) s)
    )
  ) into result;

  return result;
end;
$$;

-- Sign-ins per UTC day for the last p_days days (events and unique users).
create or replace function public.admin_sign_ins_daily(p_days integer default 30)
returns table (day date, sign_ins bigint, unique_users bigint)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.is_admin() then
    raise exception 'not authorized' using errcode = '42501';
  end if;
  return query
    -- generate_series over a date range: integers added to a date, so no
    -- time-zone conversion is involved.
    select g.d,
           count(e.id),
           count(distinct e.user_id)
    from generate_series(0, least(greatest(p_days, 1), 365) - 1) as s(i)
    cross join lateral (
      select (now() at time zone 'utc')::date - s.i as d
    ) as g
    left join public.sign_in_events e
      on (e.created_at at time zone 'utc')::date = g.d
    group by g.d
    order by g.d;
end;
$$;

-- Paginated, server-filtered user list. Never returns password hashes,
-- tokens or fitness details.
create or replace function public.admin_list_users(
  p_search text default null,
  p_limit  integer default 25,
  p_offset integer default 0
)
returns table (
  user_id         uuid,
  full_name       text,
  email           text,
  created_at      timestamptz,
  last_sign_in_at timestamptz,
  providers       text,
  account_status  text,
  total_count     bigint
)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_search text := nullif(trim(p_search), '');
begin
  if not public.is_admin() then
    raise exception 'not authorized' using errcode = '42501';
  end if;
  return query
    with filtered as (
      select u.id, p.full_name, u.email::text as email, u.created_at, u.last_sign_in_at,
             coalesce((select string_agg(x, ', ')
                       from jsonb_array_elements_text(u.raw_app_meta_data -> 'providers') as x),
                      u.raw_app_meta_data ->> 'provider', 'email') as providers,
             coalesce(p.account_status, 'active') as account_status
      from auth.users u
      left join public.profiles p on p.id = u.id
      where v_search is null
         or u.email ilike '%' || v_search || '%'
         or p.full_name ilike '%' || v_search || '%'
    )
    select f.id, f.full_name, f.email, f.created_at, f.last_sign_in_at, f.providers,
           f.account_status, count(*) over () as total_count
    from filtered f
    order by f.created_at desc
    limit least(greatest(p_limit, 1), 100)
    offset greatest(p_offset, 0);
end;
$$;

-- Retention helper: delete analytics older than p_keep_days (admins or the
-- SQL editor only). Schedule with pg_cron if desired, e.g.:
--   select cron.schedule('purge-analytics', '0 3 * * *',
--          $$ select public.purge_old_analytics(365) $$);
create or replace function public.purge_old_analytics(p_keep_days integer default 365)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count bigint;
begin
  if auth.uid() is not null and not public.is_admin() then
    raise exception 'not authorized' using errcode = '42501';
  end if;
  delete from public.analytics_events
  where created_at < now() - make_interval(days => greatest(p_keep_days, 30));
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- =============================================================================
-- FUNCTION PRIVILEGES
-- =============================================================================
revoke execute on all functions in schema public from public, anon;

grant execute on function public.is_admin()                                to authenticated;
grant execute on function public.is_active_user()                          to authenticated;
grant execute on function public.upsert_daily_activity(date, integer, numeric, integer, integer)
                                                                          to authenticated;
grant execute on function public.record_sign_in(text, text, text)          to authenticated;
grant execute on function public.admin_dashboard_stats()                   to authenticated;
grant execute on function public.admin_sign_ins_daily(integer)             to authenticated;
grant execute on function public.admin_list_users(text, integer, integer)  to authenticated;
grant execute on function public.purge_old_analytics(integer)              to authenticated;

-- Trigger functions are never called directly by clients.
revoke execute on function public.handle_new_user()            from authenticated;
revoke execute on function public.handle_user_email_change()   from authenticated;
revoke execute on function public.refresh_daily_gps_distance() from authenticated;

-- =============================================================================
-- BOOTSTRAP THE FIRST ADMIN (run manually, after that person has signed up)
-- =============================================================================
-- Replace the email and run ONLY this statement in the SQL editor. There is
-- deliberately no API, policy or function that lets a client do this.
--
--   insert into public.admin_users (user_id, note)
--   select id, 'initial admin' from auth.users where email = 'you@example.com'
--   on conflict (user_id) do nothing;
--
-- To revoke:
--   delete from public.admin_users
--   where user_id = (select id from auth.users where email = 'you@example.com');
-- =============================================================================
