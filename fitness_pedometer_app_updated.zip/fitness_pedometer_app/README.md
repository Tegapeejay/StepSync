# StepSync — Flutter Pedometer, GPS & Fitness History

StepSync counts your steps with the phone's hardware step counter, estimates
distance from your stride, measures distance with GPS on demand and compares
the two, stores your history in Supabase, plays/opens workout music, and
gives administrators an aggregated analytics dashboard.

> **Verification status:** this upgrade was written on a machine without the
> Flutter SDK, so `flutter analyze`, `flutter test` and device builds have
> **not** been run yet. Run them first (see [Run](#run)) and expect a few
> small fixes. Nothing in Supabase, Google, Facebook or Spotify has been
> configured — all credentials are placeholders.

- Setup (Supabase, Google, Facebook, admin, env): [`SUPABASE_SETUP.md`](SUPABASE_SETUP.md)
- Database schema & security: [`supabase_setup.sql`](supabase_setup.sql)
- Music providers & limits: [`docs/MUSIC_SETUP.md`](docs/MUSIC_SETUP.md)
- Audit & plan: [`docs/IMPLEMENTATION_PLAN.md`](docs/IMPLEMENTATION_PLAN.md)

---

## Features

**Kept from the original app:** dark `#121212` UI, live step counting with
the persisted daily baseline, walking/stopped status, stride estimated from
height and sex (or set manually), circular goal ring, profile, permission and
"sensor unavailable" states.

**New:**

| Area | |
|---|---|
| Auth | Supabase email/password sign-up & sign-in, **Google** and **Facebook** (browser OAuth + PKCE + deep link), "Remember me", session restore, sign-out, password reset, cancelled-OAuth handling, account deletion. |
| Dual distance | **Stride estimate** = steps × stride length. **GPS distance** from explicit start/stop sessions with accuracy, jitter, jump and signal-loss filtering. Side-by-side comparison per session with absolute and % difference. |
| History | Daily / weekly / monthly reports (totals, averages, best day, goal rate, charts), synced to Supabase with an offline retry queue. |
| Music | Local audio file playback; Spotify, YouTube and YouTube Music via their apps; saved & recent links. |
| Admin | Protected tab: registrations, sign-in events vs unique users, provider split, active users, aggregated fitness, first-launch installs, paginated user list, suspend/reactivate. |

---

## Run

```bash
cp .env.example .env
```

Fill in `.env` (see `SUPABASE_SETUP.md`), then:

```bash
flutter pub get
```

```bash
flutter analyze
```

```bash
flutter test
```

```bash
flutter run --dart-define-from-file=.env
```

Release build:

```bash
flutter build apk --release --dart-define-from-file=.env
```

Requirements: Flutter stable **3.27+** (Dart 3.4+), JDK 17, a **physical
phone** for step counting and GPS (emulators usually lack a step sensor).

If Gradle complains about plugin / Kotlin versions with your Flutter
version, regenerate the Android scaffolding without touching `lib/`:

```bash
flutter create --platforms=android .
```

then restore `android/app/src/main/AndroidManifest.xml` from this project
(it carries the permissions and the OAuth deep link).

---

## How distance is measured

**Stride estimate (all day, always on):**

```
stride (m)       = height (cm) × factor / 100   (0.415 male, 0.413 female, 0.414 unspecified)
stride distance  = steps × stride
```

**GPS (only during a session you start):** successive location fixes are
summed with these filters:

| Rule | Value |
|---|---|
| Discard fixes with accuracy worse than | 25 m |
| Ignore movement below the noise floor (avg accuracy of two fixes, min 3 m) | jitter while standing |
| Reject segments implying more than | 12 m/s (~43 km/h) |
| After > 30 s without signal, an implausible jump re-anchors instead of adding the gap | signal loss |

**Comparison** is shown **per GPS session**, using the steps counted during
that same session:

```
absolute difference = |stride distance − GPS distance|
difference %        = absolute difference / GPS distance × 100   (n/a when GPS = 0)
```

A whole-day stride total is never compared with a short GPS session. Both
values are estimates: stride length changes with pace, and GPS drifts
indoors and near tall buildings.

**Background behaviour:** GPS tracking runs while the app is open. No
background-location service is configured, so the OS may pause updates when
the app is backgrounded or the screen is off. Step counting is unaffected
(the sensor counts in hardware).

---

## Data, sync & time zones

- `daily_activity` holds one row per user per **local calendar date** (the
  date on the phone). Uploads go through `upsert_daily_activity`, which keeps
  the **larger** value per day, so retries or late uploads can never lower a
  valid total.
- GPS sessions use client-generated UUIDs and "insert, ignore duplicates", so
  retries never duplicate. Only summaries are stored (distance, duration,
  steps, stride) — never coordinates.
- If a day ends while the app is closed, its final total is uploaded on the
  next launch.
- Offline: data queues locally and syncs every 2 minutes, on resume and on
  pull-to-refresh. The Home screen shows the sync status.
- Days without data count as zero in averages; nothing is invented.

---

## Project structure

```
lib/
├── main.dart                 # bootstrap: storage, config check, Supabase init
├── app.dart                  # MaterialApp + AuthGate (protected routing)
├── config/app_config.dart    # --dart-define-from-file values
├── core/                     # theme, formatters, gps_math, distance_comparison, reports, ids
├── models/                   # profile, activity (DailyActivity, GpsSession)
├── services/
│   ├── backend.dart          # Supabase init + friendly errors
│   ├── auth_service.dart     # email, Google, Facebook, sessions, deletion
│   ├── profile_service.dart  # profiles table + local cache
│   ├── pedometer_service.dart# original pedometer (+ day close, active minutes)
│   ├── gps_tracker.dart      # geolocator sessions
│   ├── sync_service.dart     # offline queue → Supabase
│   ├── history_service.dart  # reports & sessions
│   ├── analytics_service.dart
│   ├── admin_service.dart    # admin RPCs / Edge Function
│   └── music_service.dart    # links + local player
├── widgets/common.dart       # original reusable widgets
└── screens/                  # auth/, activity/, music/, admin/, dashboard, profile
supabase/functions/           # delete-account, admin-set-user-status (Deno)
supabase_setup.sql            # schema, RLS, functions
test/                         # unit tests for the pure logic
```

State management is unchanged: `ChangeNotifier` + `ListenableBuilder`, no
extra package.

## Dependencies

| Package | Purpose |
|---|---|
| `pedometer` | Step count + pedestrian status streams |
| `permission_handler` | Activity-recognition permission |
| `shared_preferences` | Baseline, caches, offline queue |
| `supabase_flutter` | Auth, database, RPC, Edge Functions, deep links |
| `geolocator` | GPS sessions |
| `fl_chart` | Report and admin charts |
| `url_launcher` | OAuth browser, Spotify / YouTube links |
| `just_audio`, `audio_session`, `file_picker` | Local music playback |

`crypto` was removed with the old local SHA-256 accounts.

---

## Permissions

| Platform | Permission | When requested |
|---|---|---|
| Android | `ACTIVITY_RECOGNITION` | At launch, for step counting |
| Android | `ACCESS_FINE/COARSE_LOCATION` | Only when starting a GPS session |
| Android | `INTERNET` | Normal permission (no prompt) |
| iOS | `NSMotionUsageDescription`, `NSLocationWhenInUseUsageDescription` | Same as above |

No background location, no storage permission (files are chosen through the
system picker).

---

## Privacy & store disclosures

- Passwords live only in Supabase Auth; OAuth happens on the provider's page;
  client secrets are only in the Supabase dashboard.
- RLS on every table; users see only their own rows; admins see aggregates
  and basic account fields through server-checked functions.
- Location: used only during user-started sessions; route not stored.
- Analytics: no passwords, tokens, emails or coordinates; a random
  installation ID for first-launch counts.
- Retention: GPS summaries and daily totals are kept until the user deletes
  them or their account. Analytics events can be purged with
  `purge_old_analytics(365)` (schedule with pg_cron).
- Account deletion: Profile → *Delete my account* (Edge Function, cascades
  all user data).
- **Google Play Data safety / App Store privacy labels** will need to declare:
  email & name (account management), fitness info (app functionality),
  approximate/precise location (app functionality, not shared, not stored
  as a route), app interactions & device/other IDs (analytics). Provide a
  privacy policy URL and the in-app account-deletion path. Location is
  foreground-only, so no background-location declaration is required.

---

## Testing

Automated (`flutter test`, pure Dart logic — no device or credentials
needed): formatting & stride maths, GPS filtering and distance
accumulation, comparison maths incl. zero GPS, report aggregation & date
boundaries, max-value reconciliation, link validation, UUIDs.

**Needs your credentials / a physical device (not verified here):**

- Email sign-up/sign-in, Google and Facebook OAuth, deep-link return,
  session restore — need a configured Supabase project and providers.
- RLS and admin-only access — run the SQL-editor checks in
  `SUPABASE_SETUP.md` §11 with two test accounts.
- Step counting, GPS permission flows and real GPS distance — physical phone
  outdoors.
- Sync, history and analytics aggregation against a real database.
- Spotify / YouTube opening — phone with or without those apps installed.

## Known limitations

- Local accounts from the previous version can't be migrated (only a
  device-side hash existed). Users sign up again; step baselines are keyed by
  the new user id.
- GPS and local music are foreground-only.
- Store downloads are not measurable from Supabase; the dashboard reports
  first launches and labels them as such.
- Admin "today / week / month" windows are UTC; users' daily records use
  their local date.
- The application id is still `com.example.fitness_pedometer_app`.
