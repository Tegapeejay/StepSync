// Deletes the CALLING user's account. All user-owned rows reference
// auth.users with ON DELETE CASCADE, so profile, daily activity, GPS
// sessions, sign-in events and analytics linked to the user are removed too.
//
// The service-role key is read from the Edge Function environment (set
// automatically by Supabase) and never leaves the server.
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders, json } from "../_shared/cors.ts";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return json({ error: "missing authorization" }, 401);

  const url = Deno.env.get("SUPABASE_URL")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  // Identify the caller from THEIR token — never from the request body.
  const userClient = createClient(url, anonKey, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: { user }, error } = await userClient.auth.getUser(authHeader.replace(/^Bearer\s+/i, ""));
  if (error || !user) return json({ error: "not authenticated" }, 401);

  const admin = createClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error: delError } = await admin.auth.admin.deleteUser(user.id);
  if (delError) {
    console.error("delete-account failed", delError.message); // no tokens logged
    return json({ error: "could not delete account" }, 500);
  }
  return json({ deleted: true });
});
