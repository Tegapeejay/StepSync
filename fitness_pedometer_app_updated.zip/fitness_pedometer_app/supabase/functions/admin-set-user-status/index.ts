// Suspends or reactivates a user. Callable only by admins listed in
// public.admin_users (checked here with the CALLER's token via is_admin()).
//
// Suspension uses Supabase Auth's ban (the user can't sign in or refresh
// tokens) and mirrors the state into profiles.account_status for display.
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders, json } from "../_shared/cors.ts";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return json({ error: "missing authorization" }, 401);

  const url = Deno.env.get("SUPABASE_URL")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  const userClient = createClient(url, anonKey, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: { user }, error: userError } = await userClient.auth.getUser(authHeader.replace(/^Bearer\s+/i, ""));
  if (userError || !user) return json({ error: "not authenticated" }, 401);

  const { data: isAdmin, error: adminError } = await userClient.rpc("is_admin");
  if (adminError || isAdmin !== true) return json({ error: "forbidden" }, 403);

  let body: { user_id?: unknown; suspended?: unknown };
  try {
    body = await req.json();
  } catch {
    return json({ error: "invalid JSON" }, 400);
  }
  const targetId = typeof body.user_id === "string" ? body.user_id : "";
  const suspended = body.suspended === true;
  if (!UUID_RE.test(targetId)) return json({ error: "invalid user_id" }, 400);
  if (targetId === user.id) return json({ error: "you cannot change your own status" }, 400);

  const admin = createClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  // ~100 years ≈ indefinite; "none" lifts the ban.
  const { error: banError } = await admin.auth.admin.updateUserById(targetId, {
    ban_duration: suspended ? "876000h" : "none",
  });
  if (banError) {
    console.error("ban update failed", banError.message);
    return json({ error: "could not update user" }, 500);
  }

  const { error: profileError } = await admin
    .from("profiles")
    .update({ account_status: suspended ? "suspended" : "active" })
    .eq("id", targetId);
  if (profileError) console.error("profile status update failed", profileError.message);

  // A banned user can't sign in or refresh their session. An access token
  // already issued stays valid until it expires (JWT expiry, 1 hour by
  // default), after which the app is signed out.
  return json({ user_id: targetId, status: suspended ? "suspended" : "active" });
});
