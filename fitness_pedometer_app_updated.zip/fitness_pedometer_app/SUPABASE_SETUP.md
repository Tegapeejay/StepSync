# StepSync — Supabase, OAuth & environment setup

Everything below uses **placeholders**. Nothing here is pre-configured: you
need your own Supabase project, Google Cloud project and Facebook app.

Values used throughout:

| Placeholder | Meaning |
|---|---|
| `<PROJECT_REF>` | Your Supabase project reference (the subdomain of your project URL) |
| `https://<PROJECT_REF>.supabase.co/auth/v1/callback` | Supabase's OAuth callback — **this** is what Google and Facebook redirect to |
| `io.stepsync.app://login-callback` | The app's deep link — Supabase redirects **here** after it finishes sign-in |
| `com.example.fitness_pedometer_app` | Android package / application id (change it before publishing; see §11) |

---

## 1. Create a Supabase project

1. Go to <https://supabase.com/dashboard> → **New project**.
2. Choose an organisation, name, strong database password and region. Wait
   for it to finish provisioning.

## 2. Find the project URL

**Project Settings → Data API** (or **API**): copy **Project URL**, e.g.
`https://abcdefghijklmnop.supabase.co`. This is `SUPABASE_URL`.

## 3. Find the publishable key

**Project Settings → API Keys**:

- Newer projects: copy the **Publishable key** (`sb_publishable_…`).
- Older projects: copy the legacy **anon public** key.

Either goes into `SUPABASE_PUBLISHABLE_KEY`. It is safe to ship in the app
**because RLS protects the data**.

> **Never** put the `service_role` key or a `sb_secret_…` key in the app,
> `.env`, or source control. Only the Edge Functions use it, and Supabase
> injects it into them automatically.

## 4. Configure OAuth providers

The app uses Supabase's **browser-based OAuth with PKCE**: the provider's
page opens in the browser, the provider redirects to Supabase, and Supabase
redirects to the app's deep link. Client **secrets** are entered only in the
Supabase dashboard.

### 4a. Google (Google Cloud Console)

1. <https://console.cloud.google.com/> → create or select a project.
2. **APIs & Services → OAuth consent screen** (Google Auth Platform →
   Branding / Audience):
   - User type **External**, app name, support email, developer contact.
   - Authorised domain: `supabase.co` (and your own domain if you use a
     custom Supabase domain).
   - Scopes: `openid`, `.../auth/userinfo.email`, `.../auth/userinfo.profile`.
   - While in *Testing*, add test users; publish the app for everyone else.
3. **Credentials → Create credentials → OAuth client ID → Web application**
   (yes, *Web* — Supabase performs the code exchange):
   - Authorised redirect URI:
     `https://<PROJECT_REF>.supabase.co/auth/v1/callback`
   - Copy the **Client ID** and **Client secret**.
4. Supabase → **Authentication → Sign In / Providers → Google**: enable,
   paste the Client ID and Client secret, save.

*Android / iOS OAuth clients are not needed for this browser flow.* They are
only required if you later switch to native Google Sign-In
(`google_sign_in` + `signInWithIdToken`). In that case create:

- an **Android** client with package `com.example.fitness_pedometer_app` and
  the **SHA-1** of each signing key (`cd android && ./gradlew signingReport`
  for debug; the Play Console *App integrity* page for the Play signing key);
- an **iOS** client with your bundle id, and add its reversed client id as a
  URL scheme;
- then list those client ids under *Authorized Client IDs* in the Supabase
  Google provider.

### 4b. Facebook (Meta for Developers)

1. <https://developers.facebook.com/apps> → **Create app** → use case
   *Authenticate and request data from users with Facebook Login*.
2. **App settings → Basic**: copy **App ID** and **App secret**; add a
   privacy-policy URL and data-deletion instructions URL (required to go
   live).
3. **Facebook Login → Settings**:
   - **Valid OAuth Redirect URIs**:
     `https://<PROJECT_REF>.supabase.co/auth/v1/callback`
   - Enable *Client OAuth Login* and *Web OAuth Login*.
4. **Permissions**: `email` and `public_profile` (both standard access).
5. Supabase → **Authentication → Sign In / Providers → Facebook**: enable,
   paste App ID (as client id) and App secret, save.
6. Switch the Meta app to **Live** mode when ready (in Development mode only
   app roles can sign in).

*Android key hashes and an iOS bundle id are only needed for the native
Facebook SDK*, which this app does not use. If you add it later: generate
the key hash with
`keytool -exportcert -alias androiddebugkey -keystore ~/.android/debug.keystore | openssl sha1 -binary | openssl base64`
and register package `com.example.fitness_pedometer_app` + `MainActivity`.

### 4c. Email/password

Supabase → **Authentication → Sign In / Providers → Email**: enabled by
default. Decide on **Confirm email**:

- *On* (recommended for production): sign-up shows "Confirm your email" and
  the link opens the app through the deep link.
- *Off* (handy in development): users are signed in immediately.

Optionally raise the minimum password length to 8 under
**Authentication → Policies / Password security** to match the app.

## 5. Set up tables, RLS and functions

1. Supabase → **SQL Editor → New query**.
2. Paste the whole of [`supabase_setup.sql`](supabase_setup.sql) and click
   **Run**. It creates:
   - `profiles` (auto-created per user by a trigger on `auth.users`),
     `daily_activity`, `gps_sessions`, `sign_in_events`, `analytics_events`,
     `admin_users`;
   - indexes, unique constraints, `updated_at` triggers, the GPS→daily
     distance trigger;
   - RLS on every table, column privileges, and the RPC functions
     (`upsert_daily_activity`, `record_sign_in`, `is_admin`,
     `admin_dashboard_stats`, `admin_sign_ins_daily`, `admin_list_users`,
     `purge_old_analytics`).
3. Check **Table Editor**: every table should show "RLS enabled".

Dashboard-only steps (not SQL): providers (§4), redirect URLs (§7), Edge
Functions (§6), and optionally pg_cron for retention (see the comment above
`purge_old_analytics`).

## 6. Deploy the Edge Functions

They hold the only code that uses the service-role key.

```bash
npm install -g supabase
```

```bash
supabase login
```

```bash
supabase link --project-ref <PROJECT_REF>
```

```bash
supabase functions deploy delete-account
```

```bash
supabase functions deploy admin-set-user-status
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` are
provided to functions automatically. Keep **Verify JWT** enabled (default),
so only signed-in callers reach them; each function then checks who the
caller is (and `admin-set-user-status` checks `is_admin()`).

## 7. Create the first administrator (securely)

There is **no** API, policy or button that makes someone an admin.

1. Sign up in the app with the account that should be admin.
2. In the **SQL Editor** (which runs as the database owner) run:

   ```sql
   insert into public.admin_users (user_id, note)
   select id, 'initial admin' from auth.users where email = 'you@example.com'
   on conflict (user_id) do nothing;
   ```

3. Restart the app (or sign out and in): the **Admin** tab appears.

Remove an admin with
`delete from public.admin_users where user_id = (select id from auth.users where email = 'you@example.com');`.
Clients cannot read or write `admin_users` (RLS on, no policies, privileges
revoked), and profile rows can't grant admin rights.

## 8. Configure redirect URLs

Supabase → **Authentication → URL Configuration**:

- **Site URL**: your website, or `io.stepsync.app://login-callback` if you
  have none.
- **Redirect URLs** (allow-list): add `io.stepsync.app://login-callback`.

The same value must appear in:

- `.env` → `AUTH_REDIRECT_URL`
- `android/app/src/main/AndroidManifest.xml` → the `io.stepsync.app` /
  `login-callback` intent-filter
- `ios/Runner/Info.plist` → `CFBundleURLSchemes`

To use a different scheme, change all four together. Use a scheme unique to
your app (reverse-domain style; URI schemes can't contain `_`). For stronger
protection against other apps claiming the scheme, you can later move to
verified Android App Links / iOS Universal Links on a domain you own.

## 9. Set the app's environment variables

```bash
cp .env.example .env
```

Edit `.env`:

```
SUPABASE_URL=https://<PROJECT_REF>.supabase.co
SUPABASE_PUBLISHABLE_KEY=<publishable-or-anon-key>
AUTH_REDIRECT_URL=io.stepsync.app://login-callback
APP_ENV=development
```

`.env` is git-ignored. Values are compiled in with `--dart-define-from-file`.

**Development vs production:** create two Supabase projects and two files,
e.g. `.env.dev` and `.env.prod`, then build with the matching one:

```bash
flutter run --dart-define-from-file=.env.dev
```

```bash
flutter build appbundle --release --dart-define-from-file=.env.prod
```

Run `supabase_setup.sql` and configure providers / redirect URLs in **both**
projects. Use separate OAuth clients (or at least separate redirect URIs) per
project.

## 10. Run the app

```bash
flutter pub get
```

```bash
flutter run --dart-define-from-file=.env
```

Without the `--dart-define-from-file` flag the app shows a "Setup needed"
screen instead of crashing.

## 11. Verify everything works

| Check | How |
|---|---|
| Email sign-up | Create an account → a row appears in **Authentication → Users** and in `profiles`. |
| Email sign-in / session restore | Sign in with *Remember me*, kill and reopen the app → still signed in. Untick it → signed out on next launch. |
| Google / Facebook | Tap the button, finish in the browser → app opens signed in; `profiles.signup_provider` shows the provider. Cancel in the browser → the app says sign-in was cancelled. |
| Sign-in events | `select provider, count(*) from sign_in_events group by 1;` in the SQL editor. |
| Daily sync | Walk a little, pull to refresh on Home → `daily_activity` row for today. |
| GPS session | Record a session outdoors → row in `gps_sessions`; today's `daily_activity.gps_distance_m` matches. |
| RLS | With two test accounts, user B's app never shows user A's history. In the SQL editor you can simulate: `set local role authenticated; set local request.jwt.claims = '{"sub":"<user-B-id>"}'; select * from daily_activity;` (inside `begin; … rollback;`) → only B's rows. |
| Admin protection | As a non-admin: `select public.admin_dashboard_stats();` via the app/RPC → error `not authorized`. As admin → JSON. |
| Account deletion | Profile → *Delete my account* → the user and all their rows disappear. |

**Before publishing:** change the application id from
`com.example.fitness_pedometer_app` (Android `applicationId`/`namespace`,
iOS bundle id), set up release signing, and update any provider settings that
reference the package name.
