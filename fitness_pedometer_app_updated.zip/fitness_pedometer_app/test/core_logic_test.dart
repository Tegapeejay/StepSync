import 'package:fitness_pedometer_app/core/distance_comparison.dart';
import 'package:fitness_pedometer_app/core/formatters.dart';
import 'package:fitness_pedometer_app/core/gps_math.dart';
import 'package:fitness_pedometer_app/core/ids.dart';
import 'package:fitness_pedometer_app/core/reports.dart';
import 'package:fitness_pedometer_app/models/activity.dart';
import 'package:fitness_pedometer_app/services/music_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('formatting & stride', () {
    test('formatSteps adds separators and clamps negatives', () {
      expect(formatSteps(0), '0');
      expect(formatSteps(999), '999');
      expect(formatSteps(10245), '10,245');
      expect(formatSteps(1234567), '1,234,567');
      expect(formatSteps(-5), '0');
    });

    test('stride estimate uses height × sex factor', () {
      expect(estimateStrideMeters(heightCm: 180, sex: 'male'), closeTo(0.747, 1e-9));
      expect(estimateStrideMeters(heightCm: 170, sex: 'female'), closeTo(0.7021, 1e-9));
      expect(estimateStrideMeters(heightCm: 170, sex: 'unspecified'), closeTo(0.7038, 1e-9));
      expect(estimateStrideMeters(heightCm: 0, sex: 'male'), 0.75); // fallback
    });

    test('distance formatting in km and miles', () {
      expect(formatDistance(6200, DistanceUnit.km), '6.20 km');
      expect(formatDistance(12345, DistanceUnit.km), '12.3 km');
      expect(formatDistance(1609.344, DistanceUnit.mi), '1.00 mi');
    });

    test('local date keys and DST-safe calendar maths', () {
      expect(dateKey(DateTime(2026, 3, 7, 23, 59)), '2026-03-07');
      expect(parseDateKey('2026-03-07'), DateTime(2026, 3, 7));
      expect(startOfWeek(DateTime(2026, 11, 1)), DateTime(2026, 10, 26)); // Sunday → Monday
      expect(endOfMonth(DateTime(2028, 2, 10)), DateTime(2028, 2, 29)); // leap year
      expect(addDays(DateTime(2026, 10, 24), 7), DateTime(2026, 10, 31));
    });
  });

  group('distance comparison', () {
    test('uses |stride − GPS| / GPS × 100', () {
      const DistanceComparison c = DistanceComparison(strideMeters: 6200, gpsMeters: 5850);
      expect(c.absoluteDifferenceMeters, closeTo(350, 1e-9));
      expect(c.differencePercent, closeTo(5.9829, 1e-3));
      expect(c.signedDifferenceMeters, greaterThan(0));
      expect(c.isMeaningful, isTrue);
    });

    test('zero GPS distance gives no percentage instead of dividing by zero', () {
      const DistanceComparison c = DistanceComparison(strideMeters: 500, gpsMeters: 0);
      expect(c.differencePercent, isNull);
      expect(c.isMeaningful, isFalse);
    });

    test('stride distance rejects nonsense inputs', () {
      expect(strideDistanceMeters(8500, 0.73), closeTo(6205, 1e-9));
      expect(strideDistanceMeters(-1, 0.73), 0);
      expect(strideDistanceMeters(100, 0), 0);
    });
  });

  group('GPS accumulation', () {
    final DateTime t0 = DateTime.utc(2026, 10, 19, 8);
    // ~0.0001° latitude ≈ 11.1 m.
    GpsFix fix(double lat, int seconds, {double acc = 5, double lon = 0}) => GpsFix(
          latitude: lat,
          longitude: lon,
          accuracyMeters: acc,
          timestamp: t0.add(Duration(seconds: seconds)),
        );

    test('haversine is close to the known value', () {
      // 1° of latitude ≈ 111.19 km.
      expect(haversineMeters(0, 0, 1, 0), closeTo(111195, 50));
    });

    test('sums valid movement', () {
      final GpsDistanceAccumulator a = GpsDistanceAccumulator();
      expect(a.add(fix(0, 0)), FixDecision.anchored);
      expect(a.add(fix(0.0001, 10)), FixDecision.accepted);
      expect(a.add(fix(0.0002, 20)), FixDecision.accepted);
      expect(a.totalMeters, closeTo(22.24, 0.1));
    });

    test('drops inaccurate fixes', () {
      final GpsDistanceAccumulator a = GpsDistanceAccumulator();
      a.add(fix(0, 0));
      expect(a.add(fix(0.001, 10, acc: 80)), FixDecision.rejectedInaccurate);
      expect(a.totalMeters, 0);
    });

    test('ignores jitter while standing still but keeps slow progress', () {
      final GpsDistanceAccumulator a = GpsDistanceAccumulator();
      a.add(fix(0, 0, acc: 8));
      // 2.2 m wobble is below the 8 m noise floor.
      expect(a.add(fix(0.00002, 5, acc: 8)), FixDecision.ignoredJitter);
      expect(a.add(fix(0.00001, 10, acc: 8)), FixDecision.ignoredJitter);
      expect(a.totalMeters, 0);
      // Real movement eventually exceeds the floor from the original anchor.
      expect(a.add(fix(0.0001, 20, acc: 8)), FixDecision.accepted);
      expect(a.totalMeters, closeTo(11.12, 0.1));
    });

    test('rejects implausible jumps', () {
      final GpsDistanceAccumulator a = GpsDistanceAccumulator();
      a.add(fix(0, 0));
      // 1.1 km in 5 s = 222 m/s.
      expect(a.add(fix(0.01, 5)), FixDecision.rejectedJump);
      expect(a.totalMeters, 0);
      // Next normal fix still measures from the last good anchor.
      expect(a.add(fix(0.0001, 15)), FixDecision.accepted);
    });

    test('after a long signal gap re-anchors instead of adding the straight line', () {
      final GpsDistanceAccumulator a = GpsDistanceAccumulator();
      a.add(fix(0, 0));
      a.add(fix(0.0001, 10));
      final double before = a.totalMeters;
      // 60 s gap and 2.2 km away (too fast to be walking) → re-anchor.
      expect(a.add(fix(0.02, 70)), FixDecision.anchored);
      expect(a.totalMeters, before);
      expect(a.add(fix(0.0201, 80)), FixDecision.accepted);
    });

    test('rejects duplicate or out-of-order timestamps', () {
      final GpsDistanceAccumulator a = GpsDistanceAccumulator();
      a.add(fix(0, 10));
      expect(a.add(fix(0.0001, 10)), FixDecision.rejectedStale);
      expect(a.add(fix(0.0001, 5)), FixDecision.rejectedStale);
    });
  });

  group('reports', () {
    DailyActivity day(int d, int steps, {double gps = 0, int goal = 10000}) => DailyActivity(
          date: DateTime(2026, 10, d),
          steps: steps,
          strideDistanceMeters: steps * 0.7,
          gpsDistanceMeters: gps,
          activeMinutes: steps ~/ 100,
          dailyGoal: goal,
        );

    test('week totals, averages, best day and goal days', () {
      // Week of Mon 19 – Sun 25 Oct 2026; "today" is Thursday 22nd.
      final ActivityReport r = ActivityReport.build(
        period: ReportPeriod.week,
        anchor: DateTime(2026, 10, 22),
        records: <DailyActivity>[day(19, 12000, gps: 3000), day(21, 4000), day(22, 10000)],
        today: DateTime(2026, 10, 22),
      );
      expect(r.days, hasLength(7));
      expect(r.elapsedDays, 4); // Mon..Thu
      expect(r.totalSteps, 26000);
      expect(r.totalGpsMeters, 3000);
      expect(r.averageDailySteps, 6500); // Tuesday (no record) counts as 0
      expect(r.goalDays, 2);
      expect(r.goalRate, 0.5);
      expect(r.bestDay!.date, DateTime(2026, 10, 19));
      expect(r.daysWithActivity, 3);
    });

    test('month range covers the calendar month', () {
      final ActivityReport r = ActivityReport.build(
        period: ReportPeriod.month,
        anchor: DateTime(2026, 2, 14),
        records: const <DailyActivity>[],
        today: DateTime(2026, 6, 1),
      );
      expect(r.from, DateTime(2026, 2, 1));
      expect(r.to, DateTime(2026, 2, 28));
      expect(r.elapsedDays, 28);
      expect(r.bestDay, isNull);
      expect(r.averageDailySteps, 0);
    });

    test('live total never lowers a larger server value', () {
      final List<DailyActivity> merged = mergeLiveToday(
        <DailyActivity>[day(18, 5000), day(19, 9000, gps: 2000)],
        today: DateTime(2026, 10, 19),
        steps: 7000, // smaller than the server copy
        strideMeters: 0.7,
        activeMinutes: 10,
        dailyGoal: 10000,
        localGpsMeters: 2500,
      );
      final DailyActivity today = merged.last;
      expect(today.steps, 9000);
      expect(today.gpsDistanceMeters, 2500);
      expect(merged.first.date, DateTime(2026, 10, 18));
    });
  });

  group('sync reconciliation', () {
    test('merging queued uploads keeps the larger values', () {
      const DailyUpload a = DailyUpload(
          dateKey: '2026-10-19', steps: 8000, strideDistanceMeters: 5600, activeMinutes: 40, dailyGoal: 10000);
      const DailyUpload b = DailyUpload(
          dateKey: '2026-10-19', steps: 6000, strideDistanceMeters: 4200, activeMinutes: 55, dailyGoal: 12000);
      final DailyUpload m = a.merge(b);
      expect(m.steps, 8000);
      expect(m.strideDistanceMeters, 5600);
      expect(m.activeMinutes, 55);
      expect(m.dailyGoal, 12000);
      expect(DailyUpload.fromJson(m.toJson()).steps, 8000);
    });

    test('GPS session row round-trips without coordinates', () {
      final GpsSession s = GpsSession(
        id: uuidV4(),
        startedAt: DateTime(2026, 10, 19, 7, 30),
        endedAt: DateTime(2026, 10, 19, 8, 0),
        gpsDistanceMeters: 4321.06,
        durationSeconds: 1800,
        steps: 5000,
        strideMeters: 0.8,
      );
      final Map<String, dynamic> row = s.toRow('user-1');
      expect(row.keys, isNot(contains('latitude')));
      expect(row['activity_date'], '2026-10-19');
      final GpsSession back = GpsSession.fromRow(row);
      expect(back.gpsDistanceMeters, closeTo(4321.1, 1e-9));
      expect(back.strideDistanceMeters, closeTo(4000, 1e-9));
      expect(back.averageSpeedMps, closeTo(4321.1 / 1800, 1e-6));
    });
  });

  group('music links', () {
    test('only Spotify and YouTube links are accepted', () {
      expect(providerForUrl('https://open.spotify.com/playlist/37i9dQZF1DX76Wlfdnj7AP'), MusicProvider.spotify);
      expect(providerForUrl('spotify:playlist:37i9dQZF1DX76Wlfdnj7AP'), MusicProvider.spotify);
      expect(providerForUrl('https://www.youtube.com/watch?v=abc'), MusicProvider.youtube);
      expect(providerForUrl('https://youtu.be/abc'), MusicProvider.youtube);
      expect(providerForUrl('https://music.youtube.com/playlist?list=x'), MusicProvider.youtubeMusic);
      expect(providerForUrl('http://open.spotify.com/x'), isNull); // not https
      expect(providerForUrl('https://evil.example/youtube.com'), isNull);
      expect(providerForUrl('javascript:alert(1)'), isNull);
    });
  });

  test('uuidV4 is a valid version-4 UUID and unique', () {
    final RegExp re = RegExp(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$');
    final String a = uuidV4();
    expect(re.hasMatch(a), isTrue);
    expect(uuidV4(), isNot(a));
  });
}
